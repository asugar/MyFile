package cn.yunzhisheng.demo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import cn.yunzhisheng.prodemo.R;

import com.unisound.client.SpeechUnderstander;
import com.unisound.client.SpeechUnderstanderListener;

public class ASROfflineActivity extends Activity {

	private ProgressBar mProgressBarVolume;
	// private RadioButton mRadioNetAsr;
	private EditText mTextViewResult;
	private TextView mTextViewTip;
	// private TextView mTextViewStatus;
	private Button mRecognizerButton;
	private View mStatusView;
	private View mStatusLayout;
	private TextView mStatusTextView;
	private SpeechUnderstander mFixRecognizer;
	private ImageView mLogoImageView;

	private LinearLayout status_panel;
	private TextView type;

	enum AsrStatus {
		idle, recording, recognizing
	}

	private AsrStatus statue = AsrStatus.idle;
	/**
	 * 目前离线识别支持的词表
	 */
	private String mAsrFixWords = "请说以下命令：打开电视/关闭电视/打开空调/关闭空调/打开蓝牙/关闭蓝牙/增大音量/减小音量/播放音乐/停止播放";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_offline_asr);
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.status_bar_main);

		mProgressBarVolume = (ProgressBar) findViewById(R.id.progressBarVolume);
		mTextViewResult = (EditText) findViewById(R.id.textViewResult);
		// mTextViewStatus = (TextView) findViewById(R.id.textViewStatus);
		mTextViewTip = (TextView) findViewById(R.id.textViewTip);
		// mRadioNetAsr= (RadioButton) findViewById(R.id.radioNetAsr);
		status_panel = (LinearLayout) findViewById(R.id.status_panel);
		mLogoImageView = (ImageView) findViewById(R.id.logo_imageview);
		mRecognizerButton = (Button) findViewById(R.id.recognizer_btn);
		mProgressBarVolume.setVisibility(View.INVISIBLE);
		status_panel.setVisibility(View.INVISIBLE);
		mStatusView = findViewById(R.id.status_panel);
		mStatusTextView = (TextView) findViewById(R.id.status_show_textview);
		mStatusLayout = findViewById(R.id.status_layout);

		type = (TextView) findViewById(R.id.type);
		type.setText(getString(R.string.asr_offline_function));
		mTextViewTip.setText(mAsrFixWords);

		// 初始化本地离线识别
		initFixRecognizer();
	}

	/**
	 * 初始化本地离线识别
	 */
	private void initFixRecognizer() {

		// please apply your appKey at http://dev.hivoice.cn/
		mFixRecognizer = new SpeechUnderstander(this, Config.appKey, Config.secret);
		mFixRecognizer.setListener(new SpeechUnderstanderListener() {

			@Override
			public void onEvent(int type, int timeMs) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onError(int type, String errorMSG) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onResult(int type, String jsonResult) {
				// TODO Auto-generated method stub
				
			}
			
//			@Override
//			public void onVADTimeout() {
//				// VAD 超时回调
//				log_i("FixRecognizer onVADTimeout");
//				stopRecord();
//			}
//
//			@Override
//			public void onRecognizerStart() {
//				log_i("FixRecognizer onRecognizerStart");
//				mProgressBarVolume.setVisibility(View.VISIBLE);
//				status_panel.setVisibility(View.VISIBLE);
//			}
//
//			@Override
//			public void onUpdateVolume(int volume) {
//				// 说话音量实时返回
//				mProgressBarVolume.setProgress(volume);
//			}
//
//			@Override
//			public void onEnd(USCError error) {
//				// 语音识别结束
//				log_i("FixRecognizer onEnd");
//				mRecognizerButton.setEnabled(true);
//				statue = AsrStatus.idle;
//				mRecognizerButton.setText(R.string.click_say);
//				mStatusLayout.setVisibility(View.GONE);
//				if (error != null) {
//					// 显示错误信息
//					mTextViewResult.setText(error.toString());
//				} else {
//					if ("".equals(mTextViewResult.getText().toString())) {
//						mTextViewResult.setText(R.string.no_hear_sound);
//					}
//				}
//
//			}
//
//			@Override
//			public void onRecordingStop() {
//				// 录音会话结果，等待返回识别结果
//				log_i("FixRecognizer onRecordingStop");
//				mProgressBarVolume.setVisibility(View.INVISIBLE);
//				mTextViewResult.setVisibility(View.VISIBLE);
//				statue = AsrStatus.recognizing;
//				mRecognizerButton.setText(R.string.give_up);
//				mStatusTextView.setText(R.string.just_recognizer);
//			}
//
//			@Override
//			public void onResult(List<String> arg0, float arg1) {
//				// 返回离线识别结果
//				log_i("FixRecognizer onResult");
//				mTextViewResult.append(arg0.toString() + "\t score =" + arg1);
//				mFixRecognizer.stop();
//			}

		});

		mRecognizerButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (statue == AsrStatus.idle) {
					mTextViewResult.setVisibility(View.VISIBLE);
					mRecognizerButton.setEnabled(false);
					mTextViewResult.setText("");
					
					mStatusView.setVisibility(View.VISIBLE);
					mStatusLayout.setVisibility(View.VISIBLE);
					mLogoImageView.setVisibility(View.GONE);
					// 在收到 onRecognizerStart 回调前，录音设备没有打开，请添加界面等待提示，
					// 录音设备打开前用户说的话不能被识别到，影响识别效果。
					mStatusTextView.setText(R.string.opening_recode_devices);
					recognizerStart();
				} else if (statue == AsrStatus.recording) {
					stopRecord();
				} else if (statue == AsrStatus.recognizing) {
					// 取消识别
					mFixRecognizer.cancel();

					mRecognizerButton.setText(R.string.click_say);
					statue = AsrStatus.idle;
				}
			}
		});
	}

	private void stopRecord() {
		mStatusTextView.setText(R.string.just_recognizer);
		mFixRecognizer.stop();
	}

	protected void recognizerStart() {
		mTextViewResult.setText("");
		status_panel.setVisibility(View.VISIBLE);
		mLogoImageView.setVisibility(View.GONE);
		mFixRecognizer.start();
	}

	@Override
	public void onPause() {
		super.onPause();
		// 取消识别
		mFixRecognizer.cancel();
		statue = AsrStatus.idle;
	}

	private void log_i(String log) {
		Log.i("demo", log);
	}

	@Override
	protected void onDestroy() {
		mFixRecognizer.cancel();
		super.onDestroy();
	}

}
