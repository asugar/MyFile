package cn.yunzhisheng.demo;

import java.io.IOException;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import cn.yunzhisheng.prodemo.R;

import com.unisound.client.VoicePrintRecognizer;
import com.unisound.client.VoicePrintRecognizerListener;
import com.unisound.common.VoiceprintResult;
import com.unisound.sdk.RequestIdListener;
import com.unisound.tmp.USCError;

/**
 * 云知声声纹识别实例程序
 * 
 * @author
 * 
 */
public class VPROnlineActivity extends Activity implements OnClickListener {

	String vprfile = Environment.getExternalStorageDirectory().getPath() + "/vpr_demp/test.mp3";
	private VoicePrintRecognizer mVprRecognizer;
	private Button mRegisterBtn, mVerifyBtn, mStopReordBtn, mSaveRequestBtn;
	private TextView statusText, resultText;
	private String userName = "";
	private ProgressBar pbVolume;
	private String requestId = "";
	private MediaPlayer mMP;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_vpr);

		mRegisterBtn = (Button) findViewById(R.id.vpr_register_btn);
		mVerifyBtn = (Button) findViewById(R.id.vpr_verify_btn);
		mStopReordBtn = (Button) findViewById(R.id.vpr_stop_record_btn);
		mSaveRequestBtn = (Button) findViewById(R.id.vpr_save_record_btn);
		mRegisterBtn.setOnClickListener(this);
		mVerifyBtn.setOnClickListener(this);
		mStopReordBtn.setOnClickListener(this);
		mSaveRequestBtn.setOnClickListener(this);
		mSaveRequestBtn.setEnabled(false);
		mMP = new MediaPlayer();

		pbVolume = (ProgressBar) findViewById(R.id.pbVolume);
		pbVolume.setMax(100);
		statusText = (TextView) findViewById(R.id.status_text);
		resultText = (TextView) findViewById(R.id.result_text);
		// 初始化声纹对象
		mVprRecognizer = new VoicePrintRecognizer(this, Config.appKey, Config.secret);
		// 注册requestId
		registeRequestListener();

	}

	// 声纹注册
	private void registerVpr() {
		tipString("开始说话 进行身份注册...");
		resetText();
		// 声纹用户id
		// mVprRecognizer.setUserName(System.currentTimeMillis() + "");
		// 设置参数
		// mVprRecognizer.setOption(VoicePrintRecognizer.OPTION_VPR_TYPE,
		// VoicePrintRecognizer.OPTION_VPR_TYPE_REGISTERED);
		mVprRecognizer.setListener(new VoicePrintRecognizerListener() {

			@Override
			public int onEvent(int type, int times) {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public void onError(int type, String errorMSG) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onResult(int type, VoiceprintResult vprResult) {
				// TODO Auto-generated method stub
				
			}

			// @Override
			// public void onUpdateVolume(int volume) {
			// pbVolume.setProgress(volume);
			// }
			//
			// @Override
			// public void onResult(VoiceprintResult result) {
			//
			// Log.e("USC", "result :  " + result.getString());
			// switch (result.getStatus()) {
			// case 1:
			// statusText.setText("语音正在处理中");
			// break;
			//
			// case 200:
			// // 声纹注册成功，取出用户id。用于做声纹验证
			// // 获取sessionId;
			// String sessionId = (String) mVprRecognizer
			// .getOption(VoiceprintRecognizer.OPTION_VPR_SESSION_ID);
			// log_v("200  sessionId : " + sessionId);
			// userName = result.getUserName();
			// resultText.setText(result.getUserName() + "  声纹注册成功...");
			// mSaveRequestBtn.setEnabled(true);
			// break;
			//
			// case 400:
			// resultText.setText("错误码 400: 客户端参数错误");
			// break;
			//
			// case 501:
			// resultText.setText("错误码 501: 声纹注册异常");
			// break;
			//
			// case 502:
			// resultText.setText("错误码 502: 重复用户名或者声纹持久化异常");
			// break;
			//
			// case 503:
			// resultText.setText("错误码 503: 无法提取声纹特征（声音超级短，或空白语音）");
			// break;
			//
			// case 504:
			// resultText.setText("错误码 504: 语音太短(最短注册5s,匹配2s)...");
			// break;
			//
			// default:
			// resultText.setText("错误码: " + result.getStatus());
			// break;
			// }
			// }
			//
			// @Override
			// public void onRecordingStop() {
			//
			// }
			//
			// @Override
			// public void onRecordingStart() {
			// tipString("开始注册...");
			// }
			//
			// @Override
			// public void onEnd(USCError error) {
			// if (error != null) {
			// log_e(error.toString());
			// resultText.setText(error.toString());
			// }
			// }
		});
		mVprRecognizer.start(null, 0);
	}

	// 声纹验证
	private void verifyVpr() {
		tipString("开始说话 进行声份验证.....");
		resetText();
		// 设置声纹验证的用户id
//		mVprRecognizer.setUserName(userName);
//		mVprRecognizer.setOption(VoiceprintRecognizer.OPTION_VPR_TYPE, VoiceprintRecognizer.OPTION_VPR_TYPE_VERIFY);
//		mVprRecognizer.start(new VoiceprintRecognizerListener() {
//
//			@Override
//			public void onUpdateVolume(int volume) {
//				pbVolume.setProgress(volume);
//			}
//
//			@Override
//			public void onResult(VoiceprintResult result) {
//				log_e("result:  " + result.getString());
//				switch (result.getStatus()) {
//					case 1:
//						statusText.setText("语音正在处理中");
//						break;
//
//					case 200:
//						if (result.getScore() > 60) {
//							resultText.setText(result.getUserName() + "声纹验证成功...");
//						} else {
//							resultText.setText(result.getUserName() + " 声纹匹配度较低.");
//						}
//						break;
//
//					case 400:
//						resultText.setText("错误码 400: 客户端参数错误");
//						break;
//
//					case 402:
//						resultText.setText("错误码 402: 缺少必要参数type 或者userName");
//						break;
//
//					case 501:
//						resultText.setText("错误码 501: 声纹注册异常...");
//						break;
//
//					case 502:
//						resultText.setText("错误码 502: 重复用户名或者声纹持久化异常...");
//						break;
//
//					case 503:
//						resultText.setText("错误码 503:无法提取声纹特征（声音超级短，或空白语音）");
//						break;
//
//					case 504:
//						resultText.setText("错误码 504:语音太短(最短注册5s,匹配2s)...");
//						break;
//
//					default:
//						resultText.setText("错误码: " + result.getStatus());
//						break;
//				}
//			}
//
//			@Override
//			public void onRecordingStop() {
//
//			}
//
//			@Override
//			public void onRecordingStart() {
//				tipString("开始验证");
//			}
//
//			@Override
//			public void onEnd(USCError error) {
//				if (error != null) {
//					log_e(error.toString());
//					resultText.setText(error.toString());
//				}
//			}
//		});

	}

	private void tipString(String tip) {
		Toast.makeText(this, tip, Toast.LENGTH_SHORT).show();
	}

	/**
	 * 打印日志信息
	 * 
	 * @param msg
	 */
	private void log_v(String msg) {
		Log.v("demo", msg);
	}

	private void log_e(String msg) {
		Log.e("demo", msg);
	}

	/**
	 * 停止录音
	 */
	public void stopRecord() {
		statusText.setText("");
		mVprRecognizer.stop();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.vpr_register_btn:
				registerVpr();
				break;

			case R.id.vpr_verify_btn:
				verifyVpr();
				break;

			case R.id.vpr_stop_record_btn:
				stopRecord();
				break;
			case R.id.vpr_save_record_btn:
				mSaveRequestBtn.setEnabled(false);
				// 在子线程中去保存语音数据
				new Thread() {
//					public void run() {
//						if (mVprRecognizer.getRequestAudio(requestId, vprfile)) {
//							runOnUiThread(new Runnable() {
//								@Override
//								public void run() {
//									Toast.makeText(getApplicationContext(), "注册语音保存成功", 1000).show();
//								}
//
//							});
//							try {
//								Log.d("TESTLOG", "vprFile = " + vprfile);
//								mMP.reset();
//								mMP.setDataSource(vprfile);
//								mMP.setOnErrorListener(new OnErrorListener() {
//
//									@Override
//									public boolean onError(MediaPlayer mp, int what, int extra) {
//										Log.e("demo", "what: " + what);
//										return false;
//									}
//								});
//								mMP.setOnPreparedListener(new OnPreparedListener() {
//									@Override
//									public void onPrepared(MediaPlayer mp) {
//										mp.start();
//									}
//								});
//								mMP.prepare();
//								mMP.setOnCompletionListener(new OnCompletionListener() {
//
//									@Override
//									public void onCompletion(MediaPlayer mp) {
//										mSaveRequestBtn.setEnabled(true);
//									}
//								});
//
//							} catch (IllegalArgumentException e) {
//								e.printStackTrace();
//							} catch (IllegalStateException e) {
//								e.printStackTrace();
//							} catch (IOException e) {
//								e.printStackTrace();
//							}
//
//						}
//					};
				}.start();
				break;
		}

	}

	private void resetText() {
		statusText.setText("");
		resultText.setText("");
	}

	// 注册requestListener
	private void registeRequestListener() {
//		mVprRecognizer.setRequestIdListener(new RequestIdListener() {
//
//			@Override
//			public void onRecogintionRequestId(String requestid) {
//				requestId = requestid;
//				Log.d("TESTLOG", "requestId = " + requestId);
//			}
//
//		});
	}

	@Override
	protected void onDestroy() {
		if (mMP != null) {
			mMP.release();
		}
		if (mVprRecognizer != null) {
			mVprRecognizer.stop();
		}
		super.onDestroy();
	}
}
