package cn.yunzhisheng.demo;

import android.app.Activity;
import android.app.Service;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import cn.yunzhisheng.prodemo.R;

import com.unisound.client.WakeUpRecognizer;
import com.unisound.client.WakeUpRecognizerListener;

public class WakeupOfflineActivity extends Activity {

	private EditText mTextViewResult;
	private TextView mTextViewTip;
	private TextView mTextViewStatus;
	private WakeUpRecognizer mWakeUpRecognizer;
	private ImageView mLogoImageView;

	private LinearLayout status_panel;
	private TextView type;

	/**
	 * 唤醒震动提示
	 */
	private Vibrator mVibrator;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wakeup);
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.status_bar_main);
		mVibrator = (Vibrator) getSystemService(Service.VIBRATOR_SERVICE);

		mTextViewResult = (EditText) findViewById(R.id.textViewResult);
		mTextViewStatus = (TextView) findViewById(R.id.textViewStatus);
		mTextViewTip = (TextView) findViewById(R.id.textViewTip);
		status_panel = (LinearLayout) findViewById(R.id.status_panel);
		mLogoImageView = (ImageView) findViewById(R.id.logo_imageview);

		status_panel.setVisibility(View.INVISIBLE);

		type = (TextView) findViewById(R.id.type);
		type.setText(getString(R.string.wakeup_offline_function));

		// 初始化本地离线唤醒
		initWakeUp();

		// 启动本地语音唤醒
		wakeUpStart();
	}

	/**
	 * 初始化本地离线唤醒
	 */
	private void initWakeUp() {

		mWakeUpRecognizer = new WakeUpRecognizer(this, Config.appKey, Config.secret);
		mWakeUpRecognizer.setListener(new WakeUpRecognizerListener() {
			@Override
			public void onEvent(int type, int timeMs) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onError(int type, String errorMSG) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onResult(int type, String jsonResult) {
				// TODO Auto-generated method stub

			}
			// @Override
			// public void onWakeUpRecognizerStart() {
			// log_i("WakeUpRecognizer onRecordingStart");
			// setStatusText("语音唤醒已开始");
			// setTipText("请说 [你好魔方] 唤醒");
			// toastMessage("语音唤醒已开始");
			//
			// }
			//
			// @Override
			// public void onWakeUpError(USCError error) {
			// if (error != null) {
			// toastMessage("语音唤醒服务异常  异常信息：" + error.toString());
			// setTipText(error.toString());
			// }
			// showResultView();
			// }
			//
			// @Override
			// public void onWakeUpRecognizerStop() {
			// log_i("WakeUpRecognizer onRecordingStop");
			// toastMessage("语音唤醒录音已停止");
			// setStatusText("语音唤醒已停止");
			//
			// }
			//
			// @Override
			// public void onWakeUpResult(boolean succeed, String text, float
			// score) {
			// showResultView();
			// if (succeed) {
			// mVibrator.vibrate(300);
			// toastMessage(text + "(唤醒成功)");
			// mTextViewResult.setText(text + "(唤醒成功)\n score=" + score);
			// }
			// }

		});
	}

	private void showResultView() {
		status_panel.setVisibility(View.VISIBLE);
		mLogoImageView.setVisibility(View.GONE);
	}

	protected void setTipText(String tip) {

		mTextViewTip.setText(tip);
	}

	protected void setStatusText(String status) {

		mTextViewStatus.setText(getString(R.string.lable_status) + "(" + status + ")");
	}

	/**
	 * 启动语音唤醒
	 */
	protected void wakeUpStart() {

		toastMessage("开始语音唤醒");
		/** ---设置唤醒命令词集合--- */
		mTextViewResult.setText("");
		mTextViewTip.setText("");

		mWakeUpRecognizer.start();
	}

	@Override
	public void onPause() {
		super.onPause();
		// 主动停止识别
		mWakeUpRecognizer.cancel();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		mWakeUpRecognizer.start();
	}

	private void log_i(String log) {
		Log.i("demo", log);
	}

	@Override
	protected void onStop() {
		super.onStop();
		log_i("onStop()");
	}

	@Override
	protected void onDestroy() {
		log_i("onDestroy()");
		mWakeUpRecognizer.cancel();
		super.onDestroy();
	}

	private void toastMessage(String message) {
		Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
	}
}
