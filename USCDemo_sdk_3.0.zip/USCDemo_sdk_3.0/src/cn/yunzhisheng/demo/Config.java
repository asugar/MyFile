/**
 * Config.java [V 1.0.0]
 * classes : cn.yunzhisheng.prodemo.Config
 * liujunjie Create  at 2015-1-9  ??4:30:32
 */
package cn.yunzhisheng.demo;

/**
 * cn.yunzhisheng.prodemo.Config
 * 
 * @author liujunjie <br/>
 *         Create at 2015-1-9 ??4:30:32
 * 
 */
public class Config {

	public static final String appKey = "o56brpo637hlsyw3e7mpyigkirnyguwxqkqkytaa";
	public static final String secret = "2eedd10246ddfc275b13cb32be623aba";
}
