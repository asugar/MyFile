package cn.yunzhisheng.asr;

import android.media.MediaRecorder;

/**
 * VAD 参数管理类
 * @author user
 *
 */
public class VADParams {
	
	public static final int INT_OFFSET = 10000;
	public static final int FLOAT_OFFSET = 20000;
	

	static final int MINBACKENG_ = 5;    // min back energy, default 5e6 (float)
	static final int MINBACKENGH_ = MINBACKENG_ +1;   // min back energy higher TH, just larger than this, may voice occur, 5e8(for very noise, if voice is good, set it low, like 5e6) (float)
	 static final int PITCHTH_ = MINBACKENGH_ +1;       // pitch threshold, 0.7 (float)
	 static final int PITCHSTNUMTH_ = PITCHTH_ +1;  // pitch persist length for start usage, 8 (int)
	 static final int PITCHENDNUMTH_ = PITCHSTNUMTH_ +1; // pitch drop length for end usage, 50 (int)
	 static final int LOWHIGHTH_ = PITCHENDNUMTH_ +1;     // high freq energy vs low freq energy, 0.8 (float)
	 static final int MINSIGLEN_ = LOWHIGHTH_ +1;     // min signal length for speech, 10 (int)
	 static final int MAXSILLEN_ = MINSIGLEN_ +1;     // max silence length, 30 (int)
	 static final int SINGLEMAX_ = MAXSILLEN_ +1;     // max single point max in spectral, 50 (float)
	 static final int NOISE2YTH_ = SINGLEMAX_ +1;     // gloable noise to signal value threshold, 0.5 (float)
	 static final int NOISE2YTHVOWEL_ = NOISE2YTH_ +1;// gloable noise to signal value threshold for vowel part, 0.1 (float)
	 static final int VOICEPROBTH_ = NOISE2YTHVOWEL_ +1;   // voice freq domain prob Th, 0.7 (float)
	 static final int USEPEAK_ = VOICEPROBTH_ +1;       // use pitch or peak, 0 for pitch, other for peak, 0 (int)
	 static final int NOISE2YST_ = USEPEAK_ +1;     // noise to y ratio, start point in freq domain, 10 (int)
	 static final int RESET_FEND_ = NOISE2YST_ +1;    // reset type, use this when a file is end, or a voice stream is end.
	 static final int RESET_VEND_ = RESET_FEND_ +1;    // reset type, use this when detect a voice end point.
	 static final int PITCHLASTTH_ = RESET_VEND_ +1;    // the pitch last number for speech re-apear, which for transition section or tail, 3 (int)
	
	 public class VADParamValue {
		String value = null;
		public int key = 0;
		
		public VADParamValue(int key) {
			this.key = key;
		}
		public void reset() {
			disable();
		}

		public void disable() {
			value = null;
		}

		public boolean isEnabled() {
			return value != null;
		}

		public String toString() {
			return value;
		}
	}

	public class VADParamValueInt extends VADParamValue {
		
		public VADParamValueInt(int key) {
			super(key + INT_OFFSET);
		}
		
		public void setValue(int value) {
			this.value = value + "";
		}

	}

	public class VADParamValueFloat extends VADParamValue {
		
		public VADParamValueFloat(int key) {
			super(key + FLOAT_OFFSET);
		}
		
		public void setValue(float value) {
			this.value = value + "";
		}
	}
	
	

	public VADParamValueFloat MINBACKENG = new VADParamValueFloat(MINBACKENG_); // min back
																		// energy,
																		// default
																		// 5e6
																		// (float)
	public VADParamValueFloat MINBACKENGH = new VADParamValueFloat(MINBACKENGH_); // min
																		// back
																		// energy
																		// higher
																		// TH,
																		// just
																		// larger
																		// than
																		// this,
																		// may
																		// voice
																		// occur,
																		// 5e8(for
																		// very
																		// noise,
																		// if
																		// voice
																		// is
																		// good,
																		// set
																		// it
																		// low,
																		// like
																		// 5e6)
																		// (float)
	public VADParamValueFloat PITCHTH = new VADParamValueFloat(PITCHTH_); // pitch
																	// threshold,
																	// 0.7
																	// (float)
	public VADParamValueInt PITCHSTNUMTH = new VADParamValueInt(PITCHSTNUMTH_); // pitch
																	// persist
																	// length
																	// for start
																	// usage, 8
																	// (int)
	public VADParamValueInt PITCHENDNUMTH = new VADParamValueInt(PITCHENDNUMTH_); // pitch
																	// drop
																	// length
																	// for end
																	// usage, 50
																	// (int)
	public VADParamValueFloat LOWHIGHTH = new VADParamValueFloat(LOWHIGHTH_); // high freq
																	// energy vs
																	// low freq
																	// energy,
																	// 0.8
																	// (float)
	public VADParamValueInt MINSIGLEN = new VADParamValueInt(MINSIGLEN_); // min signal
																// length for
																// speech, 10
																// (int)
	public VADParamValueInt MAXSILLEN = new VADParamValueInt(MAXSILLEN_); // max silence
																// length, 30
																// (int)
	public VADParamValueFloat SINGLEMAX = new VADParamValueFloat(SINGLEMAX_); // max
																	// single
																	// point max
																	// in
																	// spectral,
																	// 50
																	// (float)
	public VADParamValueFloat NOISE2YTH = new VADParamValueFloat(NOISE2YTH_); // gloable
																	// noise to
																	// signal
																	// value
																	// threshold,
																	// 0.5
																	// (float)
	public VADParamValueFloat NOISE2YTHVOWEL = new VADParamValueFloat(NOISE2YTHVOWEL_);// gloable
																		// noise
																		// to
																		// signal
																		// value
																		// threshold
																		// for
																		// vowel
																		// part,
																		// 0.1
																		// (float)
	public VADParamValueFloat VOICEPROBTH = new VADParamValueFloat(VOICEPROBTH_); // voice
																		// freq
																		// domain
																		// prob
																		// Th,
																		// 0.7
																		// (float)
	public VADParamValueInt USEPEAK = new VADParamValueInt(USEPEAK_); // use pitch or
																// peak, 0 for
																// pitch, other
																// for peak, 0
																// (int)
	public VADParamValueInt NOISE2YST = new VADParamValueInt(NOISE2YST_); // noise to y
																// ratio, start
																// point in freq
																// domain, 10
																// (int)
	public VADParamValueInt PITCHLASTTH = new VADParamValueInt(PITCHLASTTH_); // the pitch
																	// last
																	// number
																	// for
																	// speech
																	// re-apear,
																	// which for
																	// transition
																	// section
																	// or tail,
																	// 3 (int)
	
	/** front是300帧(3秒) */
	public static final int DEFAULT_FRONT_SIL = 3000;
	/** back是100帧(1秒)*/
	public static final int DEFAULT_BACK_SIL = 1000;
	
	/**
	 * 语音采样率
	 */
	public static final int FREQUENCY_16K = 16000;
	
	public static final int FREQUENCY_8K = 8000;
	
	/**
	 * 缓冲语音数据长间(ms)
	 */
	public static final int DEFAULT_CACHE_PCM_TIME = 450;
	
	boolean isFrontVadEnabled = false;
	boolean isPlayStartBeep = true;
	int sampleRateInHz = FREQUENCY_16K;
	int frontSil = DEFAULT_FRONT_SIL;
	int backSil = DEFAULT_BACK_SIL;
	int pcmCacheByteSize = 0;
	int checkBeepCacheByteSize = 38000;
	
	/**
	 * 是否使用远讲
	 */
	protected boolean isFarFeildEnabled = false;
	private int giveUpResultMinMillisecond = 350;
	public boolean is8K216K =false;

	/**
	 * 录音线程VAD是否可用
	 */
	private boolean isVADEnabled = true;
	
	
	int recordingAudioSource = MediaRecorder.AudioSource.DEFAULT;
	int recordingSampleRate = VADParams.FREQUENCY_16K;
	
	
	public int getAudioSource() {
		return recordingAudioSource;
	}
	public void setAudioSource(int audioSource) {
		this.recordingAudioSource = audioSource;
	}
	
	public int getRecordingSampleRate() {
		
		int frequency = recordingSampleRate;
		if(is8K216K) {
			frequency = VADParams.FREQUENCY_8K;
		}

		return frequency;
	}
	
	
	public void setRecordingSampleRate(int sampleRate) {
		this.recordingSampleRate = sampleRate;
	}
	
	
	
	public VADParams () {
		setFrontCacheTime(DEFAULT_CACHE_PCM_TIME);
		setVADModelToDefault();
	}
	
	/**
	 * 放弃识别结果的最小语音时间
	 * @param ms
	 */
	public void setGiveUpResultMinMillisecond( int ms) {
		giveUpResultMinMillisecond = ms;
	}
	
	public int getGiveUpResultMinMillisecond() {
		return giveUpResultMinMillisecond;
	}
	
	/**
	 * 是否使用远讲
	 * @return 是 true, 否 false
	 */
	public boolean isFarFeildEnabled() {
		return isFarFeildEnabled;
	}
	
	/**
	 * 是否使用远讲
	 * @return 是 true, 否 false
	 */
	public void setFarFeildEnabled(boolean enabled) {
		isFarFeildEnabled = enabled;
	}
	
	
	
	public void setVADTimeout(int frontSil, int backSil) {
		
		MAXSILLEN.setValue(backSil/10); // backSil/10 ms to frame
		this.frontSil = frontSil;
		this.backSil = backSil;
	}

	
	public void setFrontCacheTime(int nTime) {
		
		if (nTime < 100) {
			nTime = 100;
		}

		pcmCacheByteSize = sampleRateInHz / 1000 * nTime * 2;
	
	}
	
	public void setFrontVadEnabled(boolean enabled) {
		this.isFrontVadEnabled = enabled;
	}


	public boolean isFrontVadEnabled() {
		return isFrontVadEnabled;
	}

	public boolean isPlayStartBeep() {
		return isPlayStartBeep;
	}
	
	public boolean isCheckBeep() {
		return isPlayStartBeep;
	}
	
	public void setPlayStartBeep(boolean enabled) {
		this.isPlayStartBeep = enabled;
	}
	
	/**
	 *  设置录音线程VAD是否启用
	 * @param enabled
	 */
	public void setVADEnabled(boolean enabled) {
		isVADEnabled = enabled;
	}
	
	/**
	 * 获取录音线程VAD是否启用
	 * @return
	 */
	public boolean isVADEnabled() {
		return isVADEnabled;
	}


	public void resetVAD() {
		MINBACKENG.reset();    // min back energy, default 5e6 (float)
		MINBACKENGH.reset();   // min back energy higher TH, just larger than this, may voice occur, 5e8(for very noise, if voice is good, set it low, like 5e6) (float)
		PITCHTH.reset();       // pitch threshold, 0.7 (float)
		PITCHSTNUMTH.reset();  // pitch persist length for start usage, 8 (int)
		PITCHENDNUMTH.reset(); // pitch drop length for end usage, 50 (int)
		LOWHIGHTH.reset();     // high freq energy vs low freq energy, 0.8 (float)
		MINSIGLEN.reset();     // min signal length for speech, 10 (int)
		MAXSILLEN.reset();     // max silence length, 30 (int)
		SINGLEMAX.reset();     // max single point max in spectral, 50 (float)
		NOISE2YTH.reset();     // gloable noise to signal value threshold, 0.5 (float)
		NOISE2YTHVOWEL.reset();// gloable noise to signal value threshold for vowel part, 0.1 (float)
		VOICEPROBTH.reset();   // voice freq domain prob Th, 0.7 (float)
		USEPEAK.reset();       // use pitch or peak, 0 for pitch, other for peak, 0 (int)
		NOISE2YST.reset();     // noise to y ratio, start point in freq domain, 10 (int)
		PITCHLASTTH.reset();    // the pitch last number for speech re-apear, which for transition section or tail, 3 (int)
	}


	/**
	 *  强噪声、强语音音量参数设置
	 */
	public void setVADModelToStrongNoiseOrVoice() {
		resetVAD();
		NOISE2YTHVOWEL.setValue(0.7f);
		NOISE2YTH.setValue(1.0f);
		PITCHTH.setValue(0.22f);
		PITCHSTNUMTH.setValue(5);
		VOICEPROBTH.setValue(0.6f);
		USEPEAK.setValue(1);
		NOISE2YST.setValue(3);
		MINBACKENG.setValue(2E8f);
		SINGLEMAX.setValue(80);
		LOWHIGHTH.setValue(1e6f);
		PITCHLASTTH.setValue(1);
	}

	/**
	 * 安静环境设置 A
	 */
	public void setVADModelToQuietEnvironmentA() {
		resetVAD();
		MINBACKENGH.setValue(5e6f);
		PITCHSTNUMTH.setValue(6);
	}

	
	/**
	 * 安静环境设置 Default
	 */
	public void setVADModelToDefault() {
		resetVAD();
		MINBACKENGH.setValue(5e6f);
		PITCHSTNUMTH.setValue(6);
		PITCHENDNUMTH.setValue(0);
	}
	
	/**
	 * 安静环境设置 B
	 */
	public void setVADModelToQuietEnvironmentB() {
		resetVAD();
		PITCHTH.setValue(0.22f);
		PITCHSTNUMTH.setValue(5);
		VOICEPROBTH.setValue(0.7f);
		USEPEAK.setValue(1);
		MINBACKENGH.setValue(5e6f);
	}

	/**
	 * 乐视VAD（过滤小音量语音），前端需缓存350ms语音
	 */
	public void setVADModelToLetv() {
		resetVAD();

//		MINBACKENG.setValue(3e7f);
//		PITCHTH.setValue(0.22f);
//		VOICEPROBTH.setValue(0.7f);
		
//		USEPEAK.setValue(1);
		// zhangjun,2014-12-04 
//		MINBACKENGH.setValue(3e8f);
//		PITCHSTNUMTH.setValue(5);
//		MAXSILLEN.setValue(40);
		
		// john@yunzhisheng.cn 2014-12-23 updata
//		MINBACKENGH.setValue(5e6f); 
//		PITCHSTNUMTH.setValue(6); 
//		PITCHENDNUMTH.setValue(50);
		
		// •zhangjun,2014-12-25 更新乐视VAD参数（过滤小音量语音，299条测试集292条正确）
		// 前端需缓存450ms语音
		MINBACKENGH.setValue(5e6f);
		MAXSILLEN.setValue(50);
		PITCHSTNUMTH.setValue(6);
		PITCHLASTTH.setValue(1);
		
	}
}