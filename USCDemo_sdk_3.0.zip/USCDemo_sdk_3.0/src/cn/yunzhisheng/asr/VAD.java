package cn.yunzhisheng.asr;

import java.io.ByteArrayOutputStream;
import java.util.LinkedList;
import java.util.List;

import cn.yunzhisheng.asr.VADParams.VADParamValue;

import com.unisound.sdk.VADListener;
import com.unisound.common.LogUtil;

public class VAD {

	public static final int ERROR_UNINITIALIZED = -1;
	
	/**
	 * 近讲状态标记 与JNI 内接口数值对应
	 */
	private static final int DEFAULT_VAD_TYPE = 0;

	/**
	 * 远讲状态标记 与JNI 内接口数值对应
	 */
	private static final int FAR_FEILD_VAD_TYPE = 1;

	/**
	 * 设置远、近讲状态 与JNI 内接口数值对应
	 */
	private static final int SET_TIME_VAD_TYPE_ID = -1001;

	/**
	 * 0表示什么都不做 与JNI内接口数值对应
	 */
	public static final int ASR_VAD_HOLDING = 0;

	/**
	 * 1，2都表示超时了 与JNI 内接口数值对应
	 */
	public static final int ASR_VAD_BACK_END = 1;
	public static final int ASR_VAD_MAX_SIL = 2;
	/**
	 * 3表示找到前端点 与JNI 内接口数值对应
	 */
	public static final int ASR_VAD_FRONT_END = 3;

	private native long create();

	private native void init(long handle);

	private native void reset(long handle);

	private native int isVADTimeout(long handle, byte[] pcm, int len);

	private native int getVolume(long handle);

	public native void setTime(long handle, int frontSil, int backSil);

	private native void destory(long handle);

	private native int checkPitchOffset(long handle, byte[] pcm, int len);

	private native int nativeSetOption(long handle, int key, String value);
	
//	private int nativeSetOption(long handle, int key, String value){
//		return 0;
//	}
	
	// ------------------ add beep check
	// 2014-02-08-----------------------------------

	private ByteArrayOutputStream cacheBytes = new ByteArrayOutputStream(
			1024 * 20);
	public static int noisePostion = 0;
	private VADParams mParams;
	// ---------------------------------------------------------------------

	List<byte[]> pcmCacheList = new LinkedList<byte[]>();
	private VADListener listener;

	private boolean isCheckBeepOver = false;
	private boolean isFarVadEnabled = false;
	private boolean isBegin = false;
	private long handle = 0;
	private boolean enabled = true;

	public void setEnabled(boolean enabled){
		this.enabled = enabled;
	}

	public VAD(VADParams params, VADListener listener) {

		this.mParams = params;
		this.listener = listener;
		handle = create();
		if (handle == 0) {
			LogUtil.e("jni VAD create fail!");
			return;
		}
		this.setEnabled(mParams.isVADEnabled());
		init(handle);
	}

	public boolean isInit() {
		return (handle != 0);
	}

	

	public int setOption(VADParamValue value) {
		
		if(!value.isEnabled()) {
			return 0;
		}
		return setOption(value.key, value.toString());
	}
	
	public int setOption(int key, String value) {
		if (handle == 0) {
			return ERROR_UNINITIALIZED;
		}
		
		if( value == null) {
			return 0;
		}
		
		
		if(value.length() == 0) {
			return 0;
		}
		
		return nativeSetOption(handle, key, value);
	}
	
	/**
	 * 设置远讲VAD 是否可用
	 * 
	 * @param enabled
	 */
	private void setFarVadEnabled(boolean enabled) {

		if (enabled == isFarVadEnabled) {
			return;
		}

		if (!isInit()) {
			return;
		}

		isFarVadEnabled = enabled;
//		if (isFarVadEnabled) {
//			// 远讲状态标记
//			setTime(handle, SET_TIME_VAD_TYPE_ID, FAR_FEILD_VAD_TYPE);
//		} else {
//			// 近讲状态标记
//			setTime(handle, SET_TIME_VAD_TYPE_ID, DEFAULT_VAD_TYPE);
//		}
	}

	public int checkPitchOffset(byte[] pcm, int len) {
		if (!isInit()) {
			return 0;
		}

		return checkPitchOffset(handle, pcm, len);
	}

	public void init_() {
		setFarVadEnabled(mParams.isFarFeildEnabled());
		setTime(mParams.frontSil, mParams.backSil);
		setOption(mParams.MINBACKENG);    // min back energy, default 5e6 (float)
		setOption(mParams.MINBACKENGH);   // min back energy higher TH, just larger than this, may voice occur, 5e8(for very noise, if voice is good, set it low, like 5e6) (float)
		setOption(mParams.PITCHTH);       // pitch threshold, 0.7 (float)
		setOption(mParams.PITCHSTNUMTH);  // pitch persist length for start usage, 8 (int)
		setOption(mParams.PITCHENDNUMTH); // pitch drop length for end usage, 50 (int)
		setOption(mParams.LOWHIGHTH);     // high freq energy vs low freq energy, 0.8 (float)
		setOption(mParams.MINSIGLEN);     // min signal length for speech, 10 (int)
		setOption(mParams.MAXSILLEN);     // max silence length, 30 (int)
		setOption(mParams.SINGLEMAX);     // max single point max in spectral, 50 (float)
		setOption(mParams.NOISE2YTH);     // gloable noise to signal value threshold, 0.5 (float)
		setOption(mParams.NOISE2YTHVOWEL);// gloable noise to signal value threshold for vowel part, 0.1 (float)
		setOption(mParams.VOICEPROBTH);   // voice freq domain prob Th, 0.7 (float)
		setOption(mParams.USEPEAK);       // use pitch or peak, 0 for pitch, other for peak, 0 (int)
		setOption(mParams.NOISE2YST);     // noise to y ratio, start point in freq domain, 10 (int)
//		setOption(mParams.RESET_FEND);    // reset type, use this when a file is end, or a voice stream is end.
//		setOption(mParams.RESET_VEND);    // reset type, use this when detect a voice end point.
		setOption(mParams.PITCHLASTTH); 		
	}

	public int getVolume_() {
		if (!isInit()) {
			return 0;
		}

		return getVolume(handle);
	}

	public int checkPCM(byte[] pcm, int len) {

		if (handle == 0) {
			return ASR_VAD_HOLDING;
		}

		return isVADTimeout(handle, pcm, len);
	}

	public void setTime(int frontSil, int backSil) {
		if (!isInit()) {
			return;
		}
		frontSil /= 10;
		backSil /= 10;
		setTime(handle, frontSil, backSil);
	}

	public void reset() {
		isBegin = false;
		isCheckBeepOver = false;
		pcmCacheList.clear();
		cacheBytes.reset();

		if (!isInit()) {
			return;
		}
		reset(handle);
	}

	public void destory() {

		if (!isInit()) {
			return;
		}

		destory(handle);
		handle = 0;
	}

	private void log_v(String log) {

		LogUtil.v("VAD >>" + log);
	}

	protected int getVolume(byte[] buffer, int len) {
		float volume = 0;
		for (int i = 0; i < len; i += 2) {
			int v1 = buffer[i] & 0xFF;
			int v2 = buffer[i + 1] & 0xFF;
			int temp = v1 + (v2 << 8);
			if (temp >= 0x8000) {
				temp = 0xffff - temp;
			}
			volume += Math.abs(temp);
		}
		volume = volume * 2 / len;
		int value = (int) ((10.0 * Math.log10(1 + volume) - 20) * 5);

		// LogUtil.v("value =" + value);
		value = value < 0 ? 0 : value;
		value = value > 100 ? 100 : value;
		return value;
	}

	private int pcm8kTo16k(byte[] src, int srcLength, byte[] out, int outLength) {

		int len8k = srcLength;
		int index = 0;
		int pcmIndex = 0;

		while (index < len8k - 1) {
			byte sl = src[index++];
			byte sh = src[index++];
			out[pcmIndex++] = sl;
			out[pcmIndex++] = sh;
			out[pcmIndex++] = sl;
			out[pcmIndex++] = sh;
		}

		return pcmIndex;
	}

	/**
	 * vad 处理语音数据
	 * 
	 * @param src
	 * @param offset
	 * @param lenght
	 */
	public int write(byte[] src, int offset, int length) {
		
		int status = ASR_VAD_HOLDING;
		if (length <= 0) {
			return status;
		}
		
		if(enabled == false) {
			onRecordingData(true, src, 0, length);
			onUpdateVolume(getVolume_());		
			return status;
		}

		byte[] pcm = null;
		if (!mParams.is8K216K) {
			pcm = src;
			// pcm = new byte[length];
			// System.arraycopy(src, offset, pcm, 0, length);
		} else {

			int pcm16kLength = length * 2;
			pcm = new byte[pcm16kLength];
			length = pcm8kTo16k(src, length, pcm, pcm16kLength);
		}

		if (mParams.isCheckBeep() && !isCheckBeepOver) {
			// 提示音检测处理
			frontCheckPitch(pcm);
			onUpdateVolume(getVolume(pcm, length));
		} else {
			// vad 检测处理

			status = checkPCM(pcm, length);
			if (status == ASR_VAD_HOLDING) {
				// log_v("ASR_VAD_HOLDING");
			} else if (status == ASR_VAD_BACK_END) {
				onVADTimeout();
				log_v("ASR_VAD_BACK_END");
			} else if (status == ASR_VAD_MAX_SIL) {
				onVADTimeout();
				log_v("ASR_VAD_MAX_SIL");
			} else if (status == ASR_VAD_FRONT_END) {
				isBegin = true;
				log_v("ASR_VAD_FRONT_END");
				flush();
				onSpeechStart();
			}
			if (!isBegin && mParams.isFrontVadEnabled) {
				// 前端VAD 处理
				checkFrontVad(pcm);
			} else {
				onRecordingData(true, pcm, 0, length);
			}

			onUpdateVolume(getVolume_());
		}
		
		return status;
	}

	private void onRecordingData(boolean enabled, byte[] data, int offset,
			int lenght) {
		VADListener ls = listener;
		if (ls != null) {
			ls.onRecordingData(enabled, data, offset, lenght);
		}
	}

	private void onSpeechStart() {

		VADListener ls = listener;
		if (ls != null) {
			ls.onSpeechStart();
		}
	}

	private void onUpdateVolume(int volume) {

		VADListener ls = listener;
		if (ls != null) {
			ls.onUpdateVolume(volume);
		}
	}

	private void onVADTimeout() {
		VADListener ls = listener;
		if (ls != null) {
			ls.onVADTimeout(this);
		}
	}

	public void flush() {

		if (cacheBytes.size() > 0) {
			onRecordingData(isBegin, cacheBytes.toByteArray(), 0,
					cacheBytes.size());
			cacheBytes.reset();
		}

		int size = pcmCacheList.size();
		for (int i = 0; i < size; i++) {
			byte[] buffer = pcmCacheList.remove(0);
			onRecordingData(isBegin, buffer, 0, buffer.length);
		}
		//音量归零回调
		onUpdateVolume(0);
	}

	/**
	 * 对语音缓冲
	 * 
	 * @param pcm
	 */
	protected void frontCheckPitch(byte[] pcm) {

		cacheBytes.write(pcm, 0, pcm.length);

		if (cacheBytes.size() >= mParams.checkBeepCacheByteSize) {
			byte[] cache = cacheBytes.toByteArray();
			cacheBytes.reset();

			int offset = checkPitchOffset(handle, cache, cache.length);
			if (offset > 0) {
				LogUtil.v("checkPitchOffset:" + offset);
				byte[] cut = new byte[offset];
				System.arraycopy(cache, 0, cut, 0, offset);
				onRecordingData(false, cut, 0, cut.length);

				cacheBytes.write(cache, offset, cache.length - offset);
				cache = cacheBytes.toByteArray();
				cacheBytes.reset();
			}
			noisePostion = offset;
			if (cache.length > 0) {

				onRecordingData(true, cache, 0, cache.length);
				checkPCM(cache, cache.length);
			}
			isCheckBeepOver = true;
			isBegin = true;
		}
	}

	/**
	 * 对语音缓冲
	 * 
	 * @param pcm
	 */
	private void checkFrontVad(byte[] pcm) {

		pcmCacheList.add(pcm);
		int pcmSize = 0;
		int enabled = 0;
		// 得到缓冲数据位置
		for (int i = pcmCacheList.size() - 1; i >= 0; i--) {
			byte[] buffer = pcmCacheList.get(i);
			pcmSize += buffer.length;
			if (pcmSize >= mParams.pcmCacheByteSize) {
				enabled = i;
				break;
			}
		}

		// 超出缓冲回写
		for (int i = 0; i < enabled; i++) {
			byte[] buffer = pcmCacheList.remove(0);
			onRecordingData(false, buffer, 0, buffer.length);
		}
	}
}
