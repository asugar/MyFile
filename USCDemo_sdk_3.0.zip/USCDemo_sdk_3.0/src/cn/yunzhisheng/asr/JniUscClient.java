package cn.yunzhisheng.asr;

public class JniUscClient {

	
	// SUCC_CODE
	public static final int ASRCLIENT_RECOGNIZER_OK = 0;
	public static final int ASRCLIENT_CREATE_SERVICE_OK = 0;
	public static final int ASRCLIENT_START_SESSION_OK = 0;
	public static final int ASRCLIENT_RECOGNIZER_NO_RESULT = 1;
	public static final int ASRCLIENT_RECOGNIZER_PARTIAL_RESULT = 2;
	
	
	//HTTP method error code
	public static final int ASRCLIENT_INIT_ERROR = -91000;
	public static final int ASRCLIENT_NOT_INIT_ERROR = -91001;
	public static final int ASRCLIENT_REQ_INIT_ERROR = -91002;
	public static final int ASRCLIENT_NETWORK_ERROR = -91003;
	public static final int ASRCLIENT_HTTP_REQ_ERROR = -91004;
	public static final int ASRCLIENT_DECODE_ERROR = -91005;
	public static final int ASRCLIENT_NO_START_ERROR = -91006;
	public static final int ASRCLINET_TEXT_NULL_ERROR = -91131;
	public static final int ASRCLIENT_TEXT_TOO_LONG_ERROR = -91132;
	public static final int ASRCLIENT_SET_SERVICE_ERROR = -91133;
	public static final int ASRCLIENT_GET_INFO_ERROR = -91134;
	public static final int ASRCLIENT_NO_SUPPORT_FORMAT_ERROR = -91135;
	public static final int ASRCLIENT_NO_SUPPORT_CODEC_ERROR =-91136;
	public static final int ASRCLIENT_SER_IP_ADDRESS_ERROR = -91137;
	public static final int ASRCLIENT_HANDLE_ERROR = -91138;
	public static final int ASRCLIENT_SET_PROPETY_ERROR = -91139;
	public static final int ASRCLIENT_NO_DARA_ERROR = -91140;
	public static final int ASRCLIENT_TOKEN_CREATE_ERROR = -91141;
	public static final int ASRCLIENT_OPTION_ID_ERROR = -91151;
	public static final int ASRCLIENT_OPTION_PARAM_ERROR = -91152;
	public static final int ASRCLIENT_APPKEY_ERROR = -91725;
	public static final int ASRCLIENT_NO_SESSION_ID_ERROR = -91735;
	public static final int ASRCLIENT_NO_SERVICE_CONNECT = -91721;
	public static final int ASRCLIENT_NO_CARRY_KEY_INFO = -91722;
	public static final int ASRCLIENT_NO_SUPPORT_SERVICE = -91723;
	public static final int ASRCLIENT_REQ_INFO_LOSE = -91724;
    public static final int ASRCLIENT_NO_CARRY_SESSIONID = -91730;
    public static final int ASRCLIENT_TOKEN_VALIDATION_ERROR = -91731;
    public static final int ASRCLIENT_SERVER_LOAD = -91732;
    public static final int ASRCLIENT_NO_ENCRYPTION_NO_SESSIONID = -91733;
    public static final int ASRCLIENT_REQUESTSERVICE_NO_SESSIONID = -91734;
    public static final int ASRCLIENT_NO_SESSIONID = -91735;
    public static final int ASRCLIENT_SERVER_ERROR = -91739;
	

	//public class INPUT_CHECKER_ERR{
	public static final int ASRCLIENT_VAD_TIMEOUT = -30001;
	public static final int ASRCLIENT_MAX_SPEECH_TIMEOUT = -30002;
	public static final int ASRCLIENT_COMPRESS_PCM_ERROR = -30003;
	public static final int ASRCLIENT_INVALID_PARAMETERS = -30004;

	// VPR params
	public static final int VPR_PARAMS = 1002;
	public static final int VPR_INIT = 1015;
	public static final int VPR_SEND_PARAMS = 1005;
	public static final int VPR_MD5_CHECK = 1020;
	public static final int VPR_OPT_SECRET = 1019;
	public static final int VPR_SERVER_SINGNER_ERROR = -91154;
	public static final int VPR_SDK_SINGNER_ERROR = -91727;

	
	public static int state = 0;
	public static int erron = 0;
	
	public void setState(int code) {
		
		state = code;		
		if(state < 0){
			erron = getLastErrorCode();
		}
		else {
			erron = 0;
		}
	}

	public static final String ASR_OPT_AUDIO_ENCODE_OUPS_16K = "opus";
	public static final String ASR_OPT_AUDIO_ENCODE_OUPS_8K = "opus-nb";	
	public static final String ASR_OPT_RSP_ENTITY = "req_audio_url";
	public static final String ASR_OPT_TEMP_RESULT_ENABLED = "get_variable";
	
	public static final String ASR_USRDATA_FLAG_OPEN = "open";	
	public static final String ASR_USRDATA_FLAG_CLOSE = "close";
	
	//id of setValue()
	public static final int ASR_OPT_ENABLE_VAD 				= 0;	// 0 OR 1, default value 0 (disable)
	public static final int ASR_OPT_VAD_TIMEOUT 			= 1;	// only valid when vad is enabled, from 2000 to 10000, default value 3000	(means 3000ms)
	public static final int ASR_OPT_MAX_SPEECH_TIMEOUT 		= 2;	// from 10 to 600, default value 60	(means 60s)
	public static final int ASR_OPT_SERVICE_TIMEOUT		 	= 3;	// 0 means always wait, default value 20 (means 20s)
	public static final int ASR_OPT_RESULT_TIMEOUT		 	= 4;	// 0 means always wait, default value 30 (means 30s)
	public static final int ASR_OPT_RESULT_FORMAT 			= 5;	// default value 0 ( 0 means "text", 1 means "json")
	public static final int ASR_OPT_PCM_COMPRESS 			= 6;	// from 0 to 10, default value 8
	public static final int ASR_OPT_DISABLE_PARTIAL_RESUL 	= 7;	// 0 OR 1, default value 0
	public static final int ASR_OPT_DEVICE_IMEI				= 8;
    public static final int ASR_OPT_SERVICE_KEY 			= 9;
    //public static final int ASR_OPT_LANGUAGE_DOMAIN			= 10;
    public static final int ASR_OPT_PACKAGE_NAME            = 10;
    public static final int	ASR_OPT_DEVICE_OS               = 11;
    public static final int ASR_OPT_CARRIER                 = 12;
    public static final int	ASR_OPT_NETWORK_TYPE            = 13;
    public static final int ASR_USER_ID                     = 14;
    public static final int	ASR_OPT_COLLECTED_INFO          = 15;
    public static final int	ASR_AUDIO_ENCODE_MTD            = 16;
    public static final int ASR_REQ_RSP_ENTITY              = 17;
    public static final int ASR_MODLE_TYPE                  = 18;
    public static final int ASR_AUDIO_ENCODE_MTD8K			= 19;
    public static final int ASR_SCENE_ID =  0x1F;
    public static final int SSUP_RSP_AUDIO_URL 				= 0x15;  // SSUP_RSP_AUDIO_URL
    public static final int SSUP_MODEL_TYPE 				= 0x16;
    public static final int SSUP_RSP_SPEAKER_INFO			= 0x19;
    public static final int SSUP_RSP_REQUEST_ID 			= 0x1A;  // 2014-06-23 ADD GET 
    public static final int ASR_DOMAIN_DEFAULT				= 0;
    public static final int ASR_DOMAIN_POI					= 1;
    public static final int ASR_USRDATA_FLAG				= 0x14;
    public static final int ASR_OPT_NET_PACKAGE_SIZE        = 21;    
    public static final int ASR_REQ_SPEAKER_INFO        	= 32;
    public static final int ASR_REDIS_DATA_VERSION          = 33;
	public static final int ASR_ENGINE_PARAMETER            = 34;
	public static final int ASR_RESULT_PARAMETER 	        = 35; 
	
    public static final int ASR_ORAL_EVAL_TEXT              = 0x17;
    public static final int ASR_ORAL_TASK_TYPE			    = 0x1A;
    public static final int ASR_ORAL_CONF_OP1			    = 0x1B;
    public static final int	ASR_ORAL_CONF_OP2			    = 0x1C;
	public static final int SSUP_RSP_RESULT_PARAMETER       = 0x22; //used to return the variable result or other parameter related to the result

	public static final int ASR_NLU_PARAMETER = 1005;
	
    // device OS
    public static final int DEVICE_OS_Android = 0;
    public static final int DEVICE_OS_iOS = 1;
        
    // network type
    public static final int NETWORK_TYPE_NONE = 0;
    public static final int NETWORK_TYPE_WIFI = 1;
    public static final int NETWORK_TYPE_3G = 2;
    public static final int NETWORK_TYPE_2G = 3;
    public static final int NETWORK_TYPE_MOBILE = 4;
	
    /**
     * 网络类型ToString
     * @param type
     * @return
     */
	public static String networkTypeToString(int type )	{
		switch(type) {
		case NETWORK_TYPE_NONE: return "NETWORK_TYPE_NONE";
		case NETWORK_TYPE_WIFI: return "NETWORK_TYPE_WIFI";
		case NETWORK_TYPE_3G: return "NETWORK_TYPE_3G";
		case NETWORK_TYPE_2G: return "NETWORK_TYPE_2G";
		case NETWORK_TYPE_MOBILE: return "NETWORK_TYPE_MOBILE";
		}
		return "NETWORK_TYPE_NONE";
	}
	
    private long handle = 0;

	// public methods
	public long create(String ip, int port) {
        if (handle == 0) {
            handle = createNative(ip, port);
        }
        return handle;
    }

	public int setOptionInt(int id, int value) {
        if (handle != 0) {
            return setOptionInt(handle, id, value);
        } else {
            return -1;
        }
    }

	public int setOptionString(int id, String s) {
        if (handle != 0) {
            return setOptionString(handle, id, s);
        } else {
            return -1;
        }
    }

	public int start() {
        if (handle != 0) {
            int ret = start(handle);
            setState(ret);
            return ret;
        } else {
            return -1;
        }
    }

	public int recognize(byte[] sample, int len) {
        if (handle != 0) {
            int ret = recognize(handle, sample, len);
            setState(ret);
            return ret;        
        } else {
            return -1;
        }
    }

	public int stop() {
        if (handle != 0) {
            int ret = stop(handle);
            setState(ret);
            return ret;            
        } else {
            return -1;
        }
    }

	public String getResult() {
        if (handle != 0) {
            return getResult(handle);
        } else {
            return "";
        }
    }

	public int cancel() {
        if (handle != 0) {
            return cancel(handle);
        } else {
            return 0;
        }
    }

	
	public String getOptionValue(int id){
        if (handle != 0) {
        	return getOptionValue(handle,id);
        }
        return "";	
	}

	
	public void destroy() {
        if (handle != 0) {
            destroyNative(handle);
            handle = 0;
        }
    }
	
	public int  getLastErrorCode(){
		
        if (handle != 0) {
        	return getLastErrno(handle);

        }	
        return 0;
	}
	
	public int setTempResultEnabled(boolean enabled) {
    	if(enabled) {
    		return setOptionString(JniUscClient.ASR_RESULT_PARAMETER, JniUscClient.ASR_OPT_TEMP_RESULT_ENABLED);
    	}
    	return ASRCLIENT_RECOGNIZER_OK;
    }
	

	//native function
	private native long createNative(String ip, int port);
	private native int setOptionInt(long handle, int id, int value);
	private native int setOptionString(long handle, int id, String s);
	private native int start(long handle);
//	private native int isactive(long handle, byte[] sample, int len);
	private native int recognize(long handle, byte[] sample, int len);
	private native int stop(long handle);
	private native String getResult(long handle);
	private native int cancel(long handle);
	private native void destroyNative(long handle);
	private native int getLastErrno(long handle);
	private native String getOptionValue(long handle,int id);
	
	/*static {
		System.loadLibrary("usc");
	}*/
}
