package cn.yunzhisheng.tts;


public class JniClient {

	@Override
	protected void finalize() throws Throwable {
		release();
		super.finalize();
	}

	   // device OS
    public static final int DEVICE_OS_Android = 0;
    public static final int DEVICE_OS_iOS = 1;

    public static int state = 0;
	public static int erron = 0;

	public static final int SUCCESS = 0;
	
	public static final int TTS_OPT_DEVICE_IMEI = 8;
	public static final int  TTS_OPT_USER_ID = 14;
    public static final int TTS_OPT_CLIENT_INFO = 15;
    public static final int TTS_OPT_USC_ENGINE_PARAMETER = 104;

	public final static int INIT_ERROR = -91000;// 初始化错误
	public final static int NO_INIT_ERROR = -91001;// 未初始化错误
	public final static int REQ_INIT_ERROR = -91002;// 请求初始化错误
	public final static int NETWORK_ERROR = -91003;// 网络错误
	public final static int HTTP_REQ_ERROR = -91004;// http 协议错误
	public final static int DECODE_ERROR = -91005;// 解码错误

	public final static int TEXT_NULL_ERROR = -91131;// 文本文件为空
	public final static int TEXT_TOO_LONG_ERROR = -91132;// 文本文件过长
	public final static int SET_SERVICE_ERROR = -91133;// 服务设置错误
	public final static int GET_INFO_ERROR = -91134;// 获取信息错误
	public final static int NO_SUPPORT_FORMAT_ERROR = -91135;// 语音格式不支持
	public final static int NO_SUPPORT_CODEC_ERROR = -91136;// 解码格式不支持
	public final static int SER_IP_ADDRESS_ERROR = -91137;// IP 地址设置错误
	public final static int HANDLE_ERROR = -91138;// Handle 错误
	public final static int OPTION_ID_ERROR = -91151;// setOption getOption ID 设置错误
	public final static int OPTION_PARAM_ERROR = -91152;// setOption getOption 参数 设置错误
	public final static int HTTP_ERROR_MIN = -91700;// http 请求错误
	public final static int APPKEY_ERROR = -91725;// Appkey 错误
	public final static int HTTP_ERROR_MAX = -91800;// Appkey 错误

	
	static {
		System.loadLibrary("uscasr");
	}

	
	
	public static String codeToString(int code) {

		switch (code) {
		case SUCCESS: return "操作成功";
		case JniClient.INIT_ERROR : return "初始化错误";
		case JniClient.NO_INIT_ERROR : return "未初始化错误";
		case JniClient.REQ_INIT_ERROR : return "请求初始化错误";
		case JniClient.NETWORK_ERROR : return "网络错误";
		case JniClient.HTTP_REQ_ERROR : return "http 协议错误";
		case JniClient.DECODE_ERROR : return "解码错误";
		case JniClient.TEXT_NULL_ERROR : return "文本文件为空";
		case JniClient.TEXT_TOO_LONG_ERROR : return "文本文件过长";
		case JniClient.SET_SERVICE_ERROR : return "服务设置错误";
		case JniClient.GET_INFO_ERROR : return "获取信息错误";
		case JniClient.NO_SUPPORT_FORMAT_ERROR : return "语音格式不支持";
		case JniClient.NO_SUPPORT_CODEC_ERROR : return "解码格式不支持";
		case JniClient.SER_IP_ADDRESS_ERROR : return "IP 地址设置错误";
		case JniClient.HANDLE_ERROR : return "句柄错误";
		case JniClient.OPTION_ID_ERROR : return " 参数设置 ID 错误";
		case JniClient.OPTION_PARAM_ERROR : return "参数设置ID错误";
		case JniClient.APPKEY_ERROR : return "Appkey 错误";
		default:
			if(HTTP_ERROR_MIN >= code && code > HTTP_ERROR_MAX ) {
				return "网络连接错误";
			}
		}
	
		return null;
	}
	
	public native long nativeCreate(String appkey);

	public native long nativeCreateExt(String appkey, String uri, String port);

	public native int nativeRelease(long handle);

	public native int nativeSetOption(long handle, int option_id, String value);
	
	public native int nativeStart(long handle, String format, String codec);

	public native int nativeStop(long handle);

	public native int nativeTextPut(long handle, String text);

	public native byte[] nativeGetResult(long handle, int[] audioLen,
			int[] synthStatus, int[] errorCode);

	public native String nativeGetOption(long handle, int option_id);

	public static native String nativeGetVersion();

	

	
	private long mHandle = 0;
	private int[] mAudioLen = new int[2];
	private int[] mSynthStatus = new int[2];
	private int[] mErrorCode = new int[2];
	public TtsResultStatus status = new TtsResultStatus();

	public class TtsResultStatus {
		public int mAudioLen = 0;
		public int mSynthStatus = 0;
		public int mErrorCode = 0;
	}

	public boolean isInit() {
		return mHandle != 0;
	}

	public boolean create(String appkey) {
		release();
		mHandle = nativeCreate(appkey);
		return isInit();

	}

	public boolean create(String appkey, String uri, int port) {
		release();
		mHandle = nativeCreateExt(appkey, uri, port + "");
		return isInit();
	}

	public int release() {
		int ret = 0;
		if (isInit()) {
			ret = nativeRelease(mHandle);
			mHandle = 0;
		}
		return ret;
	}

	public int setOption(int option_id, String value) {
		if (isInit()) {

			return nativeSetOption(mHandle, option_id, value);
		}
		return NO_INIT_ERROR;
	}

	public int start(String format, String codec) {
		if (isInit()) {

			return nativeStart(mHandle, format, codec);
		}
		return NO_INIT_ERROR;
	}

	public int stop() {
		if (isInit()) {

			return nativeStop(mHandle);
		}
		return NO_INIT_ERROR;
	}

	public int textPut(String text) {
		if (isInit()) {

			return nativeTextPut(mHandle, text);
		}
		return NO_INIT_ERROR;
	}

	public byte[] getResult() {

		if (isInit()) {
			byte[] ret = nativeGetResult(mHandle, mAudioLen, mSynthStatus,
					mErrorCode);
			status.mAudioLen = mAudioLen[0];
			status.mSynthStatus = mSynthStatus[0];
			status.mErrorCode = mErrorCode[0];

			if (status.mErrorCode == 0) {
				return ret;
			}
		}

		return null;
	}

	public String getOption(int option_id) {
		if (isInit()) {
			return nativeGetOption(mHandle, option_id);
		}
		return "";
	}

	public static String getVersion() {
		return nativeGetVersion();
	}
	
}
