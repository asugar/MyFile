package cn.yunzhisheng.tts.offline.lib;


public class YzsTts {

	/**
	 * 初始化基础句柄
	 * 
	 * @param modelPath
	 *            tts模型所在文件夹路径
	 * @return long 基础句柄 baseHandle
	 */
	private native long createbase(String modelPath);

	/**
	 * 初始化合成句柄
	 * 
	 * @param baseHandle
	 *            基础句柄
	 * @param modelPath
	 *            tts模型所在文件夹路径
	 * @return 合成句柄 ttsHandle
	 */
	private native long create(long baseHandle, String modelPath);

	/**
	 * 销毁基础引擎
	 * 
	 * @param baseHandle
	 */
	private native void releasebase(long baseHandle);

	/**
	 * 销毁合成引擎
	 * 
	 * @param ttsHandle
	 */
	private native void release(long ttsHandle);

	/**
	 * 设置参数
	 * 
	 * @param ttsHandle
	 * @param id
	 * @param value
	 * @return
	 */
	private native int setOption(long ttsHandle, int id, String value);

	/**
	 * 获取相关参数设置
	 * 
	 * @param ttsHandle
	 * @param id
	 * @return
	 */
	private native String getOption(long ttsHandle, int id);

	/**
	 * 处理文本，传入utf8编码的字符
	 * 
	 * @param ttsHandle
	 * @param text
	 * @return 0：成功；非0：失败
	 */
	public native int setText(long ttsHandle, String text);

	/**
	 * 向 setText()过程调用发送放弃标志。使用process 提前推出。
	 * 
	 * @param ttsHandle
	 */
	private native void cancel(long ttsHandle);

	/**
	 * setText TTS 数据回调，数据会写入到audio数组。
	 * 
	 * @param handle
	 * @param audio
	 * @return
	 */
	public native int receiveSamples(long handle, byte[] audio);

	static {
		System.loadLibrary("yzstts");
	}

	public long getTtsHandle() {
		return ttsHandle;
	}

	private static YzsTts mInstance = null;
	// 基础句柄
	private long baseHandle = 0;
	// 合成句柄
	private long ttsHandle = 0;
	// 用于标示是否正在合成状态
	private volatile static boolean isProcessing = false;

	public static YzsTts getInstance() {

		if (mInstance == null) {
			mInstance = new YzsTts();
		}

		return mInstance;
	}

	// 初始化基础句柄
	public boolean initBase(String modelPath, String params) {
		if (baseHandle != 0) {
			releaseBase();
		}
		baseHandle = createbase(modelPath);
		if (baseHandle != 0) {
			return true;
		} else {
			return false;
		}
	}

	// 释放基础句柄
	public void releaseBase() {
		if(baseHandle != 0){
			release(baseHandle);
			baseHandle = 0;
		}
	}

	// 初始化合成句柄 不好的地方在于不知道是因为那个原因引起的初始化合成句柄失败
	public boolean initTts(String modelPath) {
		// 基础句柄是否初始化
		if (baseHandle == 0) {
			return false;
		}
		// 合成句柄是否应经初始化
		if (ttsHandle != 0) {
			releaseTts();
		}
		// 初始化合成句柄
		ttsHandle = create(baseHandle, modelPath);
		if (ttsHandle != 0) {
			return true;
		} else {
			return false;
		}

	}

	// 释放合成句柄
	public void releaseTts() {
		if(ttsHandle != 0){
			release(ttsHandle);
			ttsHandle = 0;
		}
	}

	// 封装初始化方法（需要修改）
	public boolean init(String modelroot, String params) {

		unInit();
		baseHandle = createbase(modelroot);
		if (baseHandle == 0) {
			return false;
		}
		ttsHandle = create(baseHandle, modelroot);
		if (ttsHandle == 0) {
			return false;
		}
		return true;
	}

	// 释放合成句柄

	// 释放基础句柄

	// 封装释放方法
	public void unInit() {

		if (isInit() && isProcessing) {
			release(ttsHandle);
			ttsHandle = 0;
			releasebase(baseHandle);
			baseHandle = 0;
			isProcessing = false;
		}
	}

	// 判断是否初始化了
	public boolean isInit() {
		return ttsHandle != 0;
	}

	// 设置是否正在合成标示
	public void setProcessing(Boolean value) {
		isProcessing = value;
	}

	// 执行合成取消回调
	public void cancel() {
		if (isInit() && isProcessing) {
			cancel(ttsHandle);
			isProcessing = false;
			// ttsHandle = 0;
		}
	}

	// 0 01234 日志
	public void setLog(float value){
		value = checkParams(value);
		if (isInit()) {
			setOption(ttsHandle, 0, String.format("%1$.1f", value));
		}
	}
	
	// 1 0-100 50 调语速
	public void setVoiceSpeed(float speed) {
		speed = checkParams(speed);
		if (isInit()) {
			setOption(ttsHandle, 1, String.format("%1$.1f", speed));
		}
	}

	// 3 0-100 30 调音量（波形层级）
	public void setVoiceVolume(float volume) {
		volume = checkParams(volume);
		if (isInit()) {
			setOption(ttsHandle, 3, String.format("%1$.1f", volume));
		}
	}

	// 2 0-100 50 调音高(pitch)
	public void setVoicePitch(float value) {
		value = checkParams(value);
		if (isInit()) {
			setOption(ttsHandle, 2, String.format("%1$.1f", value));
		}
	}

	// 检测参数是否可用
	private float checkParams(float speed) {
		if (speed < 0f) {
			speed = 1f;
		} else if (speed > 100f) {
			speed = 100f;
		}
		return speed;
	}

	// 未测不知道是否支持
	public void setSampleRate(int rate) {
		if (isInit()) {
			setOption(ttsHandle, 5, String.valueOf(rate));
		}
	}

	// 未测不知道是否支持
	public boolean setField(int field) {
		if (isInit()) {
			int res = setOption(ttsHandle, 6, String.valueOf(field));
			if (res == 0) {
				return true;
			}
		}
		return false;
	}
}
