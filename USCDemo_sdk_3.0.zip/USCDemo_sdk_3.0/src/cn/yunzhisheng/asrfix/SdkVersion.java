package cn.yunzhisheng.asrfix;

public class SdkVersion {

	public static final String version = "1.5.83";

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.print(version);		  
	}
}
