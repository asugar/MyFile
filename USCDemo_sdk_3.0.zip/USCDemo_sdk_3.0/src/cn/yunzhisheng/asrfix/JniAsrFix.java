package cn.yunzhisheng.asrfix;

import com.unisound.common.LogUtil;

public class JniAsrFix {

	// return value
	public static final int ASRCLIENT_OK = 0;
	public static final int ASRCLIENT_NO_RESULT = 1;
	public static final int ASRCLIENT_PARTIAL_RESULT = 2;
	public static final int ASRCLIENT_VAD_TIMEOUT = 3;

	public static final int ASR_FATAL_ERROR = -1;
	public static final int ASR_COMMUNICATION_ERROR = -2;
	public static final int ASR_COMPRESS_PCM_ERROR = -3;
	public static final int ASR_SERVICE_NOT_RUNNING = -5;
	public static final int ASR_MEM_ALLOCATION_ERROR = -4;
	public static final int ASR_MAX_SPEECH_TIMEOUT = -6;
	public static final int ASR_VAD_TIMEOUT = -7;
	public static final int ASR_AUTHORIZE_ERROR = -8;

	public static final int ASR_ERROR_MIN_CODE = -63600;
	public static final int ASR_ERROR_MAX_CODE = -63999;

	// id of setValue()
	public static final int ASR_OPT_ENABLE_VAD = 0; // 0 OR 1, default value 0
													// (disable)
	public static final int ASR_OPT_VAD_TIMEOUT = 1; // only valid when vad is
														// enabled) from 2000 to
														// 10000, default value
														// 3000 (means 3000ms)
	public static final int ASR_OPT_MAX_SPEECH_TIMEOUT = 2; // from 10 to 600,
															// default value 60
															// (means 60s)
	public static final int ASR_OPT_SERVICE_TIMEOUT = 3; // 0 means always wait,
															// default value 20
															// (means 20s)
	public static final int ASR_OPT_RESULT_TIMEOUT = 4; // 0 means always wait,
														// default value 30
														// (means 30s)
	public static final int ASR_OPT_RESULT_FORMAT = 5; // default value 0 ( 0
														// means "text", 1 means
														// "json")
	public static final int ASR_OPT_PCM_COMPRESS = 6; // from 0 to 10, default
														// value 8
	public static final int ASR_OPT_DISABLE_PARTIAL_RESUL = 7; // 0 OR 1,
																// default value
																// 0
	public static final int ASR_OPT_DEVICE_IMEI = 8;
	public static final int ASR_OPT_SERVICE_KEY = 9;

	// CRC CHECK
	private static final int CRC_CHECK_OK = 0;
	private static final int CRC_CHECK_OPEN_ERROR = -1; // -1是文件打开失败，
	private static final int CRC_CHECK_LOSE_CRC = -2; // 是没找到CRC32这个字符串，
	private static final int CRC_CHECK_CRC_FAIL = -3; // 是CRC校验失败

	// native function
	// 增加一个jstring，为所有将被用到的模型路径
	// private native int init(String path,short);
	private native int init(String modelDir, String poiList);

	// private native int init(String ip, short port);

	private native int setOptionInt(int id, int value);

	private native int setOptionString(int id, String s);

	// private native int start(String model);
	private native int start(String model, int modelIndex);

	private native int isactive(byte[] sample, int len);

	private native int recognize(byte[] sample, int len);

	private native int stop();

	public static native String getVersion();

	private native String getResult();

	private native int cancel();

	private native void release();

	// 上层修改领域模型的接口
	private native int reset(String model, String cmd);

	// 通过关键词查询词条的接口
	private native String search(String poi, String words);

	/*
	 * 1. 离线做好城市相关POI模型，放在网络端供用户下载使用，需要进一步探讨版本号管理的方案
	 * 
	 * 2. 领域相关的模型单独处理
	 * 
	 * 1. 驾驶助手初始化时。人名，音乐等领域的模型全部单独编译，生成相对应的领域模型 à compileUserData接口
	 * 
	 * 2. 语音服务开启后，上层将所有将被用到的模型路径告知底层语音识别器 à init接口
	 * 
	 * 3. 每次语音识别前，上层告知底层语音识别器需要识别的领域（2个或更多） à start接口
	 * 
	 * 4. 在两次识别之间可以修改领域模型（比如城市由北京切换到上海，更换POI相关模型） - à reset接口
	 * 
	 * 3. 初步增加一个从大词表中搜索含有相应关键词的接口，譬如把POI中还有陆家嘴的所有词条全部找出来 à search接口
	 * 
	 * 1. 这一条不一定会由底层语音识别引擎完成，具体方案也有进一步分析
	 * 
	 * 4. 综上所述： 2. 有参数修改的接口如下：
	 * 
	 * 3. 参数意义有改动的接口如下：
	 * 
	 * 1. JNIEXPORT jint JNICALL start (JNIEnv *, jobject, jstring);
	 * 
	 * 1. 最后一个jstring以前是限定要使用的领域，为关键词，譬如APP，NAME，SONG等，新版本中为即将用到的领域模型路径名
	 * 
	 * 2. JNIEXPORT jint JNICALL compileUserData (JNIEnv *, jobject, jlong,
	 * jstring, jstring, jstring);
	 * 
	 * 1. 最后一个jstring以前是目录名，新版本中为模型存放的绝对路径
	 */
	// 2013.6.19
	private static native int crcCheck(String filePath);

	public static native long initUserDataCompiler(String szModelPath);

	// 最后一个jstring以前是目录名，新版本中为模型存放的绝对路径
	public static native int compileUserData(long handle, String jsgf,
			String szContent, String modelDir);

	// public static native int compileUserData(long handle,String jsgf, String
	// modelDir);

	public static native void destroyUserDataCompiler(long handle);

	public static native String getTagsInfo(long handle);

	public static native int compileDecodeNet(String modelDir, String netData);

	public static boolean checkFileByCrc32(String filePath) {

		if (crcCheck(filePath) == CRC_CHECK_OK) {
			return true;
		}
		return false;
	}

	// 通过关键词查询词条的接口
	public String search_(String poi, String words) {
		if (isInit) {
			return search(poi, words);
		}
		return null;
	}

	boolean isTryRelease = false;

	public boolean isTryRelease() {
		return isTryRelease;
	}

	public void setTryRelease() {
		isTryRelease = true;
	}

	public static int compileUserData_(String jsgf, String szContent,
			String modelDir, String netDat) {
		int code = -1;
		LogUtil.d("compile  initUserDataCompiler");
		long handle = initUserDataCompiler(modelDir);

		if (handle == 0) {
			return code;
		}
		LogUtil.d("compile  compileUserData");
		code = compileUserData(handle, jsgf, szContent, netDat);

		LogUtil.d("compile  destroyUserDataCompiler");
		destroyUserDataCompiler(handle);
		return code;
	}

	public static int transErrorCode(int code) {

		code = ASR_ERROR_MIN_CODE + code;

		if (code > ASR_ERROR_MIN_CODE) {
			code = ASR_ERROR_MAX_CODE + 1;
		} else if (code < ASR_ERROR_MAX_CODE) {
			code = ASR_ERROR_MAX_CODE;
		}

		return code;
	}

	private void keepInterface() {
		if (isInit == false) {
			isactive_(null, 0);
			cancel_();
		}
	}

	public int setOptionInt_(int id, int value) {
		if (isInit) {
			return setOptionInt(id, value);
		}
		return -1;
	}

	public int setOptionString_(int id, String value) {
		if (isInit) {
			return setOptionString(id, value);
		}
		return -1;
	}

	public int start_(String model, int modelIndex) {

		keepInterface();

		if (isInit) {
			return start(model, modelIndex);
			// return start(model);
		}
		return -1;
	}

	public int isactive_(byte[] sample, int len) {
		if (isInit) {
			return isactive(sample, len);
		}
		return -1;
	}

	public int recognize_(byte[] sample, int len) {
		if (isInit) {
			return recognize(sample, len);
		}
		return -1;
	}

	public int stop_() {
		if (isInit) {
			return stop();
		}
		return -1;
	}

	public String getResult_() {
		if (isInit) {
			return getResult();
		}
		return "";
	}

	public int cancel_() {
		if (isInit) {
			return cancel();
		}
		return -1;
	}

	/**
	 * 
	 * @param path
	 * @param model
	 * @return
	 */
	public int reset_(String model, String cmd) {
		synchronized (this) {
			if (isInit) {
				return reset(model, cmd);
			}
		}

		return -1000;
	}

	private boolean isInit = false;

	public int load(String modelDir, String poiList) {
		unLoad();
		isTryRelease = false;
		int code = init(modelDir, poiList);
		// int code = init(param1, (short)0);
		if (code == 0) {
			isInit = true;
		}
		return code;
	}

	public boolean isLoaded() {
		return isInit;
	}

	public void unLoad() {
		
		synchronized (this) {
			if (isInit) {
				release();
				isInit = false;
			}
		}
	}

	static {
		System.loadLibrary("asrfix");
	}

}
