package com.unisound.sdk;

import android.os.Handler;
import android.os.Message;

/**
 * Handler 回调封装
 * 
 * @author zhangkaijun@yunzhisheng.cn
 * 
 */
public class MainMessageHandler extends Handler {

	public interface MessageHandlerLisenter {
		
		boolean onHandleMessage(Message msg);
	}
	
	private MessageHandlerLisenter mListener;

	public void setMessageLisenter(MessageHandlerLisenter listener) {
		mListener = listener;
	}
	
	@Override
	public void handleMessage(Message msg) {
		super.handleMessage(msg);
		if(false == doHandleMessage(msg)) {
			if(mListener != null) {
				mListener.onHandleMessage(msg);
			}
		}
	}
	
	protected boolean doHandleMessage(Message message) {
		return true;
	}
	

	public void removeSendMessage() {
		this.removeCallbacks(null);
	}

	public void sendMessage(int what, Object obj) {
		obtainMessage(what, obj).sendToTarget();
	}

	public void sendMessage(int what) {
		sendEmptyMessage(what);
	}
}
