package com.unisound.sdk;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;
import cn.yunzhisheng.asr.VAD;
import com.unisound.sdk.FixRecognizer;
import com.unisound.sdk.FixRecognizerInterface;
import com.unisound.sdk.MixErrorCode;
import com.unisound.sdk.USCError;
import com.unisound.common.LogUtil;
import com.unisound.sdk.WakeUpCommand;
import com.unisound.common.WakeUpErrorCode;

import com.unisound.client.IAudioSource;
import com.unisound.client.SpeechConstants;
import com.unisound.client.WakeUpRecognizerListener;

/**
 * 提供语音唤醒相关接口
 * 通过setOption进行语义理解参数设置 </br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  通过loadModel加载模型 (optional)</br>
 * (4)  通过setWakeupWord 设置唤醒词(optional) </br>
 * (5)  通过star开始语音唤醒 </br>
 * (6)  获取回调 </br>
 * (7)  继续进入下一次语音唤醒
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class WakeUpRecognizerInterface extends FixRecognizerInterface{
	private static final String TAG = "WakeUpRecognizer";

	protected WakeUpRecognizerListener mListener = null;
	protected final int MSG_WAKEUP_DEFAULTDATA_INIT = FixRecognizer.MSG_MAX_WHAT_ID + 1;
	protected final int MSG_WAKEUP_USERDATA_INIT = MSG_WAKEUP_DEFAULTDATA_INIT + 1;

	protected final int MSG_WAKEUP_ERROR = MSG_WAKEUP_USERDATA_INIT + 1;

	protected float wakeUpScore = -2.7f;
	protected WakeUpCommand wakeupCommand = new WakeUpCommand();
	
	private boolean userModelInit = false ;
	/***
	 * 构造方法
	 * @param context  上下文环境
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	protected WakeUpRecognizerInterface(Context context, String appKey ,String secret) {
		super(context, appKey);
		wakeupCommand.setWakeupModelPath(modelData.dataPath);
		params.setVADRecordingEnabled(false);
		params.setFixAsrContinuousEnabled(true);
		params.setFrontVadEnabled(true);
		
		wakeupCommand.setChangedFlag(false);
		loadModel(false);
	}
	
	/**
	 * 根据JsonStr初始化WakeUp引擎 
	 * @param JsonStr
	 * @return 0 表示成功，否则返回相应错误码
	 */
	protected int init(String JsonStr) {
		return 0;
	}
	
	/**
	 * 加载模型
	 * @param modelFile
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	protected int loadModel(String modelFile) {
		return 0;
	}
	
	/**
	 * 开始语音唤醒
	 */
	protected void start() {
		LogUtil.d(TAG, "start");
		super.start(WakeUpCommand.WAKEUP_MODEL_DOMAIN);
	}
	
	
	/**
	 * 停止唤醒 </br>
	 */
	protected void stop(){
		LogUtil.d(TAG, "stop");
		super.stop();
		recognizer.stopRecognition();
	}
	
	/***
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	protected void setListener(WakeUpRecognizerListener listener){
		mListener = listener ;
	}

	/**
	 * 设置可选项</br>
	 * 设置远近讲       {@link com.unisound.client.SpeechConstants#ASR_VOICE_FIELD} 默认为VOICE_FIELD_NEAR</br>
	 * 设置 VAD前端点超时 {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_FRONTSIL} 范围 int 500~3000 (ms)</br>
	 * 设置VAD后端点超时  {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_BACKSIL} 范围 int 500~3000 (ms)</br>
	 * @param key
	 * @param value
	 */
	protected void setOption(int key , Object value){
//		protected void setWakeupRecordingModel(boolean isSelfRecording){
//			LogUtil.d(TAG, "setWakeupRecordingModel "+isSelfRecording);
//			setOption(OPT_SET_RECORDING_ENABLED, isSelfRecording);
//		}
		
//		/**
//		 * 唤醒结果门限数值
//		 * @param score
//		 */
//		public void setBenchmark(float score) {
//			wakeUpScore = score;
//		}
	}
	
	/**
	 * 获取可选项
	 * @param key
	 * @return value 返回可选项
	 */
	protected Object getOption(int key){
		return null;
	}
	
	/**
	 * 设置 唤醒词 
	 * @param wakeup
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	protected int setWakeupWord(List<String> wakeup) {
		if (wakeup != null && wakeup.size() > 0) {
			wakeupCommand.setCommandList(wakeup);
			wakeupCommand.setChangedFlag(true);
			new Thread(new Runnable() {
				@Override
				public void run() {
					loadModel(true);
				}
			}).start();
			return 0;
		}else {
			return -1;
		}
	}
		
	/**
	 * 获取唤醒命令词
	 * @return
	 */
	public List<String> getWakeUpWord(){
		List<String> commandData = new ArrayList<String>();
		commandData.addAll(wakeupCommand.getCommandList());
		return commandData;
	}
	
	/**
	 * 取消唤醒识别
	 */
	protected void cancel() {
		super.cancel();
	}
	
	/**
	 * 释放唤醒模型
	 */
	protected void release(){
		super.release();
	}
	
	/**
	 * 用来设置 audiosource 
	 * @param audioSource
	 * @return 0 表示成功, 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	public int setAudioSource(IAudioSource audioSource) {
		return 0;
	}
	
	
	/***
	 * 加载模型
	 * @return
	 */
	private int loadModel(boolean compileOptimizeEnabled) {
		if(!modelData.isInit) {
			if(!initModel(compileOptimizeEnabled)) {
				LogUtil.e("loadModel::isInit=false");
				doWakeUpError(errorCode.createPremiumError(MixErrorCode.FIX_COMPILE_NO_INIT));
				return -1;
			}
		}
		if(wakeupCommand.isChanged()) {
			// 编译加载唤醒
			String wakeupModel = wakeupCommand.getWakeupModelFile();

			int code = this.setUserData(wakeupCommand.getGsjf() ,wakeupCommand.getVocab(), wakeupModel); 
			if( 0 != code ) {
				LogUtil.e( this.toString() + (WakeUpErrorCode.WAKEUP_COMMAND_LIST_EMPTY + code));
				return -1;
			}
			userModelInit = true ;

			wakeupCommand.setChangedFlag(false);
		}

		int loadModel = safeLoadMode(wakeupCommand.getWakeupModelFile(), false);

		if(loadModel == 0) {
			if (!userModelInit) {
				recognizer.sendMessage(MSG_WAKEUP_DEFAULTDATA_INIT);
			}else {
				userModelInit = false ;
				recognizer.sendMessage(MSG_WAKEUP_USERDATA_INIT);
			}
			return loadModel;
		}
		doWakeUpError(errorCode.createPremiumError(MixErrorCode.FIX_COMPILE_ERROR));
		return loadModel;
	}
	
	
	protected boolean doHandleMessage(Message msg) {
		WakeUpRecognizerListener listener = null;
		if( super.doHandleMessage(msg)) {
			return true;
		}
		switch(msg.what) {
		case MSG_WAKEUP_ERROR:
			listener = mListener;
			if(listener != null){
				listener.onError(SpeechConstants.WAKEUP_ERROR, ((USCError)msg.obj).toString());
			}
			return true;
		case MSG_WAKEUP_DEFAULTDATA_INIT:
			listener = mListener;
			if(listener != null){
				listener.onEvent(SpeechConstants.WAKEUP_EVENT_INIT_DEFAULTDATA_FINISH, (int)System.currentTimeMillis());
			}
			return true;
		case MSG_WAKEUP_USERDATA_INIT:
			listener = mListener;
			if(listener != null){
				listener.onEvent(SpeechConstants.WAKEUP_EVENT_INIT_USERDATA_FINISH, (int)System.currentTimeMillis());
			}
			return true;
		default:
				return false;
		}
	}
	
	protected void doWakeUpError(USCError error) {
		if(error == null) {
			return ;
		}
		recognizer.sendMessage(MSG_WAKEUP_ERROR, error);
	}
	
	@Override
	protected void doFixResult(String result, boolean isLast) {
		WakeUpRecognizerListener ls = mListener;
		if (ls != null) {
			if (recognizeResult.setResultList(result)) {
				if (recognizeResult.score >= wakeUpScore) {
					mListener.onResult(SpeechConstants.WAKEUP_RESULT, recognizeResult.getText()+recognizeResult.score);
					mListener.onEvent(SpeechConstants.WAKEUP_EVENT_RECOGNIZITION_END,(int)System.currentTimeMillis());
				}
			}
		}
	}

	/**
	 * 识别结果分数
	 * @return
	 */
	public float getResultScore() {
		return recognizeResult.score;
	}

	/** ---设置唤醒命令词接口--- */
	protected int updateCommandData(List<String> commandData) {
		wakeupCommand.setCommandList(commandData);		
		return doPrepareRecognizer();
	}
	
	protected void doRecordingStart() {
		if (mListener != null) {
			mListener.onEvent(SpeechConstants.WAKEUP_EVENT_RECORDING_START, (int)System.currentTimeMillis());
		}
	}
	
	@Override
	protected void doRecordingStop() {
		if (mListener != null) {
			LogUtil.d(TAG, "onWakeUpRecognizeStop");
			mListener.onEvent(SpeechConstants.WAKEUP_EVENT_RECORDING_STOP, (int)System.currentTimeMillis());
		}
	}

	
	@Override
	protected void doVADTimeout(VAD sender) {
		// sender.reset();
	}
	
	@Override
	protected void doEnd(int error) {
		super.doEnd(error);
		doWakeUpError(errorCode.createPremiumError(error));
	}
	
	@Override
	protected void doRecordingData(boolean enabled, byte[] data, int offset,
			int length) {
		super.doRecordingData(enabled, data, offset, length);
	}
	
	
	
}
