package com.unisound.sdk;

import android.os.Handler;
import com.unisound.common.LogUtil;

/**
 * 任务定时计时类
 * @author user
 *
 */
public class OnTimer extends Handler implements Runnable {

	public interface IOnTimerListener {
		public void onTimer();
	}

	/**定时时间长度 */
	private int timeoutMillis = 30000;
	private IOnTimerListener listener;
	/**定时相关状态 */
	private boolean timeoutFlag = false;
	private boolean isStart = false;

	public OnTimer(IOnTimerListener listener) {
		this.listener = listener;
	}

	public void setTimer(int millis) {
		timeoutMillis = millis;
	}
	
	public int getTimer() {
		return timeoutMillis;
	}	

	public boolean isFinish() {
		return timeoutFlag;
	}

	@Override
	public void run() {
		timeoutFlag = true;
		if (isStart) {
			listener.onTimer();
		}
	}

	/**
	 * 添加超时定时
	 */
	public void start() {
		cancel();
		
		postDelayed(this, timeoutMillis);
		timeoutFlag = false;
		isStart = true;
		
		LogUtil.v("OnTimer:start");
	}

	/**
	 * 重置定时
	 */
	public void reset() {
		cancel();	
	}
	
	/**
	 * 放弃定时
	 */
	public void cancel() {

		if (isStart) {
			LogUtil.v("OnTimer:cancel");
			removeCallbacks(this);
			isStart = false;
		}
		timeoutFlag = false;	
	}

}
