package com.unisound.sdk;

import com.unisound.common.USCLogDataListener;

public interface RecognitionListener  extends USCLogDataListener{

	public void onRecognitionResult(String partial, boolean isLast);
	public void onRecognitionEnd();
	public void onRecognitionError(int error);	
	public void onRecognitionVADTimeout();
	public void onRecognitionMaxSpeechTimeout();
	public void onRecogintionRequestId(String id);
}
