package com.unisound.sdk;


public class VPRParams {

	/**
	 * 声纹识别
	 */
	public static final int VPR_TYPE_REGISTERED = 1;
	public static final int VPR_TYPE_VERIFY = 2;
	public static final int VPR_USERNAME = 3;
	public static final double SDK_VERSION = 1.0;
	public static final int CRYPT_VERSION = 0;
	private int mVPRType = VPR_TYPE_REGISTERED;
	private boolean mEnabled = false;
	private String mUserName = "";
	public static final String  VPR_ADDRESS = "vpr.hivoice.cn:80";
	
	public String getUserName() {
		return mUserName;
	}

	public void setUserName(String mUserName) {
		this.mUserName = mUserName;
	}

	public static double getSdkVersion() {
		return SDK_VERSION;
	}

	public boolean isEnabled() {
		return mEnabled;
	}
	

	public int getVPRType() {
		return mVPRType;
	}

	public void setVPRType(int mVPRType) {
		this.mVPRType = mVPRType;
	}


	public void setEnabled(boolean enabled) {
		mEnabled = enabled;		
	}	
	
	public String getVprAddress(){
		return VPR_ADDRESS;
	}
}
