package com.unisound.sdk;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.os.Message;
import android.util.SparseArray;
import cn.yunzhisheng.asr.JniUscClient;
import cn.yunzhisheng.asr.VAD;
import cn.yunzhisheng.asrfix.SdkVersion;

import com.unisound.client.ErrorCode;
import com.unisound.common.DeviceInfoUtil;
import com.unisound.common.LogUtil;
import com.unisound.common.USCSpeakerInfoSetting;
import com.unisound.common.USCSpeakerInformation;
import com.unisound.sdk.OnTimer.IOnTimerListener;
import com.unisound.sdk.UploadUserData.UploadUserDataListener;

public class Recognizer extends MainMessageHandler implements
		UploadUserDataListener, RecordingDataListener, RecognitionListener {

	static {
		System.loadLibrary("uscasr");
	}

	public static int ASR_MAX_TIMEOUT_MILLIS = 60000;
	public static int ASR_MIN_TIMEOUT_MILLIS = 10000;

	private USCSpeakerInfoSetting speakerInfoSetting = new USCSpeakerInfoSetting();
	private RequestIdListener tempRequestIdListener = null;
	private RequestIdListener requestIdListener = null;

	private RecognitionThread recognitionThread = null;
	private InputSourceThread recordingThread = null;
	private NetRecognizerListener listener = null;
	private RecognizerParams params = null;
	private String sessionId = "";
	private boolean stopFlag = true;

	public Recognizer(Context context, RecognizerParams params) {
		DeviceInfoUtil.init(context);
		this.params = params;
	}

	public void setPunctuation(boolean isEnable) {
		params.setPunctuation(isEnable);
	}
	
	private IOnTimerListener asrTimeoutListener = new IOnTimerListener() {

		@Override
		public void onTimer() {
			LogUtil.e("Recognizer timeout(" + asrOnTimer.getTimer() + ")");
			cancelRecognition();
			if (listener != null) {
				listener.onEnd(ErrorCode.RECOGNITION_TIMEOUT);
			}
		}
	};

	private OnTimer asrOnTimer = new OnTimer(asrTimeoutListener);
	protected USCSpeakerInformation speakerInformation = null;

	public String getVersion() {
		return SdkVersion.version;
	}

	public void setUserData(Map<Integer, List<String>> userData) {

		UploadUserData upload = new UploadUserData();
		upload.setListener(this);
		upload.postUserData(params.getAppKey(), userData);
	}

	public void setUserData(SparseArray<List<String>> userData) {

		UploadUserData upload = new UploadUserData();
		upload.setListener(this);
		upload.postUserData(params.getAppKey(), userData);
	}

	public void setUserData(String userData) {

		UploadUserData upload = new UploadUserData();
		upload.setListener(this);
		upload.postUserData(params.getAppKey(), userData);
	}

	public void setListener(NetRecognizerListener listener) {
		this.listener = listener;
//		setMessageLisenter(listener);
	}

	public void setTimeout(int millis) {

		if (millis > ASR_MAX_TIMEOUT_MILLIS) {
			millis = ASR_MAX_TIMEOUT_MILLIS;
		} else if (millis < ASR_MIN_TIMEOUT_MILLIS) {
			millis = ASR_MIN_TIMEOUT_MILLIS;
		}

		asrOnTimer.setTimer(millis);
	}

	public int getTimeout() {
		return asrOnTimer.getTimer();
	}

	/**
	 * 启动识别
	 */
	public void start(InputSourceThread inputSource) {

		asrOnTimer.reset();
		startRecognitionThread();

		recordingThread = inputSource;
		recordingThread.start();
	}

	private void startRecognitionThread() {

		cancelRecognition();

		// 识别用户信息 "性别"
		params.asrReqSpeakerInfo = speakerInfoSetting.getReqInfo();
		params.networkType = DeviceInfoUtil.getNetType();
		tempRequestIdListener = requestIdListener;
		speakerInformation = null;
		stopFlag = false;
		sessionId = "";

		recognitionThread = new RecognitionThread(params);
		recognitionThread.setRecognitionListener(Recognizer.this);
		recognitionThread.start();
	}

	public void start(List<byte[]> recordingData) {

		startRecognitionThread();
		recognitionThread.addData(recordingData);
		recognitionThread.stopRecognition();
	}

	public void stop() {

		stopRecording();
		stopRecognition();
	}

	public void cancel() {

		tempRequestIdListener = null;
		stopFlag = true;

		asrOnTimer.cancel();
		cancelRecording();
		cancelRecognition();
		removeSendMessage();
	}

	private void stopRecording() {
		stopFlag = true;
		if (recordingThread != null) {
			recordingThread.stopRecording();
		}
	}

	private void stopRecognition() {

		stopFlag = true;

		if (recognitionThread != null && !recognitionThread.isSetToStop()) {
			recognitionThread.stopRecognition();
			asrOnTimer.start();
		}
	}

	private void cancelRecording() {
		if (recordingThread != null) {
			recordingThread.cancel();
		}
	}

	private void cancelRecognition() {
		if (recognitionThread != null) {
			if (recognitionThread.isCancelled() == false) {
				recognitionThread.cancel();
				// msgHandler.sendEmptyMessage(Recognizer.MSG_RECOGNITION_CANCEL);
			}
		}
	}

	private final static int MSG_RECORDING_START = 1;
	private final static int MSG_RECORDING_STOP = 2;
	private final static int MSG_RECORDING_ERROR = 3;
	private final static int MSG_RECORDING_SPEAK_BEGIN = 5;

	private final static int MSG_RECOGNITION_RESULT = 11;
	private final static int MSG_RECOGNITION_STOP = 12;
	private final static int MSG_RECOGNITION_ERROR = 13;
	private final static int MSG_RECOGNITION_CANCEL = 14;
	private final static int MSG_RECOGNITION_EXCEPTION = 15;
	private final static int MSG_RECOGNITION_REQUEST_ID = 16;

	private final static int MSG_VAD_TIMEOUT = 21;
	private final static int MSG_UPDATE_VOLUMN = 22;
	private final static int MSG_MAX_SPEECH_TIMEOUT = 23;
	private final static int MSG_UPLOAD_USER_DATA = 24;

	private void doEnd(int error) {
		// 保存用户数据
		if (error == 0) {
			speakerInformation = new USCSpeakerInformation(
					params.asrRspSpeakerInfo, speakerInfoSetting.getReqInfo());
		}
		stopFlag = true;
		sessionId = "";
		if (recognitionThread != null) {
			sessionId = recognitionThread.getSessionId();
		}

		if (asrOnTimer.isFinish()) {
			return;
		}

		asrOnTimer.cancel();

		if (listener != null) {
			listener.onEnd(error);
		}
	}

	@Override
	public boolean doHandleMessage(Message msg) {
		switch (msg.what) {

		case MSG_RECORDING_START:
			boolean isSuccess = (Boolean) msg.obj;
			if (isSuccess) {
				if (listener != null) {
					listener.onRecordingStart();
				}
			} else {
				doEnd(ErrorCode.FAILED_START_RECORDING);
				cancelRecognition();
			}
			break;

		case MSG_RECORDING_STOP:

			stopRecognition();

			if (listener != null) {
				listener.onRecordingStop();
			}
			break;

		case MSG_RECORDING_ERROR:
			cancelRecognition();
			doEnd(ErrorCode.RECORDING_EXCEPTION);
			break;
		case MSG_RECORDING_SPEAK_BEGIN:
			doSpeakBegin();
			break;
		case MSG_RECOGNITION_RESULT:
			if (listener != null) {
				RecognitionResult recognitionResult = (RecognitionResult) msg.obj;
				listener.onResult(recognitionResult.text,
						recognitionResult.isLast);
			}
			break;

		case MSG_RECOGNITION_STOP:
			doEnd(JniUscClient.ASRCLIENT_RECOGNIZER_OK);
			break;

		case MSG_RECOGNITION_ERROR:
			cancelRecording();

			int code = (Integer) msg.obj;
			doEnd(code);

			break;

		case MSG_RECOGNITION_CANCEL:
			LogUtil.d("recognizer cancel");
			if (listener != null) {
				listener.onCancel();
			}
			break;

		case MSG_RECOGNITION_EXCEPTION:
			cancelRecording();
			doEnd(ErrorCode.RECOGNITION_EXCEPTION);

			break;

		case MSG_RECOGNITION_REQUEST_ID:
			doRecognitionRequestId((String) msg.obj);
			break;
		case MSG_VAD_TIMEOUT:
			if (listener != null) {
				listener.onVADTimeout();
			}
			break;

		case MSG_UPDATE_VOLUMN:
			if (listener != null) {
				int volume = (Integer) msg.obj;
				listener.onUpdateVolume(volume);
			}
			break;

		case MSG_MAX_SPEECH_TIMEOUT:
			cancel();
			doEnd(JniUscClient.ASRCLIENT_MAX_SPEECH_TIMEOUT);
			break;
		case MSG_UPLOAD_USER_DATA:
			if (listener != null) {
				code = (Integer) msg.obj;
				listener.onUploadUserData(code);
			}
			break;
		default:
			return false;
		}
		
		return true;
	}

	public void setServer(String domain, int port) {
		params.setServer(new String(domain), port);
	}

	protected void doRecognitionRequestId(String requestId) {

		RequestIdListener ls = tempRequestIdListener;
		if (ls != null) {
			ls.onRecogintionRequestId(requestId);
		}
	}

	protected void doSpeakBegin() {

		if (listener != null) {
			listener.onSpeechStart();
		}
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setResultTimeout(int timeout) {
		params.resultTimeout = timeout;
	}

	@Override
	public void onUploadUserDataState(int state) {
		sendMessage(MSG_UPLOAD_USER_DATA, state);
	}

	@Override
	public void onRecordingStart(boolean success) {
		sendMessage(Recognizer.MSG_RECORDING_START, success);
	}

	@Override
	public void onRecordingStop() {
		recordingThread = null;
		sendMessage(MSG_RECORDING_STOP);
	}

	@Override
	public void onRecordingError() {
		sendMessage(MSG_RECORDING_ERROR);
	}

	@Override
	public void onRecognitionVADTimeout() {
		// if (recordingThread != null) {
		// recordingThread.stopRecording();
		// }
	}

	@Override
	public void onRecognitionMaxSpeechTimeout() {
		sendMessage(Recognizer.MSG_MAX_SPEECH_TIMEOUT);
	}

	@Override
	public void onRecordingData(boolean enabled, byte[] data, int offset,
			int lenght) {

		if (recognitionThread != null && enabled) {

			recognitionThread.addData(data);
		}
		NetRecognizerListener ls = this.listener;
		if (ls != null) {
			ls.onRecordingData(enabled, data, offset, lenght);
		}
	}

	@Override
	public void onRecognitionError(int error) {

		stopRecording();

		sendMessage(MSG_RECOGNITION_ERROR, error);
	}

	@Override
	public void onUpdateVolume(int volume) {
		sendMessage(MSG_UPDATE_VOLUMN, volume);

	}

	@Override
	public void onRecognitionResult(String partial, boolean isLast) {

		RecognitionResult res = new RecognitionResult();
		res.text = partial;
		res.isLast = isLast;
		sendMessage(MSG_RECOGNITION_RESULT, res);
	}

	@Override
	public void onRecognitionEnd() {
		sendMessage(MSG_RECOGNITION_STOP);
	}

	@Override
	public void onSpeechStart() {
		sendMessage(MSG_RECORDING_SPEAK_BEGIN);
	}

	public boolean isStop() {
		return stopFlag;
	}

	@Override
	public void onRecogintionRequestId(String id) {
		sendMessage(MSG_RECOGNITION_REQUEST_ID, id);
	}

	public void setRequestIdListener(RequestIdListener listener) {
		requestIdListener = listener;
		tempRequestIdListener = listener;
	}

	public USCSpeakerInfoSetting getSpeakerInfoSetting() {
		return this.speakerInfoSetting;
	}

	public USCSpeakerInformation getSpeakerInformation() {
		return this.speakerInformation;
	}

	@Override
	public void onLogData(int what, int type, Object object) {
		if (listener != null) {
			listener.onLogData(what, type, object);
		}
	}

	@Override
	public void onVADTimeout(VAD sender) {
		sendMessage(Recognizer.MSG_VAD_TIMEOUT);
	}
	
	public String getTempResult() {
		if(recognitionThread != null) {
			return recognitionThread.getTempResult();
		}
		return "";		
	}
	
}