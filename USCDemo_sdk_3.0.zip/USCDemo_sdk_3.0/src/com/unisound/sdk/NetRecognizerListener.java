package com.unisound.sdk;

import com.unisound.common.USCLogDataListener;


public interface NetRecognizerListener extends OnlineRecognizerListener, USCLogDataListener {


	public void onRecordingStart();
	public void onEnd(int error);
	public void onCancel();
	
	public void onUploadUserData(int error);	
	public void onRecordingData(boolean enabled,byte[] data, int offset, int lenght);
	public void onRecordingStop();
	
	/**
	 * 用户开始说话

	 */
	public void onSpeechStart();
	
}
