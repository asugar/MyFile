package com.unisound.sdk;

/**
 * @author USC 播放线程接口
 */
public interface TTSPlayThreadListener {

	/**
	 * 语音缓存
	 */
	public void onBufferBegin();

	/**
	 * 语音缓存完成
	 */
	public void onBufferReady();

	/**
	 * 开始播报
	 */
	public void onPlayBegin();

	/**
	 * 语音播报结束
	 * 
	 * @param code
	 *            返回code
	 */
	public void onPlayEnd(int code);

	/**
	 * 播放暂停
	 */
	public void onPlayPause();

	/**
	 * 播放恢复
	 */
	public void onPlayResume();

	/***
	 * 取消播报
	 */
	public void onPlayCancel();

	/**
	 * 停止播放
	 */
	public void onPlayStop();

	/**
	 * 播放错误
	 * 
	 * @param error
	 *            播放错误详情
	 */
	public void onPlayError(USCError error);
}
