package com.unisound.sdk;

import com.unisound.common.BaseThread;

public class TTSBaseThread extends BaseThread {

	public static final String TAG = "TTSBaseThread";
	
	private volatile boolean mStopMark = false;
	private boolean mDebugMode = false;
    private volatile boolean mPauseMark = false;
    
	public TTSBaseThread(boolean debug) {
		super();
		mDebugMode = debug;
	}

	public boolean isStoped() {
//		LogUtil.d("mStopMark: "+mStopMark);
		return mStopMark;
	}

	public void reqStop() {
		mStopMark = true;
	}

	public boolean isDebug() {
		return mDebugMode;
	}

	public void setDebug(boolean debug) {
		mDebugMode = debug;
	}
	
	public void reqPause(){
	   mPauseMark = true;
	}

	public boolean isPause(){
		return mPauseMark;	
	}
	
	public void reqResume(){
		
	}
	
}
