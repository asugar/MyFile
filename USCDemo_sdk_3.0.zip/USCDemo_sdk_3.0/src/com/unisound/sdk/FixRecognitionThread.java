package com.unisound.sdk;

import java.util.concurrent.TimeUnit;

import cn.yunzhisheng.asrfix.JniAsrFix;

import com.unisound.client.ErrorCode;
import com.unisound.common.LogUtil;

public class FixRecognitionThread extends FixRecognitionThreadInterface {


	public FixRecognitionThread(JniAsrFix jac, String model, FixRecognizerParams params) {
		super(jac, model, params);
	}


	@Override
	public void run() {
		if (isCanceled() || jac == null) {
			return;
		}
		
		// 识别准备回调
		int r = doPrepareRecognizer();
		if(r != ErrorCode.RECOGNIZER_OK) {
			doRecognitionError(r);
			return;
		}
		int asrDataLenght = 0;		
		synchronized (jac) {

			if ((r = jac.start_(modelTag, params.getModelIndex())) < 0) {
				log_e("jac::start error=" + r +",model=" + modelTag + ",modelIndex=" + params.getModelIndex());
				doRecognitionError(JniAsrFix.transErrorCode(r));
				return;
			}
			log_d("jac::start model=" + modelTag + ",modelIndex=" + params.getModelIndex());
			
			byte[] queueHeadBuffer = null;
			doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_START, LogUtil.LOG_TYPE_NULL, null);
			while (!isCanceled()) {
				try {
					if ((queueHeadBuffer = recordQueue.poll(
							TIME_WAIT_RECORDING, TimeUnit.MILLISECONDS)) != null) {

						doRecogintionLogData(LogUtil.WHAT_TYPE_ASR_FEED, LogUtil.LOG_TYPE_BYTES,queueHeadBuffer);
						r = jac.recognize_(queueHeadBuffer,
								queueHeadBuffer.length);

						asrDataLenght += queueHeadBuffer.length;
						if (r == JniAsrFix.ASRCLIENT_PARTIAL_RESULT) {

							if (params.isFixAsrContinuous()) {
								String partial = jac.getResult_();
								if (partial != null && partial.length() > 0) {
									doRecognitionResult(partial, false);
									doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_PART_RESULT, LogUtil.LOG_TYPE_STRING, partial);
								}
							}
							log_d("recognize=" + r);
						} else if (r == JniAsrFix.ASRCLIENT_VAD_TIMEOUT) {
							doRecognitionVADTimeout();
							log_d("onRecognitionVADTimeout");
						} else if (r == JniAsrFix.ASR_MAX_SPEECH_TIMEOUT) {
							doRecognitionMaxSpeechTimeout();
							log_i("max timeout");
						} else if (r == JniAsrFix.ASRCLIENT_NO_RESULT) {

						} else if (r < 0) {
							jac.stop_();
							doRecognitionError(JniAsrFix.transErrorCode(r));
							
							return;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					break;
				}

				if (setToStopped && recordQueue.size() == 0) {
					log_i("recog break");
					break;
				}
			}

			jac.stop_();
			log_i("recog stopped");
			
			String partial = jac.getResult_();
			log_i("partial: " + partial);
			
			if(asrDataLenght < params.getGiveUpResultMinMillisecond() * 32 ) {
				log_e("Give Up Result:");
				partial = "";				
			}

			doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_STOP_RESULT, LogUtil.LOG_TYPE_STRING, partial);
			doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_END, LogUtil.LOG_TYPE_NULL, null);
			
			doRecognitionResult(partial, true);
			doRecognitionEnd();
		}
	}
}
