package com.unisound.sdk;

import com.unisound.common.VADTimeoutListener;

public class VADTimeoutHandle {
	
	private VADTimeoutListener mVADTimeoutListener;
	
	public void setListener(VADTimeoutListener listener) {
		mVADTimeoutListener = listener;
	}
	
	
	/**
	 * 是否设置监听，没有设置监听返回不可用状态
	 * @return
	 */
	public boolean isEnabled(){
		return mVADTimeoutListener != null;
	}

	
	public void onVADTimeout() {
		VADTimeoutListener listener = mVADTimeoutListener;
		if(listener != null) {
			listener.onVADTimeout();
		}		
	}
}
