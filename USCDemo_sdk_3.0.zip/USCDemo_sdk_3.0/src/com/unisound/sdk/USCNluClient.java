package com.unisound.sdk;

import com.unisound.common.HttpClient;
import com.unisound.common.LogUtil;


/**
 * 云知声语义云调用SDK
 */
public class USCNluClient {
	/**
	 * 根据请求参数对象 NluRequestPo 创建调用语义云平台API的Url
	 * get
	 * @param requestPo
	 *            请求参数对象
	 * @return 经过签名的Url
	 */
	public String createNluRequestUrl(NluRequestPo requestPo) {
		String url = TalkUrl.getTalkUrl(requestPo.getUrl(), requestPo.getMethod(),
				requestPo.getAppkey(), requestPo.getSecret(), requestPo.getUdid(),
				requestPo.getAppver(), requestPo.getGps(), requestPo.getVer(), requestPo.getText(),
				requestPo.getHistory(), requestPo.getCity(), requestPo.getTime(),
				requestPo.getVoiceId(), requestPo.getScenario(), requestPo.getScreen(),
				requestPo.getDpi(),requestPo.getPlatform(),requestPo.getViewid());
		return url;
	}
	

	/**
	 * 根据请求参数对象 NluRequestPo 调用语义云API，返回语义理解的JSON结果
	 * Http get 请求
	 * @param requestPo
	 *            请求参数对象
	 * @return Json格式的语义理解结果
	 */
	public String getNluJsonResultForGet(NluRequestPo requestPo) {
		String url = createNluRequestUrl(requestPo);
		String jsonString = HttpClient.httpGet(url);
		LogUtil.d("nlu url: "+ url);
		return jsonString;
	}
	
	/***
	 * 根据请求参数对象 NluRequestPo 调用语义云API，返回语义理解的JSON结果
	 * Http post 请求
	 * @param requestPo
	 * @return
	 */
	public String getNluJsonResultForPost(NluRequestPo requestPo) {
		String url = createNluRequestUrl(requestPo);
		String jsonString = HttpClient.httpPost(url, "");
		LogUtil.d("nlu url: "+ url);
		return jsonString;
	}
}