package com.unisound.sdk;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;
import cn.yunzhisheng.tts.JniClient;

import com.unisound.common.Addresser;
import com.unisound.common.BaseThread;
import com.unisound.common.DeviceInfoUtil;
import com.unisound.common.LogUtil;
import com.unisound.common.SdkVersion;

/**
 * @author USC 在线合成线程
 * 
 */
public class TTSOnlineSynthesizerThread extends BaseThread {

	private TTSSynthesizerThreadListener ttsListener = null;
	private List<TTSData> ttsDataList = new ArrayList<TTSData>();
	private TTSParams params;

	public TTSOnlineSynthesizerThread(TTSParams params) {
		super();
		this.params = params;
	}

	public void start(String msg) {
		setText(msg);
		start();
	}

	private void setText(String msg) {
		TTSData data = new TTSData();
		data.message = msg;
		data.type = this.params.getVoiceName();
		ttsDataList.add(data);
	}

	public void setListener(TTSSynthesizerThreadListener listener) {
		ttsListener = listener;
	}

	/**
	 * 放弃识别任务
	 */
	public void cancel() {
		ttsListener = null;

	}

	/**
	 * 是否放弃识别任务
	 */
	public boolean isCancelled() {
		return (ttsListener == null);
	}

	public static String getUTF8(String paramString) {
		if (paramString != null)
			try {
				String str = URLEncoder.encode(paramString, "UTF-8");
				return str;
			} catch (UnsupportedEncodingException localUnsupportedEncodingException) {
				localUnsupportedEncodingException.printStackTrace();
			}
		return "";
	}

	/**
	 * 合成语音数据
	 * 
	 * @param ttsData
	 * @return
	 */
	private int getTTSData(TTSData ttsData) {

		JniClient jni = new JniClient();

		int resultCode = 0;
		try {
			LogUtil.v("TTSThread---start");
			// 初始化
			Addresser address = params.getServerAddress();
			if (!jni.create(params.getAppKey(), address.getIP(), address.getPort())) {
				LogUtil.e("TTSThread:create error");
				return JniClient.INIT_ERROR;
			}

			jni.setOption(JniClient.TTS_OPT_DEVICE_IMEI, DeviceInfoUtil.imei);
			jni.setOption(JniClient.TTS_OPT_USER_ID, DeviceInfoUtil.imei);
			// collected info
			StringBuilder sb = new StringBuilder();
			sb.append(DeviceInfoUtil.packageName).append(":");
			sb.append(JniClient.DEVICE_OS_Android).append(":");
			sb.append(DeviceInfoUtil.carrier).append(":");
			sb.append(params.networkType).append(":");
			sb.append(DeviceInfoUtil.model).append(":");
			sb.append(SdkVersion.version);
			sb.append("\t" + LogUtil.erron + ":" + JniClient.state + ":" + JniClient.erron);
			jni.setOption(JniClient.TTS_OPT_CLIENT_INFO, sb.toString());
			// 音高，语速，发音人设置
			jni.setOption(JniClient.TTS_OPT_USC_ENGINE_PARAMETER, ttsParamsToString(params));

			// 开始合成
			AudioFormat audioFormat = params.getAudioFormat();
			resultCode = jni.start(audioFormat.toParamString(), audioFormat.getEncode());
			if (resultCode != JniClient.SUCCESS) {
				LogUtil.e("TTSThread:start error" + resultCode);
				return resultCode;
			}

			resultCode = jni.textPut(ttsData.message);
			if (resultCode != JniClient.SUCCESS) {
				LogUtil.e("TTSThread:textPut error" + resultCode);
				return resultCode;
			}

			doBuffer();
			// 获取网络数据
			while (!isCancelled()) {

				byte[] buffer = jni.getResult();
				if (buffer == null) {
					resultCode = jni.status.mErrorCode;
					if (resultCode == 0) {

					} else {
						LogUtil.e("TTSThread:textPut error" + resultCode);
					}
					break;
				}

				// byte[] det = new byte[jni.status.mAudioLen];
				// System.arraycopy(buffer, 0, det, 0, jni.status.mAudioLen);
				doData(buffer);
			}
			jni.stop();
			LogUtil.v("TTSThread---end");
		} finally {

			jni.release();
		}

		return resultCode;
	}

	/**
	 * 回调语音数据
	 * 
	 * @param data
	 */
	private void doData(byte[] data) {
		TTSSynthesizerThreadListener listener = ttsListener;
		if (listener != null) {
			// listener.onTTSData(data, 0, data.length);
			listener.onSynthesizerProcess(data, data.length);
		}
	}

	/**
	 * 开始缓冲语音数据
	 */
	private void doBuffer() {
		TTSSynthesizerThreadListener listener = ttsListener;
		if (listener != null) {
			// listener.onBuffer();
			listener.onSynthesizerBegin();
		}
	}

	/**
	 * 语音合成线程
	 */
	@Override
	public void run() {
		super.run();

		TTSData ttsData = null;

		while (false == isCancelled()) {

			if (ttsDataList.size() == 0) {
				break;
			}

			ttsData = ttsDataList.remove(0);
			int ret = getTTSData(ttsData);
			if (ret != TTSErrorCode.SUCCESS) {
				doEnd(ret);
				LogUtil.e("tts error: " + ret);
				break;
			} else {
				doEnd(TTSErrorCode.SUCCESS);
			}
		}
	}

	/**
	 * 合成结束回调
	 * 
	 * @param code
	 */
	private void doEnd(int code) {
		TTSSynthesizerThreadListener listener = ttsListener;
		if (listener != null) {
			// listener.onTtsEnd(code);
			listener.onSynthesizerEnd();
		}
	}

	/**
	 * 设置监听
	 * 
	 * @param listener
	 */
	public void setTTSListener(TTSSynthesizerThreadListener listener) {
		ttsListener = listener;
	}

	public String getSessionId() {
		return null;
	}

	private String ttsParamsToString(TTSParams params) {
		StringBuilder sb = new StringBuilder();
		if (params != null) {
			sb.append("vol=").append(params.getVoicePitch()).append(";");
			sb.append("spd=").append(params.getVoiceSpeed()).append(";");
			sb.append("vcn=").append(params.getVoiceName()).append(";");
		}
		return sb.toString();
	}

}
