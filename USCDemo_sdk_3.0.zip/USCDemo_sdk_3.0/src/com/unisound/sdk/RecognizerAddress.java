package com.unisound.sdk;

import com.unisound.common.Addresser;

public class RecognizerAddress 
{
//	public static Addresser CHINESE_ADDRESS =   new Addresser("tr.hivoice.cn",80,     "117.121.49.44",80);
	public static Addresser CHINESE_ADDRESS =   new Addresser("vpr.hivoice.cn",80,     "117.121.49.35",80);	
	public static Addresser ENGLISH_ADDRESS =   new Addresser("v_eng.hivoice.cn",80, "117.121.55.43",80);
	public static Addresser CANTONESE_ADDRESS = new Addresser("v_cnt.hivoice.cn",80, "117.121.55.41",80);
	public static Addresser ORAL_ADDRESS =      new Addresser("eval.hivoice.cn",80,  "140.207.193.59",80);
	public static Addresser FAR_FEILD_ADDRESS =  new Addresser("117.121.55.39",9001,     "117.121.55.39",9001);

	
	// htc address
//	public static Addresser CHINESE_ADDRESS =   new Addresser("117.121.55.39",9004,     "117.121.55.39",9004);
	// htc  address
	public static Addresser CN_EN_ADDRESS =   new Addresser("v_zhen.hivoice.cn",9004,     "v_zhen.hivoice.cn",9004);

	
	public static Addresser getAddresser(String lang)
	{
		if (lang.equals(RecognizerParams.ENGLISH)) 
		{
			return RecognizerAddress.ENGLISH_ADDRESS;
		}
		else if (lang.equals(RecognizerParams.CANTONESE)) 
		{
			return RecognizerAddress.CANTONESE_ADDRESS;
		}
		else if(lang.equals(RecognizerParams.ORAL))
		{
			return RecognizerAddress.ORAL_ADDRESS;
		}
		else if(RecognizerParams.CN_EN_MIX.equals(lang)) 
		{
			return RecognizerAddress.CN_EN_ADDRESS;
		}
		return RecognizerAddress.CHINESE_ADDRESS;
	}
}
