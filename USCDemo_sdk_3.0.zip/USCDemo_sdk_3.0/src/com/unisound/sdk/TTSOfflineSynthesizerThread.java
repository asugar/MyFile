package com.unisound.sdk;

import cn.yunzhisheng.tts.offline.lib.YzsTts;

import com.unisound.common.LogUtil;

/**
 * @author USC 离线合成线程
 */
public class TTSOfflineSynthesizerThread extends TTSBaseThread {

	private String mText;
	private YzsTts mTts = YzsTts.getInstance();
	private static TTSSynthesizerThreadListener mListener;
	/**
	 * 0.1s 播放结束填充数据
	 */
	public static int bufferMillisecond = 500;
	private static byte[] fillBuffer = new byte[3200];

	public TTSOfflineSynthesizerThread(String text, boolean debug) {
		super(debug);
		mText = text;
	}

	// 注册合成监听器
	public void setSynthesizerListener(TTSSynthesizerThreadListener listener) {
		this.mListener = listener;
	}

	@Override
	public void reqStop() {
		super.reqStop();
		mTts.cancel();
	}

	@Override
	public void run() {
		super.run();
		try {

			doSynthesizeBegin();
			int handle = mTts.setText(mTts.getTtsHandle(), mText);
			if (handle != 0) {
				LogUtil.e("setText error");
				return;
			}
			byte[] buffer = new byte[8000];
			handle = 1;
			// 标记正在合成
			mTts.setProcessing(true);
			// 循环条件应该加上!isStop()
			while (handle != 0 && !isStoped()) {
				handle = mTts.receiveSamples(mTts.getTtsHandle(), buffer);
				if (buffer != null && handle > 1) {
					doSynthesizeProcess(buffer, handle);
				}
			}
			
			doSynthesizeEnd();
			// 标记正在合成结束
			mTts.setProcessing(false);
			// 释放合成资源
			// mTts.unInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 执行合成开始回调
	private static void doSynthesizeBegin() {
		TTSSynthesizerThreadListener listener = mListener;
		if (listener != null) {
			listener.onSynthesizerBegin();
		}
	}

	// 执行合成结束回调
	private static void doSynthesizeEnd() {
		TTSSynthesizerThreadListener listener = mListener;
		if (listener != null) {
			// android 丢帧问题 填充数据。
			for (int i = 0; i < bufferMillisecond / 100; i++) {
				listener.onSynthesizerProcess(fillBuffer, fillBuffer.length);
			}
			listener.onSynthesizerEnd();
		}
	}

	// 执行合成数据回调
	private static void doSynthesizeProcess(byte[] data, int length) {
		TTSSynthesizerThreadListener listener = mListener;
		if (listener != null) {
			listener.onSynthesizerProcess(data, length);
		}
	}

	// 执行合成取消
	private void doSynthesizeCancel() {
		TTSSynthesizerThreadListener listener = mListener;
		if (listener != null) {
			listener.onSynthesizerCancel();
		}
	}

	// 执行合成停止
	private void doSynthesizerStop() {
		TTSSynthesizerThreadListener listener = mListener;
		if (listener != null) {
			listener.onSynthesizerStop();
		}
	}
	
	private void doSynthesizerRelease() {
		TTSSynthesizerThreadListener listener = mListener;
		if (listener != null) {
			listener.onSynthesizerRelease();
		}
	}
	
	public void release() {
		mTts.unInit();
		doSynthesizerRelease();
	}

	// 不太清楚方法作用
	public void setBufferTime(int millisecond) {
		bufferMillisecond = millisecond;
	}

	public void waitEnd(int millis) {
		if (isAlive()) {
			mTts.cancel();
			try {
				super.join(millis);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void cancel() {
//		doSynthesizeCancel();
		this.setSynthesizerListener(null);
		reqStop();
	}

	public void setLog(float value) {
		mTts.setLog(value);
	}

	public void setVoiceSpeed(float speed) {
		mTts.setVoiceSpeed(speed);

	}

	public void setVoicePitch(float speed) {
		mTts.setVoicePitch(speed);
	}

	public void setVoiceVolume(float volume) {
		mTts.setVoiceVolume(volume);
	}

	// 这两个方法时新的不知道怎么用
	public void setSampleRate(int rate) {
		mTts.setSampleRate(rate);
	}

	public boolean setField(int field) {
		return mTts.setField(field);
	}
}
