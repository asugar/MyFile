package com.unisound.sdk;

import com.unisound.sdk.BasicRecognizerHandle;




public class FixRecognizerHandle extends BasicRecognizerHandle {



}
