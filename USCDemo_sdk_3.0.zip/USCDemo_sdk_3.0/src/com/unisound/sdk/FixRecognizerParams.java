package com.unisound.sdk;


public class FixRecognizerParams extends RecognizerParams {


	private int modelIndex = 0;
	
	
	public void setModelIndex(int modelIndex) {
		this.modelIndex = modelIndex;
	}

	
	public int getModelIndex() {
		return modelIndex;
	}
	
	
	// wakeup
	boolean isFixAsrContinuous = false;
	public boolean isFixAsrContinuous() {
		return isFixAsrContinuous;
	}
	
	public void setFixAsrContinuousEnabled(boolean enabled) {
		isFixAsrContinuous = enabled;
	}


}
