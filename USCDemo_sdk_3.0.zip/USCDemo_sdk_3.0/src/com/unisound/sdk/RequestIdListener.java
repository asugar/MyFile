package com.unisound.sdk;

public interface RequestIdListener {
	
	public void onRecogintionRequestId(String requestId);
}
