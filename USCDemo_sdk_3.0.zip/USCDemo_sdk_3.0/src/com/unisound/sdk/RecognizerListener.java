package com.unisound.sdk;

import com.unisound.common.USCLogDataListener;
import com.unisound.sdk.MainMessageHandler.MessageHandlerLisenter;



public interface RecognizerListener extends MessageHandlerLisenter, VADListener, USCLogDataListener {

	public void onResult(String result, boolean isLast);
	public void onRecordingStart();
	public void onRecordingDataStart();
	public void onEnd(int error);
	public void onCancel();
	public boolean isStopRecording();
	public void onUploadUserData(int error);	
	public void onRecordingStop();
}
