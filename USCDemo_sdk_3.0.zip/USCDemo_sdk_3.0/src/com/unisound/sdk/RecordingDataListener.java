package com.unisound.sdk;

public interface RecordingDataListener extends VADListener {
	
	public void onRecordingStart(boolean success);
	public void onRecordingStop();
	public void onRecordingError();
}
