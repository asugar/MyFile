package com.unisound.sdk;

import java.util.ArrayList;
import java.util.List;

/**
 * 唤醒词管理
 * @author user
 *
 */
public class WakeUpCommand {
	
	public static final String WAKEUP_MODEL_DOMAIN = "wakeup";
	private String wakeupModleFile = "wakeup.dat";
	public static final String jsgf= "#JSGF V1.0 utf-8 cn;\n"
		+ "grammar wakeup;\n" 
		+ "public <wakeup> =( \"<s>\" (\n"
		+ "(<NAME> )\n"
		+ ") \"</s>\");";
		
	private List<String> commandList = new ArrayList<String>();
	private boolean isChanged = false;
	
	public WakeUpCommand(){
		commandList.add("您好魔方");
	}
	
	public void setWakeupModelPath(String path) {
		wakeupModleFile = path + "wakeup.dat";
	}
	
	public String getWakeupModelFile() {
		return wakeupModleFile;
	}
	
	public String getGsjf() {
		return jsgf;
	}
	
	
	
	public boolean isChanged() {
		return isChanged;
	}
	
	public void setChangedFlag(boolean changed) {
		isChanged = changed;
	}
	
	public boolean isCnaghedCommand(List<String> commandList) {
		
		if(commandList == null) {
			return true;
		}
		
		String list1 = commandList.toString();
		String list2 = this.commandList.toString();
		
		if(list1.equals(list2)) {
			return false;
		}
		return true;
		
	}
	
	/**
	 * 设置唤醒词
	 * @param commandList
	 */
	public void setCommandList(List<String> commandList) {
		
		if(isCnaghedCommand(commandList)) {
			setChangedFlag(true);
			this.commandList.clear();
			this.commandList.addAll(commandList);
		}
	}
	
	/**
	 * 唤醒词列表
	 * @return
	 */
	public String getVocab() {
		return getVocab(commandList);
	}
	
	public String getVocab(List<String> commandList) {
		
		StringBuffer buffer = new StringBuffer();
		buffer.append("<NAME>").append("\n");
		for( String name : commandList) {
			buffer.append(name).append("\n");
		}
		
		buffer.append("</NAME>");
		
		return buffer.toString();
	}


	public List<String> getCommandList() {
		return commandList;
	}
}
