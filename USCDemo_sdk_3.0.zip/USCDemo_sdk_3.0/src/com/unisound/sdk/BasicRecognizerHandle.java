package com.unisound.sdk;





public class BasicRecognizerHandle {

	BasicRecognizerListener mBasicRecognizerListener;
	
	public void setListener(BasicRecognizerListener listener) {
		mBasicRecognizerListener = listener;
	}
	
	/**
	 * 是否设置监听，没有设置监听返回不可用状态
	 * @return
	 */
	public boolean isEnabled(){
		return mBasicRecognizerListener != null;
	}
	
	public void onRecognizerStart() {
		
		BasicRecognizerListener listener = mBasicRecognizerListener;
		if (listener != null) {
			listener.onRecognizerStart();
		}		
	}
	
	
	public void onVADTimeout() {
		BasicRecognizerListener listener = mBasicRecognizerListener;
		if (listener != null) {
			listener.onVADTimeout();
		}			
	}
	
	
	public void onUpdateVolume(int volume) {
		
		BasicRecognizerListener listener = mBasicRecognizerListener;
		if (listener != null) {
			listener.onUpdateVolume(volume);
		}		
	}
}
