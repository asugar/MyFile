package com.unisound.sdk;

public class AudioFormat {
	public static final String AUDIO_FORMAT_WAV = "x-wav";
	public static final String AUDIO_FORMAT_CODEC = "pcm";
	public static final String AUDIO_FORMAT_ENCODE = "opus";
	public static final int AUDIO_FORMAT_BIT = 16;
	public static final int AUDIO_FORMAT_RATE = 16000;
	
	
	private String audio = AUDIO_FORMAT_WAV;
	private String codec = AUDIO_FORMAT_CODEC;
	private String encode = AUDIO_FORMAT_ENCODE;
	private int bit = AUDIO_FORMAT_BIT;
	private int rate = AUDIO_FORMAT_RATE;
	private boolean isChanged = true;
	
	public String getEncode() {
		return encode;
	}

	public String toParamString() {
		// "audio/x-wav;codec=pcm;bit=16;rate=16000"
		return "audio/" + audio;
		// + ";codec=" + codec + ";bit=" + bit + ";rate=" +rate;
	}

	public boolean isChanged() {
		return isChanged;
	}

	public void setChange(boolean value) {
		isChanged = value;		
	}
}
