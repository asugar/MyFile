package com.unisound.sdk;

import android.text.TextUtils;

import com.unisound.client.ErrorCode;

import cn.yunzhisheng.asr.JniUscClient;
import cn.yunzhisheng.asrfix.JniAsrFix;


public class MixErrorCode extends ErrorCode {

//	public static final int FIX_RECOGNIZER_INIT_ERROR = -63501;
	public static final int FIX_RECOGNIZER_NO_INIT    = -63502;
	public static final int FIX_COMPILE_NO_INIT    = -63503;
	public static final int FIX_COMPILE_ERROR    = -63504;

	
	@Override
	public  String toMessage(int code) {
		
		String msg = super.toMessage(code);
		if(!TextUtils.isEmpty(msg)){
			return msg;
		}
		switch (code) {
//		case FIX_RECOGNIZER_INIT_ERROR:
		case FIX_RECOGNIZER_NO_INIT:				return "离线引擎没有初始化";
		case FIX_COMPILE_NO_INIT:					return "离线引擎没有初始化,不能编译用户数据";
		case FIX_COMPILE_ERROR:						return "离线引擎编译失败";
		}
		
		if(code <= JniAsrFix.ASR_ERROR_MAX_CODE || code <= JniAsrFix.ASR_ERROR_MIN_CODE) {
			return "本地识别错误";
		}

		return "";
	}
	


	public int toProfession(int code){
		
		switch(code){
		//public class INPUT_CHECKER_ERR{
		case JniUscClient.ASRCLIENT_VAD_TIMEOUT:
		case JniUscClient.ASRCLIENT_MAX_SPEECH_TIMEOUT:
			break;
		case JniUscClient.ASRCLIENT_COMPRESS_PCM_ERROR:
		case JniUscClient.ASRCLIENT_INVALID_PARAMETERS:
			return JniUscClient.ASRCLIENT_COMPRESS_PCM_ERROR;
		case FIX_RECOGNIZER_NO_INIT:
			return FIX_RECOGNIZER_NO_INIT;
		}
		
		return code;
	}	
}
