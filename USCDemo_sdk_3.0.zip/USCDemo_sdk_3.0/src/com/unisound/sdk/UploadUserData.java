package com.unisound.sdk;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import android.util.SparseArray;

import com.unisound.sdk.EncodeContent;
import com.unisound.sdk.USCConfig;
import com.unisound.client.ErrorCode;
import com.unisound.common.DeviceInfoUtil;
import com.unisound.common.LogUtil;

/**
 * <NAME><APP><SONG>
 */

/**
 * 2014-06-10 add 扩充了多个领域，包括：SINGER（歌手）, ALBUM（专辑）, COMMAND（命令）, POI（地名）。
 */

public class UploadUserData extends Thread {

	public static String userDataServer = "http://v2.hivoice.cn:8081/casr/upload";

	public interface UploadUserDataListener {
		public void onUploadUserDataState(int state);
	}

	private UploadUserDataListener listener;
	private EncodeContent encode = new EncodeContent();
	private String uploadData;

	/**
	 * 处理个性化数据去除非法字符
	 * 
	 * @param items
	 */
	private void formatList(List<String> items) {

		for (int i = items.size() - 1; i > -1; i--) {

			String text = items.get(i);
			if (text == null || text.length() == 0) {
				items.remove(i);
				continue;
			}
			boolean changed = false;
			if (text.indexOf(">") > -1) {
				text = text.replaceAll(">", "");
				changed = true;
			}

			if (text.indexOf("<") > -1) {
				text = text.replaceAll("<", "");
				changed = true;
			}

			if (text.length() == 0) {
				items.remove(i);
				continue;
			}
			if (changed) {
				items.set(i, text);
			}
		}
	}

	private int getMaxSize(int tag) {

		switch (tag) {
		case USCConfig.NAME:
			return USCConfig.MAX_NAME;
		case USCConfig.APP:
			return USCConfig.MAX_APP;
		case USCConfig.SONG:
			return USCConfig.MAX_SONG;
		case USCConfig.SINGER:
			return USCConfig.MAX_SINGER;
		case USCConfig.ALBUM:
			return USCConfig.MAX_ALBUM;
		case USCConfig.COMMAND:
			return USCConfig.MAX_COMMAND;
		case USCConfig.POI:
			return USCConfig.MAX_POI;
		default:
			return -1;
		}
	}

	private String tagIdToString(int tagId) {

		switch (tagId) {
		case USCConfig.NAME:
			return "NAME";
		case USCConfig.APP:
			return "APP";
		case USCConfig.SONG:
			return "SONG";
		case USCConfig.SINGER:
			return "SINGER";
		case USCConfig.ALBUM:
			return "ALBUM";
		case USCConfig.COMMAND:
			return "COMMAND";
		case USCConfig.POI:
			return "POI";
		default:
			return null;
		}
	}

	private boolean readListToBuffer(int tagId, List<String> list, StringBuilder sb) {

		String tagName = tagIdToString(tagId);
		if (tagName == null) {
			log_e(" not find tag id = " + tagId);
			return true;
		}

		if (list == null) {
			log_e(tagName + " = NULL");
			return true;
		}

		int maxSize = getMaxSize(tagId);
		if (list.size() > maxSize) {

			log_e(tagName + " Number of over count > " + maxSize);
			uploadUserDataState(ErrorCode.UPLOAD_USER_TOO_LARGE);
			return false;
		}

		formatList(list);
		
		sb.append("<" + tagName + ">\n");
		for (String name : list) {
			sb.append(name).append("\n");
		}
		sb.append("</" + tagName + ">\n");

		return true;
	}

	private Map<Integer, List<String>> formatUserData(
			Map<Integer, List<String>> userData) {

		for (Integer key : userData.keySet()) {

			List<String> items = userData.get(key);
			if (items != null) {
				formatList(items);
				if (items.size() > 0) {
					// map.put(key, items);
				}
			}
		}
		return userData;
	}

	public void setListener(UploadUserDataListener listener) {
		this.listener = listener;
	}

	public void uploadUserDataState(int state) {
		UploadUserDataListener ls = listener;
		if (ls != null) {
			ls.onUploadUserDataState(state);
		}
	}

	private void log_e(String error) {
		LogUtil.e("UploadUserData:" + error);
	}

	public void postUserData(String serviceKey, String userData) {

		StringBuilder sb = new StringBuilder();
		sb.append(serviceKey).append("\n");
		postUserData(sb.toString());
	}

	public void postUserData(String serviceKey,	SparseArray<List<String>> userData) {

		StringBuilder sb = new StringBuilder();
		sb.append(serviceKey).append("\n");

		int size = userData.size();
		for (int i = 0; i < size; i++) {
			int key = userData.keyAt(i);
			List<String> list = userData.get(key);
			if (!readListToBuffer(key, list, sb)) {
				return;
			}
		}

		postUserData(sb.toString());
	}

	private void postUserData(String userData) {
		uploadData = userData;
		start();
	}

	public void postUserData(String serviceKey,	Map<Integer, List<String>> userData) {

		if (listener == null || userData == null) {
			uploadUserDataState(ErrorCode.UPLOAD_USER_DATA_EMPTY);
			return;
		}

		if (userData.isEmpty()) {
			uploadUserDataState(ErrorCode.UPLOAD_USER_DATA_EMPTY);
			return;
		}

		userData = formatUserData(userData);
		StringBuilder sb = new StringBuilder();
		sb.append(serviceKey).append("\n");
		
		for (Integer key : userData.keySet()) {

			List<String> list = userData.get(key);
			if (!readListToBuffer(key, list, sb)) {
				return;
			}
		}

		postUserData(sb.toString());
	}

	@Override
	public void run() {
		int error = ErrorCode.RECOGNIZER_OK;
		try {

			byte[] imeiByte = DeviceInfoUtil.imei.getBytes();
			byte[] sourceByte = uploadData.getBytes();
			byte[] encodeByte = new byte[imeiByte.length + sourceByte.length
					+ 10];

			if (0 != encode
					.EncodeTotalContent(imeiByte, sourceByte, encodeByte)) {
				error = ErrorCode.UPLOAD_USER_ENCODE_ERROR;
			} else {

				URL url = new URL(userDataServer);
				HttpURLConnection conn = (HttpURLConnection) url
						.openConnection();
				conn.setRequestMethod("POST");
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setConnectTimeout(30 * 1000);

				OutputStream out = conn.getOutputStream();
				out.write(encodeByte);
				out.flush();
				out.close();

				if (conn.getResponseCode() == 200) {
					InputStreamReader reader = new InputStreamReader(
							conn.getInputStream());
					BufferedReader bufferReader = new BufferedReader(reader);
					String codeStr = bufferReader.readLine();
					int code = Integer.parseInt(codeStr);
					LogUtil.d("upload userdata code=" + code);
					if (code == 0) {
						error = ErrorCode.RECOGNIZER_OK;
					} else if (code == -6) {
						error = ErrorCode.UPLOAD_USER_DATA_TOO_FAST;
					} else {
						error = ErrorCode.UPLOAD_USER_DATA_SERVER_REFUSED;
					}
				} else {
					error = ErrorCode.UPLOAD_USER_DATA_NETWORK_ERROR;
				}
			}
		} catch (Exception e) {
			error = ErrorCode.UPLOAD_USER_DATA_NETWORK_ERROR;
		}
		uploadUserDataState(error);
	}

}
