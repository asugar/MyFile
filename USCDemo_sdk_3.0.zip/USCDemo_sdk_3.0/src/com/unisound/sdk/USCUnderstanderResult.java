/**
 * USCUnderstandResult.java [V 1.0.0]
 * classes : cn.yunzhisheng.understand.USCUnderstandResult
 * liujunjie Create  at 2014-11-13  下午1:42:50
 */
package com.unisound.sdk;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * cn.yunzhisheng.understand.USCUnderstandResult
 * 
 * @author liujunjie <br/>
 *         Create at 2014-11-13 下午1:42:50 语义结果对象
 */
public class USCUnderstanderResult {

	private String stringResult = "";
	private String responsesText = "";
	private String requestText = "";
	private String scenario = "";

	public USCUnderstanderResult(String result) {
		this.stringResult = result;
		stringFormat(result);
	}

	/**
	 * 获取String 结果
	 * 
	 * @return
	 */
	public String getStringResult() {
		return stringResult;
	}

	/**
	 * 获取应答文本
	 * 
	 * @return
	 */
	public String getResponsesText() {
		return responsesText;
	}

	/**
	 * 获取请求的场景名称
	 * 
	 * @return
	 */
	public String getScenario() {
		return scenario;
	}

	/**
	 * 获取请求文本
	 * 
	 * @return
	 */
	public String getRequstText() {
		return requestText;
	}

	private boolean isStringEmpty(String str) {
		
		if (str != null && str.trim().length() != 0) {
			return false;
		}
		return true;
	}

	private boolean stringFormat(String result) {

		if (!isStringEmpty(result)) {
			try {
				JSONObject jsonResult = new JSONObject(result);
				if (jsonResult != null) {
					scenario = jsonResult.has("history") ? jsonResult
							.getString("history") : "";
					requestText = jsonResult.has("text") ? jsonResult
							.getString("text") : "";
					if (jsonResult.has("general")) {
						JSONObject general = jsonResult
								.getJSONObject("general");
						responsesText = general.has("text") ? general
								.getString("text") : "";
						return true;
					}
				}
			} catch (JSONException e) {
				e.printStackTrace();
				return false;
			}
		}
		return false;
	}

}
