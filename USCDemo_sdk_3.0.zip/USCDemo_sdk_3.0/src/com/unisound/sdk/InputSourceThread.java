package com.unisound.sdk;

import android.media.AudioFormat;
import cn.yunzhisheng.asr.VAD;
import cn.yunzhisheng.asr.VADParams;

import com.unisound.common.LogUtil;
import com.unisound.sdk.VADListener;

public abstract class InputSourceThread extends Thread {

	public static final int FREQUENCY_16K = VADParams.FREQUENCY_16K;
	protected static int CHANNEL = AudioFormat.CHANNEL_IN_MONO; // .CHANNEL_CONFIGURATION_MONO;
	protected static int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

	protected volatile boolean setToStopped = false; // asked to stop
	protected RecordingDataListener listener = null;
	protected VADParams vadParams = null;
	protected VAD vad = null;

	public InputSourceThread(VADParams vadParams, RecordingDataListener listener) {
		this.vadParams = vadParams;
		this.listener = listener;
		vad = new VAD(vadParams, listener);
		vad.init_();

	}

	public void stopRecording() {
		if(!isSetToStop()) {
			LogUtil.d("InputSourceThread::stopRecording");
			this.setToStopped = true;
		}
	}

	public boolean isSetToStop() {

		return setToStopped;
	}

	public boolean isCancel() {

		return listener == null;
	}

	public void cancel() {
		if (!isCancel()) {
			stopRecording();
			LogUtil.d("InputSourceThread::cancel");
			listener = null;
		}
	}

	protected void doRecordingStart(boolean success) {

		RecordingDataListener ls = listener;
		if (ls != null) {
			ls.onRecordingStart(success);
		}
	}

	protected abstract boolean open();

	protected abstract void close();

	protected abstract byte[] read();

	@Override
	public void run() {

		boolean error = false;
		try {
			if (open()) {

				doRecordingStart(true);

				while (!isSetToStop() && !isCancel()) {
					byte[] buffer = read();
					if (buffer != null) {
						vad.write(buffer, 0, buffer.length);
					} else {						
						Thread.sleep(20);
					}
				}

				if (listener != null) {
					vad.flush();
				}

			} else {
				doRecordingStart(false);
			}

		} catch (Exception e) {
			e.printStackTrace();
			error = true;
		} finally {
			close();
			vad.destory();
		}

		if (error) {
			doRecordingError();
		} else {
			doRecordingStop();
			LogUtil.d("recording stopped");
		}
	}

	protected void doRecordingStop() {

		RecordingDataListener ls = listener;
		if (ls != null) {
			ls.onRecordingStop();
		}
	}

	protected void doRecordingError() {

		RecordingDataListener ls = listener;
		if (ls != null) {
			ls.onRecordingError();
		}
	}

	public boolean isStopped() {
		return setToStopped;
	}

	public void waitEnd() {
		
		cancel();
		if (isAlive()) {
			try {
				join(4000);
				LogUtil.d("InputSourceThread::waitEnd()");
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}
	}
}