package com.unisound.sdk;

import com.unisound.common.RecordingListener;

public class RecordingHandle {
	

	private RecordingListener mRecordingListener = null;
	
	public void setListener(RecordingListener listener) {
		mRecordingListener = listener;
	}
	
	/**
	 * 是否设置监听，没有设置监听返回不可用状态
	 * @return
	 */
	public boolean isEnabled(){
		return mRecordingListener != null;
	}
	
//	public void onRecordingData(boolean enabled,byte[] data) {
//		
//		RecordingListener listener = mRecordingListener;
//		if (listener != null) {
//			listener.onRecordingData(enabled,data);
//		}		
//	}
	
	
	public void onUpdateVolume(int volume) {
		RecordingListener listener = mRecordingListener;
		if (listener != null) {
			listener.onUpdateVolume(volume);
		}	
	}
	
	
	public void onRecordingStart() {
		
		RecordingListener listener = mRecordingListener;
		if (listener != null) {
			listener.onRecordingStart();
		}	
	}
	
	public void onRecordingStop() {
		RecordingListener listener = mRecordingListener;
		if (listener != null) {
			listener.onRecordingStop();
		}	
	}
}
