package com.unisound.sdk;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.res.AssetManager;
import cn.yunzhisheng.asrfix.JniAsrFix;

import com.unisound.common.LogUtil;

public class ModelData {

	public String dataPath;


	public String[] models = new String[] { "tri", "l", "wid", "am",
			"digit", "wseg", "stat" };
	public String AM_FILE = "am";
	public String USER_FILE = "net";
	private String FILE_EXT = ".dat";
	public String ASR_DOMAIN = "main";
	public static final String DEF_MODEL_CONFIG = "ml";
//	public static final String FAR_MODEL_CONFIG = "ml_far";
	public boolean isInit = false;
	/**
	 * 模型文件是否进行CRC32校验
	 */
	public boolean checkCrc = false;
	public static final int SET_USER_DATA_OK = 0;
	public static final int SET_USER_DATA_ERROR = -100;
	public static final int SET_USER_DATA_WARNING = -200;
	public static final int SET_USER_ERROR = -300;
	public static int MAX_DAT_FILE_COUNT = 20;
	// public static final int SET_USER_EXCEPTION = -400;
	private static Compiler compiler = new Compiler();

	public ModelData() {

	}
	
	public String getNetFile() {
		return dataPath + USER_FILE +".dat";
	}

	public void setPath(String path) {
		dataPath = path + "/";
	}
	
	public boolean initModelList(Context context, String modleConfig) {

		try {
			AssetManager assets = context.getAssets();
			InputStream in = assets.open(modleConfig);
			InputStreamReader reader = new InputStreamReader(in);
			BufferedReader bufferReader = new BufferedReader(reader);
			String line;
			while ((line = bufferReader.readLine()) != null) {
				String items[] = line.split("=");
				if (items.length != 2) {
					continue;
				}
				String name = items[0].trim();
				String value = items[1].trim();
				if ("models".equals(name)) {
					models = value.split(",");
				} else if ("am".equals(name)) {
					AM_FILE = value;
				} else if ("custom".equals(name)) {
					USER_FILE = value;
				} else if ("domain".equals(name)) {
					ASR_DOMAIN = value;
				}
			}

			in.close();
			return true;

		} catch (Exception e) {
			LogUtil.e("model list error");
			e.printStackTrace();
		}
		return false;
	}

	public static boolean getFromAssets(AssetManager assets, String dir,
			String save) {
		FileOutputStream out = null;
		try {
			File file = new File(save);	
			out = new FileOutputStream(file);
			byte[] buffer = new byte[10240];

			if (MAX_DAT_FILE_COUNT == 1) {

				InputStream in = assets.open(dir + "/data");
				while (true) {
					int nRead = in.read(buffer, 0, buffer.length);
					if (nRead <= 0) {
						break;
					}
					out.write(buffer, 0, nRead);
				}
				in.close();
			} else {
				
				String[] files = assets.list(dir);
				for (int i = 0; i < files.length; i++) {
					InputStream in = assets.open(dir + "/" + files[i]);
					while (true) {
						int nRead = in.read(buffer, 0, buffer.length);
						if (nRead <= 0) {
							break;
						}
						out.write(buffer, 0, nRead);
					}
					in.close();
				}
			}
			return true;

		} catch (Exception e) {
			LogUtil.e("init asr model error");
			e.printStackTrace();
		} finally {
			
			try {
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * 加载模型开始标识
	 * 
	 * @param context
	 */
	public void setLoadModelBegin(Context context) {

		File version = new File(dataPath + "version");
		version.delete();
	}

	/**
	 * 加载模型失败标识
	 * 
	 * @param context
	 */
	public void setLoadModelSuccess(Context context) {
		getFromAssets(context.getAssets(), "version", dataPath + "version");
	}

	public static boolean getModelFromAssets(AssetManager assets, String dir,
			String save, boolean overwrite, boolean crcCheck) {

		if (false == overwrite) {
			File file = new File(save);
			if (file.exists()) {

				if (false == crcCheck) {
					return true;
				}

				if (JniAsrFix.checkFileByCrc32(save)) {
					return true;
				} else {
					LogUtil.e("reset model file " + save);
				}
			}
		}

		return getFromAssets(assets, dir, save);
	}

	public boolean findTag(String tag) {
		return false; // cn.yunzhisheng.asrfix.Compiler.findTag(tag);
	}

	public static boolean checkAMFile(String amFileName) {

		return JniAsrFix.checkFileByCrc32(amFileName);
	}

	public boolean updateAMFile(Context context, String amFileName) {

		if (false == isInit) {
			initData(context);
		}

		try {
			File outFile = new File(dataPath + AM_FILE + FILE_EXT);

			File inFile = new File(amFileName);
			FileInputStream in = new FileInputStream(inFile);
			FileOutputStream out = new FileOutputStream(outFile);
			byte[] buffer = new byte[10240];
			while (true) {
				int nRead = in.read(buffer, 0, buffer.length);
				if (nRead <= 0) {
					break;
				}
				out.write(buffer, 0, nRead);
			}
			in.close();
			out.close();
			return true;

		} catch (Exception e) {

			e.printStackTrace();
			LogUtil.e("setAMFile error");

			getFromAssets(context.getAssets(), AM_FILE, dataPath + AM_FILE
					+ FILE_EXT);
		}
		return false;
	}

	private boolean isUpdateModel(AssetManager assets, String versionFile) {

		boolean update = true;
		try {
			File file = new File(versionFile);
			if (false == file.exists()) {
				return update;
			}

			String newVersion = "";
			InputStream in = assets.open("version/data");
			byte buffer[] = new byte[20];
			int nRead = in.read(buffer, 0, buffer.length);
			if (nRead > 0) {
				newVersion = new String(buffer, 0, nRead).trim();
			}
			in.close();

			BufferedReader reader = new BufferedReader(new FileReader(file));
			String text = reader.readLine();
			if (text != null) {
				if (text.equals(newVersion)) {
					update = false;
				}
			}
			reader.close();

			return update;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	private boolean removeFile(String fileName) {

		File f = new File(fileName);
		if (f.exists()) {
			return f.delete();
		}

		return true;
	}

	/**
	 * 用户数据校验处理
	 * 
	 * @return
	 */
	public boolean checkCustomFile() {

		String fileName = dataPath + USER_FILE + FILE_EXT;
		if (false == JniAsrFix.checkFileByCrc32(fileName)) {
			removeFile(fileName);
			return false;
		}
		return true;
	}

	protected boolean initDataAnyModel(Context context) {

		isInit = false;
		synchronized (this) {
			AssetManager localAssetManager = context.getAssets();

			File localFile = new File(this.dataPath);
			if (false == localFile.exists()) {
				localFile.mkdirs();
			}

			boolean bool = isUpdateModel(localAssetManager, this.dataPath
					+ "version");
			if (bool) {
				LogUtil.v("init asr models..");
			}
			try {
				String[] arrayOfString1 = localAssetManager.list("models");
				byte[] arrayOfByte = new byte[10240];
				for (String str : arrayOfString1) {
					FileOutputStream localFileOutputStream = new FileOutputStream(
							this.dataPath + str);
					InputStream localInputStream = localAssetManager
							.open("models/" + str);
					while (true) {
						int k = localInputStream.read(arrayOfByte, 0,
								arrayOfByte.length);
						if (k <= 0) {
							break;
						}
						localFileOutputStream.write(arrayOfByte, 0, k);
					}
					localInputStream.close();
					localFileOutputStream.close();
				}

				if (bool) {
					LogUtil.v("init asr models ok");
					getFromAssets(localAssetManager, "version", this.dataPath
							+ "version");
				}
				isInit = true;
				return true;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return false;
	}

	/**
	 * 
	 * @param context
	 * @return
	 */
	public boolean initData(Context context) {

		return initData( context, false);
	}
	
	/**
	 * 
	 * @param context
	 * @param compilerOptimizeEnabled  编译速度优化(编译用模型提前加入内存减少加载时间)
	 * @return
	 */
	public boolean initData(Context context, boolean compilerOptimizeEnabled) {

		synchronized (this) {

			if (isInit) {
				return true;
			}

			AssetManager assets = context.getAssets();

			File file = new File(dataPath);
			if (false == file.exists()) {
				file.mkdirs();
			}

			boolean overwrite = isUpdateModel(assets, dataPath + "version");
			if (overwrite) {
				LogUtil.v("init asr models..");
			}

			checkCustomFile();

			for (String model : models) {
				
				if (false == getModelFromAssets(assets, model, dataPath + model
						+ ".dat", overwrite, checkCrc)) {
					return false;
				}
			}
			if (overwrite) {
				LogUtil.v("init asr models ok");
				getFromAssets(assets, "version", dataPath + "version");
			}
			
			if(!compiler.isInit() && compilerOptimizeEnabled) {
				compiler.init(dataPath);
			}
			isInit = true;
			return true;
		}
	}

	// private boolean compileDecodeNet(Context context) {
	//
	// try {
	// InputStream in = context.getAssets().open("test0.jsgf");
	// InputStreamReader reader = new InputStreamReader(in);
	// BufferedReader bufferReader = new BufferedReader(reader);
	// StringBuffer sb = new StringBuffer(1024 * 400);
	// String line;
	// while ((line = bufferReader.readLine()) != null) {
	// sb.append(line).append("\n");
	// }
	// reader.close();
	// in.close();
	//
	// JniAsrFix.compileDecodeNet(dataPath, sb.toString());
	// return true;
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	//
	// return false;
	// }

	public static boolean loadText(String modelDir, String key,
			StringBuffer userData) {

		try {
			String textFileName = modelDir + key;
			File file = new File(textFileName);
			if (false == file.exists()) {
				return true;
			}
			userData.append("<").append(key).append(">").append("\n");
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String text;
			while ((text = reader.readLine()) != null) {
				if (text.length() > 0) {
					userData.append(text).append("\n");
				}
			}
			userData.append("</").append(key).append(">").append("\n");
			reader.close();
			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public static boolean saveText(String modelDir, String key,
			List<String> list) {

		FileOutputStream out = null;
		try {
			String textFileName = modelDir + key;
			File file = new File(textFileName);
			out = new FileOutputStream(file);

			if (list != null) {
				Map<String, Object> map = new HashMap<String, Object>();
				for (String text : list) {
					if (text != null) {
						if (-1 == text.indexOf(">")) {
							text = text.replaceAll(">", "");
						}
						if (-1 != text.indexOf("<")) {
							text = text.replaceAll("<", "");
						}
						text = text.trim();
						if (text.length() > 0) {
							map.put(text, null);
						}
					}
				}

				byte[] newLine = "\n".getBytes();
				for (String text : map.keySet()) {
					byte buffer[] = text.getBytes();
					out.write(buffer);
					out.write(newLine);
				}
			}
			out.close();
			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			if (out != null) {
				out.close();
				out = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	private static void log_e(String log) {
		LogUtil.e(log);
	}

	public int setUserData(String netData) {
		int nRet = JniAsrFix.compileDecodeNet(dataPath, netData);
		if (0 == nRet) {
			return SET_USER_DATA_OK;
		}
		log_e("setUserData DecodeNet error:" + nRet);
		return SET_USER_ERROR;

	}

	public int setUserData(Map<String, List<String>> userData) {
		// int nRet = JniAsrFix.compileDecodeNet(dataPath, netData);
		// if( 0 == nRet ) {
		// return SET_USER_DATA_OK;
		// }
		// log_e("setUserData DecodeNet error:" + nRet);
		return SET_USER_ERROR;
	}

	public StringBuffer getCustom() {
		StringBuffer sb = new StringBuffer(1024 * 20);
		try {
			File file = new File(dataPath + USER_FILE + FILE_EXT);
			if (false == file.exists()) {
				return sb;
			}
			FileInputStream in = new FileInputStream(file);
			InputStreamReader reader = new InputStreamReader(in);
			BufferedReader bufferReader = new BufferedReader(reader);
			String line;
			while ((line = bufferReader.readLine()) != null) {
				sb.append(line).append("\n");
			}
			reader.close();
			in.close();

			return sb;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb;
	}

	public int compileUserData(String jsgf, String userData, String netDat) {
		File model = new File(netDat);
		if (model.exists()) {
			model.delete();
		} else {
			File dir = new File(model.getParent());
			if (!dir.exists()) {
				dir.mkdirs();
			}
		}

		
		int nRet = -1;
		if( compiler.isInit()) {
			// static compiler model in memory
			nRet = compiler.compile(jsgf, userData, netDat);
		}
		else {
			// temp compiler model in memory
			nRet = Compiler.compileUserData(jsgf, userData, dataPath, netDat);
		}

		if (0 == nRet) {
			return SET_USER_DATA_OK;
		}

		return SET_USER_ERROR;
	}

	public int compileUserData(String jsgf, String userData) {
		
		return compileUserData(jsgf, userData, this.getNetFile());
	}
	
	public boolean isExistUserData() {

		synchronized (this) {
			String fileName = dataPath + USER_FILE + FILE_EXT;
			return JniAsrFix.checkFileByCrc32(fileName);
		}
	}

	/**
	 * 获取当前模型大小
	 * 
	 * @return
	 */
	public int getModelSize() {

		try {
			synchronized (this) {
				File amFile = new File(dataPath + AM_FILE + FILE_EXT);
				if (amFile.exists()) {
					return (int) amFile.length();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogUtil.e("setAMFile error");
		}

		return 0;
	}


	public boolean resetModel(Context context) {

		synchronized (this) {

			AssetManager assets = context.getAssets();
			File file = new File(dataPath);
			if (false == file.exists()) {
				file.mkdirs();
			}

			if (getFromAssets(assets, AM_FILE, dataPath + AM_FILE + FILE_EXT) && true) {
				return true;
			}
		}
		return false;
	}

	public boolean isExistModel() {
		return JniAsrFix.checkFileByCrc32(dataPath + AM_FILE);
	}

	public boolean isEnabledAM(Context context,String modelConfig) {
		try {
			AssetManager assets = context.getAssets();
			String list[] = assets.list("");
			for(String fileName: list) {
				if(fileName.equals(modelConfig)) {
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public void unInit() {
		compiler.unInit();		
	}
}