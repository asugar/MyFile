package com.unisound.sdk;

public interface PrepareRecognizerListener {
	public int onPrepareRecognizer();
}
