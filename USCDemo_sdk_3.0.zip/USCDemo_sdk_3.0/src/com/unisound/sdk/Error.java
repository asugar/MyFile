package com.unisound.sdk;

/**
 * 错误类，返回错误码及描述
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class Error {
	private int mUSCErrorCode ;
	private String mErrorMSG ;
	public Error(int errorCode) {
		this.mUSCErrorCode = errorCode ;
	}
	
	/**
	 * 获取错误码
	 * @return 错误码
	 */
	public int getErrorCode(){
		return mUSCErrorCode;
	}
	
	/**
	 * 获取错误描述
	 * @return 返回描述信息
	 */
	public String getErrorDescription(){
		return mErrorMSG ;//TODO
	}

	
	/**
	 * 返回错误信息
	 * @return 错误码+错误描述
	 */
	@Override
	public String toString() {
		return "ErrorCode : "+mErrorMSG+" ; "+"ErrorDescription : "+mErrorMSG;//TODO
	}

}
