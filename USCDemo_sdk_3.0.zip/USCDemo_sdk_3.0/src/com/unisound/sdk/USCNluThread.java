package com.unisound.sdk;

import com.unisound.client.ErrorCode;
import com.unisound.common.DeviceInfoUtil;
import com.unisound.common.LogUtil;



public class USCNluThread  extends Thread{
	
	public static int VOICE_OGG_MAX_LENGTH = 150*1024;
	private String questionStr = "";
	private boolean  setStop = false;
	private USCNluListener  listener;
	private  USCNluParams   params;

	public USCNluThread(USCNluParams   params) {
            this.params = params;
	}
	
	private NluRequestPo buildNluRequest() {
		if (params != null) {
			NluRequestPo requestPo = new NluRequestPo(params.getAppkey(),
					params.getSecret());
			requestPo.setAppver(params.getAppver());
			return requestPo;
		}
		return null;
	}


	// 解析文本内容
	private String processing() {
		if(isStringEmpty(questionStr)){
			return null;
		}
		LogUtil.d("NLU processing begin");
		NluRequestPo requestPo = buildNluRequest();
		requestPo.setUrl(params.getNluServer());
		requestPo.setUdid(params.getUdid());
		requestPo.setHistory(params.getHistory());
		requestPo.setCity(params.getCity());
		requestPo.setScenario(params.getScenario());
		requestPo.setTime(USCNluParams.getCurrentTime()); 
		requestPo.setViewid(params.getViewid());
		requestPo.setUdid(DeviceInfoUtil.imei);
		requestPo.setText(questionStr); 
		USCNluClient sdk = new USCNluClient(); 
		String nluResult = sdk.getNluJsonResultForPost(requestPo); 
		return nluResult;
	}
	
	//添加文本内容
	public void  setData(String questionStr){
		this.questionStr = questionStr;
	}
	
	public void setNluStop(){
		setStop = true;
	}
	
	public boolean isNluStop(){
		return setStop;
	}
	
	public void  cancel(){
		setNluStop();
		listener = null;
	}
	
	public boolean isCancel(){
		return (listener==null);
	}
	
	@Override
	public void run() {
		super.run();
		int errorCode = 0;
		if (!setStop) {
			String nluResult = processing();
			if (nluResult == null) {
				errorCode = ErrorCode.NLU_REQUEST_EMPTY;
			} else if (nluResult.equals("{}")) {
				errorCode = ErrorCode.NLU_SERVER_ERROR;
			} else {
				doNluResult(nluResult);
			}
			doNluEnd(errorCode);
		}
	}
	
	private void doNluResult(String result){
		USCNluListener   nluListener = listener;
		if(nluListener!=null){
			nluListener.onResult(result);
		}
	}
	
	private void doNluEnd(int code){
		USCNluListener   nluListener = listener;
		if(nluListener!=null){
			nluListener.onEnd(code);
		}
	}
	
	private   boolean   isStringEmpty (String  str){
		if( str!=null && str.length() !=0 ){
			return false;
		}
		return true;
	}

	public void waitEnd(int mill) {
		cancel();
		if (isAlive()) {
			try {
				join(mill);
				LogUtil.d("USCNluThread::waitEnd()");
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}		
	}

	/**
	 * @param nluListener
	 */
	public void setNluListener(USCNluListener nluListener) {
		this.listener = nluListener;
		
	}
	
}