package com.unisound.sdk;

public class EncodeContent{
       
	public native int EncodeTotalContent(byte[] key, byte[] targetData, byte[] encodedData);
	public native int DecodeTotalContent(byte[] key, byte[] encodedData, byte[]decodedData);
	
}

