package com.unisound.sdk;

import java.util.ArrayList;
import java.util.List;

import android.media.AudioManager;
import android.text.TextUtils;

import com.unisound.common.Addresser;

public class TTSParams {

	public static String webPath = "ttsService/Authentication";

	public static String playPath = "ttsService/TTSServiceApi";

	public String userId = "";
	public String id = "";
	public String synthTextType = "";
	public String synthText = "";

	public static boolean ENABLED_REQ_RSP_ENTITY = true;
	public static boolean ENABLED_8K = false;
	private Addresser address = new Addresser("tr.hivoice.cn", 80, "tr.hivoice.cn", 80);
	private boolean startChunkMode = true;

	public int networkType = 0;

	public String isMD5 = null;
	public AudioFormat audioFormat = new AudioFormat();
	public int spxQuality = 8;
	public int resultTimeout = 20;
	/**
	 * 识别模型名称
	 */
	public boolean MODEL_TYPE_ENABLED = false;
	public boolean HTTP_TTS_ENABLED = false;
	public boolean PLAY_TTS_ENABLED = true;

	private static TTSParams instance;

	// -------------分割线
	private Boolean mDebug = false;// 是否打log
	private String mDebugDir;// 保存音频文件的路径
	private int mPlayStartBufferTime = 100;// TTSPlayThread.DEFAULT_PLAY_START_BUFFER_TIME;
	private float mVoiceSpeed = 50;
	private float mVoicePitch = 50;
	private float mVoiceVolume = 50;
	private String mVoiceName = "xiaoli";
	private int mSampleRate = 16 * 1000;
	private List<Integer> listField = new ArrayList<Integer>();
	private int mStreamType = AudioManager.STREAM_MUSIC;
	private String mAppKey;
	private String mSecret;
	private Integer mMode;

	private TTSParams() {
	}

	public static TTSParams getInstance() {
		if (instance == null) {
			instance = new TTSParams();
		}
		return instance;
	}

	public AudioFormat getAudioFormat() {
		return audioFormat;
	}

	public String getServerIP() {

		return address.getIP();
	}

	public int getServerPort() {

		return address.getPort();
	}

	public String getChunkMode() {
		if (!startChunkMode) {
			return "&user-agent=MIPlayer";
		}
		return "";
	}

	/**
	 * 重置域名解析
	 */
	public void resetDNS() {
		address.resetDNS();
	}

	public void setServer(String server, int port) {
		address.setDefaultServer(server);
		address.setDefaultPort(port);
		address.setServer(server);
		address.setPort(port);

	}

	/**
	 * 设置识别服务器地址
	 * 
	 * @param value
	 * @return
	 */
	private boolean setAddress(String address) {
		return this.address.setAddress(address);
	}

	/**
	 * 参数设置
	 * 
	 * @param key
	 * @param obj
	 */
	public boolean setOption(int key, Object obj) {
		return false;
	}

	/**
	 * 获取参数
	 * 
	 * @param key
	 */
	public Object getOption(int key) {
		return null;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSynthTextType() {
		return synthTextType;
	}

	public void setSynthTextType(String synthTextType) {
		this.synthTextType = synthTextType;
	}

	public String getSynthText() {
		return synthText;
	}

	public void setSynthText(String synthText) {
		this.synthText = synthText;
	}

	public Addresser getServerAddress() {
		return address;
	}

	// ------------------分割线
	public String getIsMD5() {
		return isMD5;
	}

	public void setIsMD5(String isMD5) {
		this.isMD5 = isMD5;
	}

	public Boolean getDebug() {
		return mDebug;
	}

	public void setDebug(Object mDebug) {
		boolean _debug = object2Boolean(mDebug);
		this.mDebug = _debug;
	}

	public String getDebugDir() {
		return mDebugDir;
	}

	public void setDebugDir(Object mDebugDir) {
		String _debugDir = object2String(mDebugDir);
		if (_debugDir == null) {
			return;
		}
		this.mDebugDir = _debugDir;
	}

	public String getVoiceName() {
		return mVoiceName;
	}

	public void setVoiceName(Object voiceName) {
		String _name = object2String(voiceName);
		if (_name == null) {
			return;
		}
		if (!isUseable(_name)) {
			return;
		} else {
			this.mVoiceName = _name;
		}

	}

	public float getVoiceSpeed() {
		return mVoiceSpeed;
	}

	public void setVoiceSpeed(Object voiceSpeed) {
		String _speed = object2String(voiceSpeed);
		if (_speed == null) {
			return;
		}
		if (!isUseable(_speed)) {
			return;
		} else {
			this.mVoiceSpeed = checkParams(_speed);
		}
	}

	public float getVoicePitch() {
		return mVoicePitch;
	}

	public void setVoicePitch(Object voicePitch) {
		String _pitch = object2String(voicePitch);
		if (_pitch == null) {
			return;
		}
		if (!isUseable(_pitch)) {
			return;
		} else {
			this.mVoicePitch = checkParams(_pitch);
		}

	}

	public float getVoiceVolume() {
		return mVoiceVolume;
	}

	public void setVoiceVolume(Object voiceVolume) {
		String _volume = object2String(voiceVolume);
		if (_volume == null) {
			return;
		}
		if (!isUseable(_volume)) {
			return;
		} else {
			this.mVoiceVolume = checkParams(_volume);
		}
	}

	public int getPlayStartBufferTime() {
		return mPlayStartBufferTime;
	}

	public void setPlayStartBufferTime(Object playStartBufferTime) {
		String _playStartBufferTime = object2String(playStartBufferTime);
		if (_playStartBufferTime == null) {
			return;
		}
		if (!isUseable(_playStartBufferTime)) {
			return;
		}
		this.mPlayStartBufferTime = Integer.valueOf(_playStartBufferTime);
	}

	private boolean isUseable(String value) {
		if (TextUtils.isEmpty(value) || !TextUtils.isDigitsOnly(value)) {
			return false;
		}
		return true;
	}

	private float checkParams(String value) {
		float _value = Integer.valueOf(value);
		if (_value < 0f) {
			_value = 1f;
		} else if (_value > 100f) {
			_value = 100f;
		}
		return _value;
	}

	public String object2String(Object obj) {
		if (obj == null) {
			return null;
		}
		if (obj instanceof String) {
			return (String) obj;
		}
		return null;
	}

	public int getSampleRate() {
		return mSampleRate;
	}

	/**
	 * 采样率，建议直接设为整数的形式
	 * 
	 * @param mSampleRate
	 */
	public void setSampleRate(Object mSampleRate) {
		String _sampleRate = object2String(mSampleRate);
		if (_sampleRate == null) {
			return;
		}
		if (!isUseable(_sampleRate)) {
			return;
		}
		int _SampleRate = Integer.valueOf(_sampleRate);
		switch (_SampleRate) {
			case 16000:
				break;
			case 8000:
				break;
			case 48000:
				this.mSampleRate = _SampleRate;
				break;
		}
	}

	/**
	 * 场景，建议直接设为整数
	 * 
	 * @param value
	 */
	public void addField(Object value) {
		String _field = object2String(value);
		if (_field == null) {
			return;
		}
		if (!isUseable(_field)) {
			return;
		}
		int field = Integer.valueOf(_field);
		listField.add(field);
	}

	public List<Integer> getField() {
		return listField;
	}

	/**
	 * 设置服务器
	 * 
	 * @param address
	 * @return
	 */
	public boolean setServerAddress(Object address) {
		String _address = object2String(address);
		if (_address == null) {
			return false;
		}
		return setAddress(_address);
	}

	public int getStreamType() {
		return mStreamType;
	}

	public void setStreamType(Object mStreamType) {
		Integer _streamType = object2Integer(mStreamType);
		if (_streamType == 0) {
			return;
		}
		this.mStreamType = _streamType;
	}

	public Integer object2Integer(Object obj) {
		if (obj == null) {
			return 0;
		}
		if (obj instanceof Integer) {
			return (Integer) obj;
		}
		return 0;
	}
	
	private boolean object2Boolean(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj instanceof Boolean) {
			return (Boolean) obj;
		}
		return false;
	}

	public String getAppKey() {
		return mAppKey;
	}

	public void setAppKey(String mAppKey) {
		this.mAppKey = mAppKey;
	}

	public String getSecret() {
		return mSecret;
	}

	public void setSecret(String mSecret) {
		this.mSecret = mSecret;
	}

	public Integer getMode() {
		return mMode;
	}

	public void setMode(Object mMode) {
		Integer _mode = object2Integer(mMode);
		if (_mode == 0) {
			return;
		}
		this.mMode = _mode;
	}

}
