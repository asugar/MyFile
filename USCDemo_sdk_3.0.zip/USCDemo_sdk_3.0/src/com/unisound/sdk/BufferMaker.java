package com.unisound.sdk;

import java.util.ArrayList;

public class BufferMaker {
	private final static int CAPCITY = 1024;
	private short[] mBuffer = new short[CAPCITY];
	private int mSize;

	public ArrayList<short[]> makeBuffer(short[] buffer, int len) {
		ArrayList<short[]> result = new ArrayList<short[]>(4);
		int begin = 0;
		int left = len;
		while (left > 0) {
			if (left <= CAPCITY - mSize) {
				int size = left;
				System.arraycopy(buffer, begin, mBuffer, mSize, size);
				mSize += size;
				begin += size;
				left -= size;
			} else {
				int size = CAPCITY - mSize;
				System.arraycopy(buffer, begin, mBuffer, mSize, size);
				result.add(mBuffer.clone());
				mSize = 0;
				begin += size;
				left -= size;
			}
		}
		return result;
	}

	public short[] flush() {
		if (mSize > 0) {
			short[] result = new short[mSize];
			System.arraycopy(mBuffer, 0, result, 0, mSize);
			return result;
		}
		return null;
	}
}
