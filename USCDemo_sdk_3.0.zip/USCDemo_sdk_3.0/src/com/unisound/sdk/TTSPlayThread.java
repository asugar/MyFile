package com.unisound.sdk;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import android.media.AudioFormat;
import android.text.TextUtils;

import com.unisound.common.LogUtil;

/**
 * @author USC tts播放基类
 */
public class TTSPlayThread extends TTSBaseThread {
	public static final String TAG = "TTSPlayThread";
	public static final int DEFAULT_PLAY_START_BUFFER_TIME = 300; // ms
	private static final SimpleDateFormat mDateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault());
	private static int WAIT_AUDIO_DATA_MILLISECONDS = 50;
	public static final int DEFAULT_PLAY_BUFFER_MILLISECONDS = 50; // ms

	private BlockingQueue<byte[]> mAudioBuffer = new LinkedBlockingQueue<byte[]>();

	private int mMinPlayBufferTime = DEFAULT_PLAY_START_BUFFER_TIME;
	private TTSPlayThreadListener mPlayerListener;
	private boolean mIsDataOver = false;
	private int mBufferDataSize = 0;
	private int mStreamType;
	private String mDebugFolder;
	private BlockingAudioTrack mAudioTrack = null;
	private boolean isPause = false;
	private boolean isPlaying = false;
	private Object lockObject = new Object();
	private static int mSampleRate = 16000;
	private Boolean isPlay = true;
	private Boolean isFirst = true;

	public TTSPlayThread(boolean debug, int streamType) {
		super(debug);
		mStreamType = streamType;
	}

	public void init(String debugFolder) {
		mDebugFolder = debugFolder;
	}

	public void addData(byte[] data) {
		mBufferDataSize += data.length;
		mAudioBuffer.add(data);
		if (isFirst) {
			onBufferBegin();
			isFirst = false;
		}
	}

	public void setIsPlay(Boolean is) {
		isPlay = is;
	}

	/**
	 * 播放语音缓冲时间
	 * 
	 * @param time
	 */
	public void setPlayBufferTime(int time) {
		if (time > 15000) {
			time = 15000;
		}
		mMinPlayBufferTime = time;
	}

	@Override
	public void run() {
		super.run();

		int retCode = TTSErrorCode.SUCCESS;
		File file = null;
		BufferedOutputStream mBufferOS = null;
		if (isDebug() && !TextUtils.isEmpty(mDebugFolder)) {
			file = new File(mDebugFolder, generateFileName());
			File parent = file.getParentFile();
			if (parent != null) {
				parent.mkdirs();
			}
			try {
				mBufferOS = new BufferedOutputStream(new FileOutputStream(file, true));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		mAudioTrack = new BlockingAudioTrack(mStreamType, mSampleRate, AudioFormat.ENCODING_PCM_16BIT, 1);
		mAudioTrack.init();
		int CACHE_TIME = mMinPlayBufferTime * 16000 * 2 / 1000;
		int PLAY_SIZE_IN_BYTES = DEFAULT_PLAY_BUFFER_MILLISECONDS * (16000 * 2 / 1000);

		try {
			while (!isPlay) {
				Thread.sleep(100);
			}
			while (!isStoped() && !isEnd() && mBufferDataSize < CACHE_TIME) {
				Thread.sleep(50);
			}
			onBufferReady();
			// 是否存在数据
			if (existData()) {
				mAudioTrack.start();
				onPlayingStart();

				while (!isStoped()) {

					byte[] buffer = mAudioBuffer.poll(WAIT_AUDIO_DATA_MILLISECONDS, TimeUnit.MILLISECONDS);
					if (buffer != null) {
						int bufferSize = buffer.length;
						int playSize = PLAY_SIZE_IN_BYTES;
						int offset = 0;
						while (bufferSize > 0 && !isStoped()) {

							synchronized (lockObject) {
								if (isPause) {
									LogUtil.d("lockObject wait...");
									onPlayingPause();
									lockObject.wait();
								} else {
									isPlaying = true;
								}
							}

							playSize = PLAY_SIZE_IN_BYTES;
							if (playSize > bufferSize) {
								playSize = bufferSize;
							}

							mAudioTrack.write(buffer, offset, playSize);
							offset += playSize;
							bufferSize -= playSize;
						}

						if (mBufferOS != null && isDebug()) {
							LogUtil.v(TAG + " play length:" + buffer.length);
							mBufferOS.write(buffer, 0, buffer.length);
						}
					} else if (isEnd()) {
						break;
					}
				}
				onPlayingStop();
			}
		} catch (Exception e) {
			e.printStackTrace();
			retCode = TTSErrorCode.PLAYING_EXCEPTION;

		} finally {
			mAudioTrack.stop();
			mAudioTrack.waitAndRelease();
			mAudioTrack = null;
			isPause = false;
			if (mBufferOS != null) {
				try {
					mBufferOS.flush();
					mBufferOS.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		onPlayingEnd(retCode);
		mBufferDataSize = 0;
	}

	private boolean isEnd() {
		return mIsDataOver;
	}
	
	private void onBufferBegin() {
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onBufferBegin();
		}
	}

	private void onBufferReady() {
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onBufferReady();
		}
	}

	private void onPlayingStart() {
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onPlayBegin();
		}
	}

	public void onPlayingEnd(int code) {
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onPlayEnd(code);
		}
	}

	private void onPlayingPause() {
		isPlaying = false;
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onPlayPause();
		}
	}

	private void onPlayingResume() {
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onPlayResume();
		}
	}
	
	private void onPlayingCancel() {
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onPlayCancel();
		}
		isPlaying = false;
	}
	
	private void onPlayingStop() {
		TTSPlayThreadListener listener = mPlayerListener;
		if (listener != null) {
			listener.onPlayStop();
		}
		isPlaying = false;
	}

	private String generateFileName() {
		return mDateFormat.format(new Date(System.currentTimeMillis())) + ".pcm";
	}

	public TTSPlayThreadListener getPlayerListener() {
		return mPlayerListener;
	}

	public void setPlayerListener(TTSPlayThreadListener listener) {
		mPlayerListener = listener;
	}

	public static byte[] toBytes(short[] input) {
		if (input == null) {
			return null;
		} else {
			byte[] result = new byte[input.length * 2];
			for (int i = 0; i < input.length; i++) {
				short s = input[i];
				result[i * 2] = (byte) (s & 0x00FF);
				result[i * 2 + 1] = (byte) ((s & 0xFF00) >> 8);
			}
			return result;
		}
	}

	public void dataOver() {
		mIsDataOver = true;
	}

	public void waitEnd(int millis) {

		if (isAlive()) {
			cancel();
			try {
				super.join(millis);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public boolean isCancel() {
		return mPlayerListener == null;
	}

	private boolean existData() {

		return mBufferDataSize > 0;
	}

	public void cancel() {
		mPlayerListener = null;
		mIsDataOver = true;
		reqStop();
		onPlayingCancel();
	}

	@Override
	public void reqStop() {
		super.reqStop();
		BlockingAudioTrack audioTrack = mAudioTrack;
		if (audioTrack != null) {
			playThreadNotify();
			audioTrack.stop();
			audioTrack = null;
		}
	}

	@Override
	public void reqPause() {
		super.reqPause();
		playThreadPause();
	}

	@Override
	public void reqResume() {
		super.reqResume();
		playThreadNotify();
	}

	public boolean isPlaying() {
		return isPlaying;
	}

	private void playThreadNotify() {
		synchronized (lockObject) {
			if (isPause) {
				isPause = false;
				LogUtil.d("lockObject notify..");
				lockObject.notify();
				onPlayingResume();
			}
		}
	}

	private void playThreadPause() {
		isPause = true;
	}

	public void setSampleRate(int rate) {
		mSampleRate = rate;
	}
}
