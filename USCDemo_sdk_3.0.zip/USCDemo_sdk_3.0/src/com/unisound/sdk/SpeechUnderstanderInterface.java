package com.unisound.sdk;

import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import cn.yunzhisheng.asr.VAD;

import com.unisound.client.ErrorCode;
import com.unisound.client.IAudioSource;
import com.unisound.client.SpeechConstants;
import com.unisound.client.SpeechUnderstanderListener;
import com.unisound.common.DeviceInfoUtil;
import com.unisound.common.LogUtil;
import com.unisound.common.USCSpeakerInfoSetting;
import com.unisound.common.USCSpeakerInformation;


/**
 * 提供语音识别+语义理解相关接口</br>
 * 通过setOption进行识别参数设置,支持云端识别、本地识别、云+端的混合模式 </br>
 * 初始化过程:</br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  配置audiosource,如果不配置将使用内置音频处理 </br>
 * (4)  通过loadModel加载模型 (optional)</br>
 * (5)  通过loadGrammar & insertVocab 加载动态数据 (optional)</br>
 * (6)  通过star开始识别 </br>
 * (7)  获取回调 </br>
 * (8)  结束本次识别 </br>
 * 编译及加载模型相关接口为非阻塞
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class SpeechUnderstanderInterface extends FixRecognizerInterface{
	private SpeechUnderstanderListener mSpeechUnderstanderListener ;
	private USCNluParams   nluParams;
	private static final String  ASR_JSON_NAME = "asr_recongize";
	private SpeechUnderstanderParams mSpeechUnderstanderParams ;
	/***
	 * 构造方法
	 * @param context  上下文环境
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	protected SpeechUnderstanderInterface(Context context, String appKey ,String secret) {
		super(context, appKey);
		mSpeechUnderstanderParams = new SpeechUnderstanderParams();
		nluParams = params.getNluParams();
		nluParams.setAppkey(appKey);
		nluParams.setSecret(secret);
		nluParams.setUdid( DeviceInfoUtil.imei);
		
		netRecognizer = new Recognizer(context, params);
		netRecognizer.setListener(netRecognizerListener);
		params.setAppKey(appKey);
	}
	
	/**
	 * 根据JsonStr初始化ASR引擎 
	 * @param JsonStr 初始化参数配置(Key&Value)
	 * @return 0 表示成功，否则返回相应错误码
	 * @see com.unisound.client.SpeechConstants
	 */
	protected int init(String JsonStr) {
		return 0;
	}
	
	/**
	 * 开始语音识别,使用默认模型
	 * 默认main标签 开始识别
	 */
	protected void start() {
		start(modelData.ASR_DOMAIN);
	}
	
	/**
	 * 开始语音识别,离线识别使用 grammar_tag 模型
	 * @param grammar_tag 模型识别标签
	 */
	protected void start(String grammar_tag) {
		recordingLimitTime.reset();
		netAsrSessionId = "";
		netEnd = false;
		fixEnd = false;
		
		netAsrInputSource = null;
		switch (engine) {
		case SpeechConstants.ASR_SERVICE_MODE_NET:
			fixEnd = true;
			recognizer.setAsrEnabled(false);
			netAsrInputSource = new InputPcmDataThread(params,netRecognizer);
			netRecognizer.start(netAsrInputSource);

			break;
		case SpeechConstants.ASR_SERVICE_MODE_MIX:
			netAsrInputSource = new InputPcmDataThread(params,netRecognizer);
			recognizer.setAsrEnabled(true);
			netRecognizer.start(netAsrInputSource);
			break;
		case SpeechConstants.ASR_SERVICE_MODE_LOCAL:
		default:
			netEnd = true;
			recognizer.setAsrEnabled(true);
		}

		super.start(grammar_tag);
	}
	
	/**
	 * 结束录音，停止本次语音识别，并回调相关结果,非阻塞</br>
	 * 先录音停止回调onEvent type=ASR_EVENT_RECORDING_STOP</br>
	 * 再完成识别回调onEvent type=ASR_EVENT_RECOGNIZITION_END，</br>
	 */
	protected void  stop(){
		super.stop();

		netAsrInputSource = null;
		netRecognizer.stop();
	}
	
	/**
	 * 取消本次语音识别,停止所有相关回调
	 */
	protected void cancel(){
		netEnd = true;
		fixEnd = true;
		recognizer.cancel(true);
		netRecognizer.cancel();
	}
	
	/**
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	protected void setListener(SpeechUnderstanderListener listener){
		this.mSpeechUnderstanderListener = listener ;
	}

//	/**
//	 * 设置是否同步请求语义结果
//	 * @param enable 默认为true 开启语义设置为true，关闭语义设置为false
//	 */
//	public void setNluEnable(boolean enable){
//		super.setNluEnable(enable);
//	}
	
	/**
	 * 设置可选项</br>
	 * 设置识别模式     {@link com.unisound.client.SpeechConstants#ASR_SERVICE_MODE} </br>
	 * 设置采样率 16000/8000{@link com.unisound.client.SpeechConstants#ASR_SAMPLING_RATE} </br>
	 * 设置在线识别带宽 {@link com.unisound.client.SpeechConstants#ASR_BANDWIDTH} </br>
	 * 设置识别领域     {@link com.unisound.client.SpeechConstants#ASR_DOMAIN} </br>
	 * 设置远近讲       {@link com.unisound.client.SpeechConstants#ASR_VOICE_FIELD} 默认为VOICE_FIELD_NEAR</br>
	 * 设置识别语言     {@link com.unisound.client.SpeechConstants#ASR_LANGUAGE} 默认LANGUAGE_MANDARIN </br>
	 * 设置 VAD前端点超时 {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_FRONTSIL} 范围 int 500~3000 (ms)</br>
	 * 设置VAD后端点超时  {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_BACKSIL} 范围 int 500~3000 (ms)</br>
	 * 设置语音解析服务器 {@link com.unisound.client.SpeechConstants#ASR_SERVER_ADDR} server=ip:port</br>
	 * 设置同步请求语义结果 {@link com.unisound.client.SpeechConstants#NLU_ENABLE} 默认同步请求语义</br>
	 * 设置语义理解场景   {@link com.unisound.client.SpeechConstants#NLU_SCENARIO} </br>
	 * 设置语义解析服务器 {@link com.unisound.client.SpeechConstants#NLU_SERVER_ADDR} server=ip:port </br>
	 * 设置UDID {@link com.unisound.client.SpeechConstants#GENERAL_UDID} server=ip:port </br>
	 * 设置云平台返回的历史信息 {@link com.unisound.client.SpeechConstants#GENERAL_HISTORY}</br>
	 * 设置解析城市信息 {@link com.unisound.client.SpeechConstants#GENERAL_CITY} </br>
	 * 设置语义日志ID     {@link com.unisound.client.SpeechConstants#GENERAL_VOICEID} </br>
	 * 设置网络交互超时   {@link com.unisound.client.SpeechConstants#ASR_NET_TIMEOUT} 范围 int 3000~10000 (ms)
	 * @param key
	 * @param value
	 * @see com.unisound.client.SpeechConstants
	 */
	protected void setOption(int key , Object value){
		switch (key) {
		case SpeechConstants.ASR_SERVICE_MODE:
			int v = (Integer) value;
			switch (v) {
				case SpeechConstants.ASR_SERVICE_MODE_LOCAL:
				case SpeechConstants.ASR_SERVICE_MODE_MIX:
				case SpeechConstants.ASR_SERVICE_MODE_NET:
					engine = v;
					break;
				default:
					LogUtil.e("USCMixRecognizer.setOption unkown value " + v);
					break;
			}
			break;
		case SpeechConstants.ASR_BANDWIDTH:
			
			break;
		case SpeechConstants.ASR_SAMPLING_RATE:
			setSampleRate((Integer)value);
			break;
		case SpeechConstants.ASR_DOMAIN:
			setNetEngine((String)value);
			break;
		case SpeechConstants.ASR_VOICE_FIELD:
			setFarFeild((Boolean) value);
			break;
		case SpeechConstants.ASR_LANGUAGE:
			setLanguage((String)value);
			break;
		case SpeechConstants.ASR_VAD_TIMEOUT_FRONTSIL:
			
			break;
		case SpeechConstants.ASR_VAD_TIMEOUT_BACKSIL:
			
			break;
		case SpeechConstants.ASR_SERVER_ADDR:
			params.setServer((String) value);
			break;
		case SpeechConstants.NLU_ENABLE:
			
			break;
		case SpeechConstants.NLU_SCENARIO:
			setNluScenario((String) value);
			break;
		case SpeechConstants.GENERAL_HISTORY:
			setNluHistory((String) value);
			break;
		case SpeechConstants.GENERAL_CITY:
			setNluCity((String) value);
			break;
		case SpeechConstants.GENERAL_VOICEID:
			setNluVoiceId((String) value);
			break;
		case SpeechConstants.ASR_NET_TIMEOUT:
			setNetGetResultTimeout((Integer)value);
			break;
			
		case SpeechConstants.GENERAL_UDID:
			setNluUdid((String) value);
			break;
			
		case SpeechConstants.GENERAL_UPDATE_VOLUME:
			mSpeechUnderstanderParams.setUpdateVolume((Integer)value);
			break;
		default:
			super.setOption(key, value);
			break;
		}
	}
	
	/**
	 * 获取可选项
	 * 对应 {@link com.unisound.client.SpeechUnderstander#setOption}
	 * @param key
	 * @return value 返回可选项
	 * @see com.unisound.client.SpeechConstants
	 */
	protected Object getOption(int key){
		switch (key) {
		case SpeechConstants.ASR_SERVICE_MODE:
			return engine;
		case SpeechConstants.ASR_BANDWIDTH:
			return null;
		case SpeechConstants.ASR_SAMPLING_RATE:
			return params.getRecordingSampleRate();
		case SpeechConstants.ASR_DOMAIN:
			return null;
		case SpeechConstants.ASR_VOICE_FIELD:
			return null;
		case SpeechConstants.ASR_LANGUAGE:
			return null;
		case SpeechConstants.ASR_VAD_TIMEOUT_FRONTSIL:
			return null;
		case SpeechConstants.ASR_VAD_TIMEOUT_BACKSIL:
			return null;
		case SpeechConstants.ASR_SERVER_ADDR:
			return null;
		case SpeechConstants.NLU_ENABLE:
			return null;
		case SpeechConstants.NLU_SCENARIO:
			return null;
		case SpeechConstants.GENERAL_HISTORY:
			return null;
		case SpeechConstants.GENERAL_CITY:
			return null;
		case SpeechConstants.GENERAL_VOICEID:
			return null;
		case SpeechConstants.ASR_NET_TIMEOUT:
			return netRecognizer.getTimeout();
		case SpeechConstants.ASR_SESSION_ID:
//			return netRecognizer.getSessionId();
			return netAsrSessionId;
		case SpeechConstants.GENERAL_UPDATE_VOLUME:
			return mSpeechUnderstanderParams.getUpdateVolume();
		default:
			return null;
		}
	}
	
	/**
	 * 上传用户词表，非阻塞 </br>
	 * 上传完成后回调onEvent type=　ASR_EVENT_USERDATA_UPLOADED</br>
	 * 用户设置命令词并上传，提高识别率</br>
	 * 如果当前为在线识别，则上传词表 </br>
	 * @param userData 用户词表
	 */
	protected void uploadUserData(Map<Integer, List<String>> userData) {
		netRecognizer.setUserData(userData);
	}
	
	/**
	 * 编译用户词表，非阻塞 </br>
	 * 编译完成后回调onEvent type=　ASR_EVENT_GRAMMAR_COMPILED</br>
	 * 用户自定义jsgf格式标准语法文件，语音识别系统可以根据此生成标准格式的识别语法 </br>
	 * 如果当前为离线识别，则编译编译模型</br>
	 * @param jsgfPath JSGF文件路径
	 * @param desFile 目标二进制文件
	 * @return 0 表示成功， 否则返回相应错误码
	 */
	protected int compileGrammar(String jsgfPath , String desFile) {
		return 0;
	}
	
//	/**
//	 * 接收外部录音数据进行识别
//	 * @param data
//	 * @param offset
//	 * @param length
//	 */
//	public void writeAudioData(byte[] data,int offset, int length){
//	}
	
	
	
	/**
	 * 获取版本信息
	 * @return 返回当前版本信息
	 */
	protected String getVersion(){
		return super.getVersion();
	}
	
	/**
	 * 返回当前状态 READY, RECOGNIZING, etc
	 * @return 当前状态 范围 int 0-2.
	 * @return 返回当前状态
	 */
	protected int getStatus() {
		return 0;
	}
	
	/**
	 * 加载模型，非阻塞</br>
	 * 加载完成后回调onEvent type=　ASR_EVENT_MODEL_LOADED
	 * @param modelFile 模型文件路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	protected int loadModel(String modelFile) {
		return super.loadModel(modelFile);
	}

	/**
	 * 预留，暂不支持</br>
	 * 加载用户字典， 用户字典用来对于一些用户自定义的特殊发音做标记
	 * @param userDictName 用户字典名称
	 * @param userDictPath 用户字典路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	protected int loadUserDict(String userDictName, String userDictPath) {return 0;}
	
	/**
	 * 用来设置 audiosource </br>
	 * 音频源需要实现打开录音,打开放音,关闭,读数据,取数据操作
	 * @param audioSource 相应音频源实现
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	protected int setAudioSource(IAudioSource audioSource) {return 0;}

//	/**
//	 * 设置 唤醒词 
//	 * @param wakeup
//	 * @return 0 表示成功， 否则返回相应错误码
//	 * @see com.unisound.client.ErrorCode
//	 */
//	public int setWakeupWord(String wakeup) {return 0;}
	
	/**
	 * 将识别参数以json格式批量输入到引擎,加入到目前识别中</br>
	 * 当postInfo和setOption设置同一参数时,以最新调用为准</br>
	 * 可设置参数请参考setoption</br>
	 * @param jsoninfo json格式的字符串，可以包含各种引擎参数，设备参数等.
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 * @see com.unisound.client.SpeechConstants
	 * @see com.unisound.client.SpeechUnderstander#setOption(int, Object)
	 */
	protected int postInfo(String jsoninfo) {
		return 0;
	}
	
	/**
	 * 加载二进制的grammar文件</br>
	 * 加载完成后回调onEvent type=　ASR_EVENT_GRAMMAR_LOADED
	 * @param grammarName
	 * @param grammarPath
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 * @see com.unisound.client.SpeechConstants
	 * @see com.unisound.client.SpeechUnderstanderListener#onEvent
	 */
	protected int loadGrammar(String grammarName, String grammarPath) {return 0;}
	
	/**
	 * 预留, 暂不支持</br>
	 * 把二进制的grammar文件插入相应的host grammar的槽内, 非阻塞</br>
	 * 插入完成后回调onEvent type=　ASR_GRAMMAR_INSERTED
	 * @param grammarName grammar名字
	 * @param grammarPath grammar路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	protected int insertGrammar(String grammarName,String grammarPath,String slotName) {return 0;}
	
	/**
	 * 预留, 暂不支持 </br>
	 * 把动态获得的用户信息插入相应的grammar内, 非阻塞 </br>
	 * 插入完成后回调onEvent type=　ASR_EVENT_VOCAB_INSERTED </br>
	 * 执行后即可start进行识别
	 * @param strList 用户信息列表 比如 联系人列表
	 * @param vocabName 词表名称比如contact,需要和grammar对应
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	protected int insertVocab (List<String> strList, String vocabName ){return 0;}
	
	/**
	 * 预留, 暂不支持</br>
	 * 保存当前Grammar到文件</br>
	 * @param grammarPath grammar保存路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	protected int saveCurGrammar (String grammarPath ){return 0;}
	
	/**
	 * 释放引擎
	 * 释放整个引擎  {@link com.unisound.client.SpeechConstants#ASR_RELEASE_ENGINE} </br>
 	 * 释放用户字典  预留 暂不支持{@link com.unisound.client.SpeechConstants#ASR_RELEASE_USERDICT} </br>
 	 * 释放语法  预留 暂不支持{@link com.unisound.client.SpeechConstants#ASR_RELEASE_GRAMMAR} </br>
 	 * 释放词表  预留 暂不支持{@link com.unisound.client.SpeechConstants#ASR_RELEASE_VOCAB} </br>
	 * @param type 
	 * @param dataName 
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	//	根据type值进行卸载</br>
	//	type</br>
	//	ASR_ENGINE</br>
	//	ASR_USERDICT</br>
	//	ASR_GRAMMAR</br>
	//	ASR_VOCAB</br>
	//	
	//	dataName:</br>
	//	null</br>
	//	userDictName</br>
	//	grammarName</br>
	//	vocabName</br>
	protected int release(int type , String dataName) {
		switch (type) {
		case SpeechConstants.ASR_RELEASE_ENGINE:
			super.release();
			return 0;
		default:
			return -1;
		}
	}
	
	/**
	 * 设置语义场景
	 * 
	 * @param scenario
	 *            场景
	 */
	private void setNluScenario(String scenario) {
		nluParams.setScenario(scenario);
	}

	/**
	 * 上一次访问语义云平台返回的history信息
	 * 
	 * @param history
	 *            历史信息
	 */
	private void setNluHistory(String history) {
		nluParams.setHistory(history);
	}
	
	/***
	 * 设置用户唯一标示
	 * 
	 * @param udid
	 *            用户标示
	 */
	private void setNluUdid(String udid) {
		nluParams.setUdid(udid);
	}

	/**
	 * 设置城市
	 * 
	 * @param city
	 *            城市
	 */
	private void setNluCity(String city) {
		nluParams.setCity(city);
	}

	/***
	 * 设置语义日志ID
	 * 
	 * @param voiceId
	 *            日志ID
	 */
	private void setNluVoiceId(String voiceId) {
		nluParams.setVoiceId(voiceId);
	}
	

//	USCRecognizerListener recognizerListener = new USCRecognizerListener() {
//
//		private void doNetEnd(USCError error) {
//			if (listener != null) {
//				listener.onNetEnd(error);
//			}
//		}
//		
//		@Override
//		public void onVADTimeout() {
//			if (listener != null) {
//				listener.onVADTimeout();
//			}
//		}
//
//		@Override
//		public void onUpdateVolume(int volume) {
//			if (listener != null) {
//				listener.onUpdateVolume(volume);
//			}
//		}
//
//		@Override
//		public void onRecognizerStart() {
//			if (listener != null) {
//				listener.onRecognizerStart();
//			}
//		}
//
//		@Override
//		public void onSpeechStart() {
//			if (listener != null) {
//				listener.onSpeechStart();
//			}
//		}
//
//		@Override
//		public void onNetResult(String result, boolean isLast) {
//			LogUtil.d("result: " + result);
//			if (listener != null) {
//				listener.onNetResult(jsonParse(result, ASR_JSON_NAME), isLast);
//				if (isLast) {
//					listener.onUnderstanderResult(asrResultToUnderstanderResult(result));
//				}
//			}
//		}
//
//		@Override
//		public void onNetEnd(USCError error) {
//            doNetEnd(error);
//		}
//
//		@Override
//		public void onFixEnd(USCError error) {
//			if (listener != null) {
//				listener.onFixEnd(error);
//			}
//		}
//
//		@Override
//		public void onCancel() {
//			if (listener != null) {
//				listener.onCancel();
//			}
//		}
//
//		@Override
//		public void onUploadUserData(USCError error) {
//			if (listener != null) {
//				listener.onUploadUserData(error);
//			}
//		}
//
//		@Override
//		public void onRecordingStop() {
//			if (listener != null) {
//				listener.onRecordingStop();
//			}
//		}
//
//		@Override
//		public void onRecordingDataStart() {
//			if (listener != null) {
//				listener.onRecordingDataStart();
//			}
//		}
//
//		@Override
//		public void onFixResult(List<String> result, float score) {
//			if (listener != null) {
//				listener.onFixResult(result, score);
//			}
//		}
//	};

	private  String  jsonParse(String jsonText, String name){
		JSONObject json;
		String result = "";
		try {
			json = new JSONObject(jsonText);
			result = json.has(name) ? json.getString(name) : "";
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	private USCUnderstanderResult asrResultToUnderstanderResult (String result){
		JSONObject json = null;
		try {
			json = new JSONObject(result);
			if(json.has(ASR_JSON_NAME)){ 
				json.remove(ASR_JSON_NAME);
				return new USCUnderstanderResult(json.toString().replace("\\/", "/"));
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 近讲、远讲选择
	 * 
	 * @param
	 */
	protected boolean setFarFeild(boolean farFeild) {
		if(!super.setFarFeild(farFeild)) {
			return false;
		}
		params.setFarFeild(farFeild);
		return true;
	}

	@Override
	protected void doFixResult(String result, boolean isLast) {
		if (mSpeechUnderstanderListener!=null) {
			if (recognizeResult.setResultList(result)) {
				mSpeechUnderstanderListener.onResult(SpeechConstants.ASR_RESULT_LOCAL, recognizeResult.items.toString()+recognizeResult.score);
			}
		}
	}


	@Override
	protected void doRecordingDataStart() {
		if (mSpeechUnderstanderListener!=null) {
			mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_RECORDING_START, (int)System.currentTimeMillis());
		}
	}

	protected void doCancel() {
		if (mSpeechUnderstanderListener!=null) {
			mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_CANCEL, (int)System.currentTimeMillis());
		}	
	}

	@Override
	protected void doUploadUserData(int error) {
		if (mSpeechUnderstanderListener!=null) {
			mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_USERDATA_UPLOADED, (int)System.currentTimeMillis());
		}	
	}

	@Override
	protected void doRecordingStop() {
		if (mSpeechUnderstanderListener!=null) {
			mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_RECORDING_STOP, (int)System.currentTimeMillis());
		}
	}
	
	public static final String LANGUAGE_ENGLISH = RecognizerParams.ENGLISH;
	public static final String LANGUAGE_CANTONESE = RecognizerParams.CANTONESE;
	public static final String LANGUAGE_CHINESE = RecognizerParams.CHINESE;
	
	private InputPcmDataThread netAsrInputSource = null;
	private boolean netEnd = true;
	private boolean fixEnd = true;
	private String netAsrSessionId = "";
	private int engine = SpeechConstants.ASR_SERVICE_MODE_MIX;
	private RecordingLimitTime recordingLimitTime = new RecordingLimitTime();
	protected Recognizer netRecognizer;

	public boolean isNetEnd() {
		return netEnd;
	}

	public boolean isFixEnd() {
		return fixEnd;
	}
	
	/**
	 * 获取在线识别返回的用户信息
	 * @return USCSpeakerInformation 返回为null 标示没有获取到用户信息,通常为网络错误引起.
	 */
	public USCSpeakerInformation getSpeakerInformation() {
		return netRecognizer.getSpeakerInformation();
	}
	
	/**
	 * 获取用户信息配置,通过配置选择从服务器获取的种类信息。
	 * @return USCSpeakerInfoSetting
	 */
	public USCSpeakerInfoSetting getSpeakerInfoSetting() {
		return netRecognizer.getSpeakerInfoSetting();
	}
	
	/**
	 * 设置识别请求ID获取监听
	 * @param listener
	 */
	public void setRequestIdListener(RequestIdListener listener) {
		netRecognizer.setRequestIdListener(listener);
	}

//	protected void start(String poi) {
//		recordingLimitTime.reset();
//		netAsrSessionId = "";
//		netEnd = false;
//		fixEnd = false;
//		
//		netAsrInputSource = null;
//		switch (engine) {
//		case ENGINE_ONLINE:
//			fixEnd = true;
//			recognizer.setAsrEnabled(false);
//			netAsrInputSource = new InputPcmDataThread(params,netRecognizer);
//			netRecognizer.start(netAsrInputSource);
//
//			break;
//		case ENGINE_MIX:
//			netAsrInputSource = new InputPcmDataThread(params,netRecognizer);
//			recognizer.setAsrEnabled(true);
//			netRecognizer.start(netAsrInputSource);
//			break;
//		case ENGINE_FIX:
//		default:
//			netEnd = true;
//			recognizer.setAsrEnabled(true);
//		}
//
//		super.start(poi);
//	}

	@Override
	protected void doEnd(int error) {
		fixEnd = true;
		if (mSpeechUnderstanderListener!=null) {
			mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_LOCAL_END, (int)System.currentTimeMillis());
		}

		if (error != MixErrorCode.FIX_RECOGNIZER_NO_INIT
				&& error != ErrorCode.RECOGNIZER_OK) {
			netEnd = true;
			netRecognizer.cancel();
			if (mSpeechUnderstanderListener!=null) {
				mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_NET_END, (int)System.currentTimeMillis());
			}
		}
	}

	@Override
	protected void doSpeechStart() {
		if (mSpeechUnderstanderListener!=null) {
			mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_SPEECH_DETECTED, (int)System.currentTimeMillis());
		}
	}

	/**
	 * 是否放弃启动录音
	 * 
	 * @return
	 */
	@Override
	protected boolean isStopRecording() {
		// 纯离线识别失败不再开启录音。
		if (engine == SpeechConstants.ASR_SERVICE_MODE_LOCAL) {
			return true;
		}
		return false;
	}

	@Override
	protected void doRecordingStart() {
		if (fixEnd && netEnd) {
			recognizer.cancel(false);
			netRecognizer.cancel();
		} else {
			if (mSpeechUnderstanderListener!=null) {
				mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_SPEECH_DETECTED, (int)System.currentTimeMillis());
			}
		}
	}

	@Override
	protected void doRecordingData(boolean enabled, byte[] data, int offset,
			int lenght) {
		
		super.doRecordingData(enabled, data, offset, lenght);
		InputPcmDataThread inputSource = netAsrInputSource;
		if(inputSource != null) {
			netRecognizer.onRecordingData(enabled, data, offset, lenght);
			//inputSource.writePcmData(data, offset, lenght);
		}
		// 录音时长超时判断
		if (recordingLimitTime.isTimeout(enabled, lenght)) {
		//	recognizer.onVADTimeout();
		}
	}

	/**
	 * 设置识别语音采样率 16000/8000
	 * 
	 * @param rate
	 */
	private void setSampleRate(int rate) {
		params.setSampleRate(rate);
	}

//	/**
//	 * 设置识别语音采样率 16000/8000
//	 * 
//	 * @param rate
//	 */
//	private void setBandwidth(int bw) {
//		netRecognizer.setRateParams(bw);
//	}
//	
//	
//	/**
//	 * 设置最大录音时间
//	 * @param max
//	 */
//	public void setMaxRecordingTime( int max ) {
//		
//		recordingLimitTime.setMaxTime(max);
//	}
	
	/**
	 * 在线识别监听
	 */
	private NetRecognizerListener netRecognizerListener = new NetRecognizerListener() {

		@Override
		public void onResult(String result, boolean isLast) {
			if (mSpeechUnderstanderListener!=null) {
				mSpeechUnderstanderListener.onResult(SpeechConstants.ASR_RESULT_NET, jsonParse(result, ASR_JSON_NAME));
				if (isLast) {
					mSpeechUnderstanderListener.onResult(SpeechConstants.ASR_RESULT_NLU, asrResultToUnderstanderResult(result).getStringResult());
				}
			}
		}

		@Override
		public void onEnd(int error) {
			// 保留在线识别Session ID
			netAsrSessionId = netRecognizer.getSessionId();

			if (error != 0) {
				if (SpeechConstants.ASR_SERVICE_MODE_NET == engine || fixEnd == true) {
					recognizer.cancel(false);
				}
			}

			netEnd = true;
			if (mSpeechUnderstanderListener!=null) {
				mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_NET_END, (int)System.currentTimeMillis());
			}
		}

		@Override
		public void onCancel() {
		}

		@Override
		public void onVADTimeout() {
		}

		@Override
		public void onUpdateVolume(int volume) {
		}

		@Override
		public void onUploadUserData(int error) {
			doUploadUserData(error);
		}

		public void onRecordingStop() {
		}

		public void onRecordingData(boolean enabled, byte[] data, int offset,
				int lenght) {
		}

		public void onRecognizerStart() {
		}

		public void onRecordingStart() {
		}

		@Override
		public void onSpeechStart() {

		}

		@Override
		public void onLogData(int what, int type, Object object) {
			
		}
	};

	/**
	 * 设置识别网络超时
	 * 
	 * @param millis
	 *            (毫秒)
	 */
	private void setNetGetResultTimeout(int millis) {

		netRecognizer.setTimeout(millis);
	}

	/**
	 * 设置识别参数
	 * 
	 * @param engine
	 */
	public boolean setNetEngine(String engine) {

		if (params.setModelType(engine)) {
			return true;
		}
		LogUtil.e("setNetEngine::error: unkown param " + engine);
		return false;
	}

	/**
	 * 该设置语言方法，分别用于设置中文，英文，和粤语
	 * 
	 * @param lang
	 *            取值 "chinese"中文，"english"英文，"cantonese"粤语
	 */
	private void setLanguage(String lang) {
		params.setLanguage(lang);
	}
	
	@Override
	protected void doUpdateVolume(int volume) {
		mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_VOLUMECHANGE,(int)System.currentTimeMillis());
		setOption(SpeechConstants.GENERAL_UPDATE_VOLUME,(int)volume);
	}
	
	@Override
	protected void doVADTimeout(VAD sender) {
		mSpeechUnderstanderListener.onEvent(SpeechConstants.ASR_EVENT_VAD_TIMEOUT,(int)System.currentTimeMillis());
	}
	

}
