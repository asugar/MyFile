package com.unisound.sdk;

public class RecognitionResult {
	
	public String text;
	public boolean isLast;
}
