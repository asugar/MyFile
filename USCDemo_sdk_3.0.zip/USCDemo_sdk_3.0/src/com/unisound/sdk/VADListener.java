package com.unisound.sdk;

import cn.yunzhisheng.asr.VAD;

public interface VADListener {
	public void onRecordingData(boolean enabled,byte[] data, int offset, int lenght);
	public void onSpeechStart();
	public void onUpdateVolume(int volume);
	public void onVADTimeout(VAD sender);
}
