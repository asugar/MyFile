package com.unisound.sdk;

import com.unisound.common.AsrSkinViewInterface;
import com.unisound.common.AsrSkinViewInterface.AsrSkinViewOperateListener;

/**
 * 皮肤界面事件监听，用于SDK 关联皮肤界面，二次封装类
 * 
 * @author zhangkj
 * 
 */

public class AsrSkinViewHandle {

	private AsrSkinViewInterface mAsrSkinViewInterface = null;
	private AsrSkinViewOperateListener mAsrSkinViewOperateListener = null;
	
	
	/**
	 * 是否设置监听，没有设置监听返回不可用状态
	 * @return
	 */
	public boolean isEnabled(){
		return mAsrSkinViewInterface != null;
	}

	
	public void setSkinViewOperateLinstener(AsrSkinViewOperateListener listener) {
		if(mAsrSkinViewInterface != null) {
			mAsrSkinViewInterface.setSkinViewOperateLinstener(listener);
		}
		mAsrSkinViewOperateListener = listener;
	}
	

	/**
	 * 识别结果状态回调
	 * 
	 * @param result
	 * @param isLast
	 */
	public void onResult(String result, boolean isLast) {

		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onResult( result,  isLast);
		}
	}

	/**
	 * 识别停止回调
	 * 
	 * @param error
	 */
	public void onEnd(int error) {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onEnd(error);
		}
	}

	/**
	 * 停止录音状态回调
	 */
	public void onRecordingStop() {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onRecordingStop();
		}
	}

	/**
	 * 录音开始状态回调
	 */
	public void onRecordingStart() {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onRecordingStart();
		}
	}

	/**
	 * 检测到说话开始状态回调
	 */
	public void onSpeechStart() {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onSpeechStart();
		}
	}


	public void onVADTimeout() {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onVADTimeout();
		}
		
	}


	public void onUpdateVolume(int volume) {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onUpdateVolume(volume);
		}
		
	}

	
	/**
	 * 取消状态回调
	 */
	public void onCancel() {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onCancel();
		}
	}

	public void setSkinViewInterface(AsrSkinViewInterface skinView) {

		mAsrSkinViewInterface = skinView;
		if(mAsrSkinViewInterface != null) {
			mAsrSkinViewInterface.setSkinViewOperateLinstener(mAsrSkinViewOperateListener);
		}
	}


	public void onStart() {
		AsrSkinViewInterface listener = mAsrSkinViewInterface;
		if (listener != null) {
			listener.onStart();
		}		
	}


}
