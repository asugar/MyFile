/**
 * RecordingDataListener.java [V 1.0.0]
 * classes : cn.yunzhisheng.wakeup.RecordingDataListener
 * liujunjie Create  at 2014-12-8  下午4:18:26
 */
package com.unisound.sdk;

/**
 * cn.yunzhisheng.wakeup.RecordingDataListener
 * @author  liujunjie <br/>
 * Create at 2014-12-8 下午4:18:26
 *
 */
public interface WakeUpRecordingDataListener {

	public void onRecordingData(byte[] data, int offset, int length);
}
