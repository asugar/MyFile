package com.unisound.sdk;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import cn.yunzhisheng.asrfix.JniAsrFix;

import com.unisound.sdk.RecognitionListener;
import com.unisound.client.ErrorCode;
import com.unisound.common.LogUtil;

public class FixRecognitionThreadInterface extends Thread{

	protected static long TIME_WAIT_RECORDING = 200; // ms
	
	protected BlockingQueue<byte[]> recordQueue = new LinkedBlockingQueue<byte[]>();

	protected PrepareRecognizerListener prepareRecognizer = null;
	protected RecognitionListener recognitionListener = null;
	protected FixRecognizerParams params = null;
	protected JniAsrFix jac = null;
	protected boolean setToStopped = false;
	protected boolean vadStop = false;
	protected String modelTag = "";
	
	public FixRecognitionThreadInterface(JniAsrFix jac, String modelTag, FixRecognizerParams params) {
		this.jac = jac;
		this.modelTag = modelTag;
		this.params = params;
	}

	@Override
	public void start() {
		super.start();
	}

	public void stopRecognition() {
		if(!setToStopped) {
			LogUtil.d("RecognitionThreadInterface::stopRecognition");
			setToStopped = true;
		}
	}

	public void addData(byte[] data) {
		recordQueue.add(data);
	}

	public void setListener(RecognitionListener listener) {
		recognitionListener = listener;
	}

	public void cancel() {
		
		if(!isCanceled()) {
			LogUtil.d("RecognitionThreadInterface::cancel");
			recognitionListener = null;
			setToStopped = true;
		}
	}

	public boolean isSetToStopped() {
		return setToStopped;
	}

	protected void log_i(String log) {
		LogUtil.i("RecognitionThreadInterface:"+ log);
	}

	protected void log_e(String log) {
		LogUtil.e("RecognitionThreadInterface:"+log);
	}

	protected void log_d(String log) {
		LogUtil.d("RecognitionThreadInterface:" + log);
	}


	@Override
	public void run() {

	}

	protected byte[] poll() throws InterruptedException {

		return recordQueue.poll(TIME_WAIT_RECORDING, TimeUnit.MILLISECONDS);
	}

	protected void doRecognitionError(int code) {

		log_d("doRecognitionMaxSpeechTimeout=" + code);
		RecognitionListener listener = recognitionListener;
		if (listener != null) {
			listener.onRecognitionError(code);
		}
	}

	protected void doRecognitionMaxSpeechTimeout() {
		log_i("doRecognitionMaxSpeechTimeout");
		RecognitionListener listener = recognitionListener;
		if (listener != null) {
			listener.onRecognitionMaxSpeechTimeout();
		}
	}
	
	
	protected void doRecognitionVADTimeout() {
		log_d("onRecognitionVADTimeout");
		RecognitionListener listener = recognitionListener;
		if (listener != null) {
			listener.onRecognitionVADTimeout();
		}
	}
	
	
	protected void doRecogintionLogData(int what, int type, Object object) {
		
		RecognitionListener listener = recognitionListener;
		if (listener != null) {
			listener.onLogData(what, type, object);
		}
	}
	
	protected void doRecognitionResult(String partial, boolean isLast) {
	
		log_d("doRecognitionResult partial=" + partial );
		RecognitionListener listener = recognitionListener;
		if (listener != null) {
			listener.onRecognitionResult(partial, true);
		}
	}

	/**
	 * 是否存在要处理的数据
	 * 
	 * @return
	 */
	protected boolean isExistAsrData() {

		if (recordQueue.size() == 0) {
			return false;
		}
		return true;
	}

	/**
	 * 是否取消识别
	 * 
	 * @return
	 */
	protected boolean isCanceled() {
		if( jac != null) {
			if( jac.isTryRelease()) {
				return true;
			}
		}
		return (recognitionListener == null);
	}

	protected void doRecognitionEnd() {
		RecognitionListener listener = recognitionListener;
		if (listener != null) {
			listener.onRecognitionEnd();
		}
	}
	
	/*
	 * 停止并等待识别结束
	 */
	public void waitEnd(boolean isCancel) {

		if (isCancel) {
			cancel();
		}

		if (isAlive()) {
			try {
				join(39000);
				LogUtil.d(this.getName()+ "waitEnd()");
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}
	}
	
	protected int doPrepareRecognizer() {
		if(prepareRecognizer != null) {
			return prepareRecognizer.onPrepareRecognizer();
		}
		return ErrorCode.RECOGNIZER_OK;
	}
	
	
	public void setPrepareRecognizer(PrepareRecognizerListener prepareRecognizer) {
		this.prepareRecognizer = prepareRecognizer;

	}
}


