package com.unisound.sdk;

import com.unisound.client.IAudioSource;
import com.unisound.client.VoicePrintRecognizerListener;
import android.content.Context;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.unisound.client.ErrorCode;
import com.unisound.client.SpeechConstants;
import com.unisound.common.AsrSkinViewInterface.AsrSkinViewOperateListener;
import com.unisound.common.BluetoothSetting;
import com.unisound.common.DataStroe;
import com.unisound.common.SceneManage;
import com.unisound.common.USCLogDataListener;
import com.unisound.common.USCRecognizerStatus;
import com.unisound.common.VoiceprintResult;
import com.unisound.common.VprHttpClient;
import com.unisound.common.WaveHeader;
import com.unisound.sdk.RecognizerParams.EngineFunction;
import android.media.AudioManager;
import android.util.Log;


/**
 * 提供声纹识别相关接口
 * 通过setOption进行语义理解参数设置 </br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  通过start传入用户标示和启动类型(注册|登陆),开始进行声纹识别 </br>
 * (4)  获取回调,得到语义理解json结果 </br>
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class VoicePrintRecognizerInterface{

	protected RecognizerParams params = new RecognizerParams();
	private VoicePrintRecognizerListener mVoicePrintRecognizerListener;
	private static SceneManage sceneManage = new SceneManage();
	protected ErrorCode errorCode = new ErrorCode();
	protected RecordingHandle recordingHandle = new RecordingHandle();
	protected VADTimeoutHandle vadTimeoutHandle = new VADTimeoutHandle();
	protected List<byte[]> recordingData = new ArrayList<byte[]>();

	private USCLogDataListener logListener;
	private Recognizer mRecognizer;
	private USCRecognizerStatus status = USCRecognizerStatus.idle;
	protected InputPcmDataThread inputPcmDataThread = null;
	private AsrSkinViewHandle asrSkinViewHandle = new AsrSkinViewHandle();
	private AudioManager audioManager;

	private String mRequestAudioServer = "117.121.49.3:10000";
	private String mAppkey;
	private String recordingDataFile = "";

	private boolean recordingEnabled = true;
	private boolean asrRateReal8k = false;
	private boolean isRecordingDataEnable = false;
	private boolean addRecordingDataWavHeader = true;
	// 是否保存录音
	private boolean isSaveRecordingData = false;
	// 保存的录音文件是否加入 wav头
	private boolean isAddWaveHeader = false;
    //是否启动蓝牙录音
	private boolean isStartBluetooth = false;
	private boolean isWaveHeaderExist = false;
	/** 是否保存VAD过滤的语音 */
	protected static boolean KEEP_FILTER_RECORDING_DATA = false;
	/**VPR声纹注册*/
	public static final int OPTION_VPR_TYPE_REGISTERED = VPRParams.VPR_TYPE_REGISTERED;
	/**VPR声纹验证*/
	public static final int OPTION_VPR_TYPE_VERIFY = VPRParams.VPR_TYPE_VERIFY;
	private int mVolume = 0;
	
	/**
	 * 声纹识别构造方法
	 * @param context
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	protected VoicePrintRecognizerInterface(Context context, String appKey,
			String secret) {
		mAppkey = appKey;
		params.setSecret(secret);
		params.setEngineFunction(EngineFunction.VPR);
		// params.setVADEnabled(false);
		params.setServer(VPRParams.VPR_ADDRESS);
		params.setPlayStartBeep(false);
		mRecognizer = new Recognizer(context, params);
		mRecognizer.setListener(recognizerListener);
		if (appKey != null) {
			params.setAppKey(appKey);
		}
		asrSkinViewHandle
				.setSkinViewOperateLinstener(asrSkinViewOperateListener);
		sceneManage.setParams(params);
		audioManager = (AudioManager) context
				.getSystemService(Context.AUDIO_SERVICE);
	}
	
	/**
	 * init 通过 jsonFile来配置系统启动参数
	 * @param JsonStr
	 * @return 如果为0 则表示成功，否则返回错误码
	 * @see 
	 */
	protected int init(String JsonStr) {
		return 0;
	}

	/**
	 * 启动声纹识别
	 * @param userName 用户标识
	 * @param Type 1:声纹注册 2:声纹登陆
	 */
	protected void start(String userName , int Type) {
		params.getVPRParams().setUserName(userName);
		params.getVPRParams().setVPRType(Type);
		start();
	}

	/**
	 * 停止录音，完成当前任务
	 */
	protected void stop() {
		runStop();
	}

	/**
	 * 放弃当前任务
	 */
	protected void cancel() {
		asrSkinViewHandle.onCancel();
		runCancel();
	}
	
	/**
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	protected void setListener(VoicePrintRecognizerListener listener){
		mVoicePrintRecognizerListener = listener;
	}
	
	/**
	 * 用来设置 audiosource 
	 * @param audioSource
	 * @return 0 表示成功， 否则返回相应错误码
	 */
	protected int setAudioSource(IAudioSource audioSource) {
		return 0;
	}
	/**
	 * 设置可选项</br>
	 * 设置采样率是否是8k 16000/8000{@link com.unisound.client.SpeechConstants#VPR_INPUT_8K} </br>
	 * 设置采样率是否是16k {@link com.unisound.client.SpeechConstants#VPR_INPUT_16k} </br>
	 * 设置识别SCENE    {@link com.unisound.client.SpeechConstants#VPR_SCENE_ID}</br>
	 * 添加Log监听对象    {@link com.unisound.client.SpeechConstants#VPR_LOG_LISTNER} </br>
	 * 保存录音数据    {@link com.unisound.client.SpeechConstants#VPR_SAVE_RECORDING_DATA} </br>
	 * 设置前端VAD是否可用 {@link com.unisound.client.SpeechConstants#VPR_FRONT_VAD_ENABLED} </br>
	 * 设置采样率  {@link com.unisound.client.SpeechConstants#VPR_SAMPLE_RATE}8k 或 16k</br>
	 * 设置是否开启蓝牙录音 {@link com.unisound.client.SpeechConstants#VPR_BLUETOOTH_ENABLED}</br>
	 * 设置前后端VAD超时{@link com.unisound.client.SpeechConstants#VPR_VAD_TIMEOUT} </br>
	 * 设置停止识别超时(ms)   {@link com.unisound.client.SpeechConstants#VPR_STOP_TIMEOUT} </br>
	 * 设置语义解析服务器 {@link com.unisound.client.SpeechConstants#VPR_SERVER_ADDR} server=ip:port </br>
	 * 设置获取注册语音数据的地址 {@link com.unisound.client.SpeechConstants#VPR_REQUEST_AUDIO_SERVER}</br>
	 * 设置远讲是否可用  {@link com.unisound.client.SpeechConstants#VPR_FARFILED_ENABLED}</br>
	 * 设置VPR的识别类型    {@link com.unisound.client.SpeechConstants#VPR_TYPE}VPRParams.VPR_TYPE_REGISTERED , VPRParams.VPR_TYPE_VPR_TYPE_VERIFY</br>
	 * 设置录音是否可用  {@link com.unisound.client.SpeechConstants#VPR_RECORDING_ENABLED}</br>
	 * 设置是否活取wav文件头   {@link com.unisound.client.SpeechConstants#VPR_GET_WAVE_DATA_ENABLED}</br>
	 * 设置用户名   {@link com.unisound.client.SpeechConstants#VPR_USERNAME}</br>
	 * @param key
	 * @param obj
	 * @see com.unisound.client.SpeechConstants
	 */
	protected void setOption(int key , Object obj){
		switch(key) {
		case SpeechConstants.VPR_SERVER_ADDR:
			params.setServer((String) obj);
			break;
		case SpeechConstants.VPR_INPUT_8K:
			asrRateReal8k = true;
			break;
		case SpeechConstants.VPR_INPUT_16k:
			asrRateReal8k = false;
			break;
		case SpeechConstants.VPR_SCENE_ID:
			params.setStartScene(sceneManage.findScene((String) obj));
			break;
		case SpeechConstants.VPR_LOG_LISTNER:
			this.logListener = (USCLogDataListener) obj;
			break;
		case SpeechConstants.VPR_SAVE_RECORDING_DATA:
			this.recordingDataFile = (String) obj;
			break;
		case SpeechConstants.VPR_FRONT_VAD_ENABLED:
			params.setFrontVadEnabled((Boolean)obj);
			break;
		case SpeechConstants.VPR_SAMPLE_RATE:
			params.setSampleRate((Integer)obj);
			break;
		case SpeechConstants.VPR_BLUETOOTH_ENABLED:
			this.isStartBluetooth = (Boolean)obj;
			break;
		case SpeechConstants.VPR_VAD_TIMEOUT:
			int[] sils = (int[])obj;
			params.setVADTimeout(sils[0],sils[1]);
			break;
		case SpeechConstants.VPR_STOP_TIMEOUT:
			mRecognizer.setTimeout((Integer)obj);
			break;
		case SpeechConstants.VPR_REQUEST_AUDIO_SERVER:
			mRequestAudioServer = (String)obj;
			break;
		case SpeechConstants.VPR_FARFILED_ENABLED:
			params.setFarFeild((Boolean)obj);
			break;
		case SpeechConstants.VPR_TYPE:
			params.getVPRParams().setVPRType((Integer)obj);
			break;
		case SpeechConstants.VPR_RECORDING_ENABLED:
			recordingEnabled = (Boolean) obj;
			if (!recordingEnabled) {
				params.setPlayStartBeep(false);
			}
			break;
		case SpeechConstants.VPR_GET_WAVE_DATA_ENABLED:
			isRecordingDataEnable = (Boolean) obj;
			break;
		case SpeechConstants.VPR_USERNAME:
			params.getVPRParams().setUserName((String)obj);
			break;
		}
	}
	
	/**
	 * 获取可选项
	 * @param key
	 * @return value 返回可选项
	 */
	protected Object getOption(int key){
		switch(key) {
		case SpeechConstants.VPR_SESSION_ID:
			return params.getSessionId();
		case SpeechConstants.VPR_GET_WAVE_HEADER:
			addWaveHeader();
			return recordingData;
		case SpeechConstants.VPR_USERNAME:
			return params.getVPRParams().getUserName();
		case SpeechConstants.VPR_EVENT_VOLUME_UPDATED:
			return mVolume;
		case SpeechConstants.VPR_STOP_TIMEOUT:
			return mRecognizer.getTimeout();
			default:
				break;
		}

		return null;
	}

	/**
	 * 识别调度类回调
	 */
	private NetRecognizerListener recognizerListener = new NetRecognizerListener() {
		@Override
		public void onResult(String result, boolean isLast) {
			asrSkinViewHandle.onResult(result, isLast);
			mVoicePrintRecognizerListener.onResult(SpeechConstants.VPR_RESULT, new VoiceprintResult(result));
		}

		@Override
		public void onEnd(int error) {
			status = USCRecognizerStatus.idle;
			asrSkinViewHandle.onEnd(error);
			if (error != 0) {
				mVoicePrintRecognizerListener.onError(SpeechConstants.VPR_ERROR, errorCode.toMessage(error));
			}
			mVoicePrintRecognizerListener.onEvent(SpeechConstants.VPR_EVENT_RECOGNITION_END, (int)System.currentTimeMillis());
		}

		@Override
		public void onVADTimeout() {
			asrSkinViewHandle.onVADTimeout();
			vadTimeoutHandle.onVADTimeout();
			if (!asrSkinViewHandle.isEnabled() &&
					!vadTimeoutHandle.isEnabled()) {
				// 主动sotp
				stop();
			}
			mVoicePrintRecognizerListener.onEvent(SpeechConstants.VPR_VAD_TIMEOUT, (int)System.currentTimeMillis());
		}

		@Override
		public void onUpdateVolume(int volume) {
			asrSkinViewHandle.onUpdateVolume(volume);
			recordingHandle.onUpdateVolume(volume);
			mVolume = volume;
			mVoicePrintRecognizerListener.onEvent(SpeechConstants.VPR_EVENT_VOLUME_UPDATED, (int)System.currentTimeMillis());
		}

		@Override
		public void onUploadUserData(int error) {
		}

		@Override
		public void onRecordingStop() {
			asrSkinViewHandle.onRecordingStop();
			recordingHandle.onRecordingStop();
			doRecordingStop();
			mVoicePrintRecognizerListener.onEvent(SpeechConstants.VPR_EVENT_RECORDING_STOP, (int)System.currentTimeMillis());
		}

		@Override
		public void onRecordingStart() {
			asrSkinViewHandle.onRecordingStart();
			recordingHandle.onRecordingStart();
			mVoicePrintRecognizerListener.onEvent(SpeechConstants.VPR_EVENT_RECORDING_START, (int)System.currentTimeMillis());
		}

		@Override
		public void onRecordingData(boolean enabled, byte[] data, int offset,
				int lenght) {
			doRecordingData(enabled, data, offset, lenght);
		}

		@Override
		public void onRecognizerStart() {
			asrSkinViewHandle.onRecordingStart();
			recordingHandle.onRecordingStart();
			mVoicePrintRecognizerListener.onEvent(SpeechConstants.VPR_EVENT_RECOGNITION_START, (int)System.currentTimeMillis());
		}

		@Override
		public void onSpeechStart() {
			asrSkinViewHandle.onSpeechStart();
			mVoicePrintRecognizerListener.onEvent(SpeechConstants.VPR_EVENT_SPEECH_START, (int)System.currentTimeMillis());
		}

		@Override
		public void onCancel() {
		}

		@Override
		public void onLogData(int what, int type, Object object) {
			doLogData(what, type, object);
		}
	};

	protected void doLogData(int what, int type, Object object) {
		if (logListener != null) {
			logListener.onLogData(what, type, object);
		}
	}

	private void resetSaveRecordInfo() {
		recordingDataFile = "";
		isSaveRecordingData = false;
		isAddWaveHeader = false;
	}

	protected void doRecordingData(boolean enabled, byte[] data, int offset,
			int lenght) {

		if (isRecordingDataEnable && enabled || KEEP_FILTER_RECORDING_DATA) {
			recordingData.add(data);
		}
		if (isSaveRecordingData) {
			DataStroe.saveRecordingData(data, recordingDataFile);
			Log.d("VoicePrintRecognizerInterface : ","doRecordingData........");
		}
	}

	protected void runStart() {
		status = USCRecognizerStatus.recording;
		// 外部输入语音识别指定8k是进行8k识别
		params.setRateReal8k(asrRateReal8k && !recordingEnabled);
		// reset status
		inputPcmDataThread = null;
        if(isStartBluetooth){
        	audioManager.setBluetoothScoOn(true);
        	audioManager.startBluetoothSco();
        }
		if (recordingEnabled) {
			RecordingThread.waitRecordingEnd();
			mRecognizer.start(new RecordingThread(params, mRecognizer));
		} else {
			inputPcmDataThread = new InputPcmDataThread(params, mRecognizer);
			mRecognizer.start(inputPcmDataThread);
		}
		isWaveHeaderExist = false;
		if (isRecordingDataEnable) {
			recordingData = new ArrayList<byte[]>();
		}

		isSaveRecordingData = DataStroe
				.checkRecordingFileNameisValid(recordingDataFile);
		if (isSaveRecordingData) {
			isAddWaveHeader = DataStroe.isWaveFile(recordingDataFile);
		}
	}

	private void addWaveHeader() {
		if (isRecordingDataEnable && addRecordingDataWavHeader
				&& !isWaveHeaderExist) {
			isWaveHeaderExist = true;
			// PCM加文件名
			int lenght = 0;
			for (byte[] pcm : recordingData) {
				lenght += pcm.length;
			}
			if (lenght > 0) {
				byte[] header = WaveHeader.getHeader(lenght, 1, 16000);
				if (header != null) {
					recordingData.add(0, header);
				}
			}
		}
	}

	protected void runCancel() {
		status = USCRecognizerStatus.idle;
		mRecognizer.cancel();
	}

	protected void runStop() {
		status = USCRecognizerStatus.recognizing;
		inputPcmDataThread = null;
		mRecognizer.stop();
		if(audioManager.isBluetoothScoOn()){
			audioManager.setBluetoothScoOn(false);
			audioManager.stopBluetoothSco();
		}
	}

	protected void start() {
		asrSkinViewHandle.onStart();
		runStart();
	}

	/**
	 * 启用蓝牙录音输入
	 * @param context
	 */
	protected boolean startBluetoothSco(Context context) {
		return BluetoothSetting.startBluetoothSco(context);
	}

	/**
	 * 停用蓝牙录音输入,
	 * @param context
	 */
	protected boolean stopBluetoothSco(Context context) {

		return BluetoothSetting.stopBluetoothSco(context);
	}

	public void writePcmData(byte[] data, int offset, int lenght) {

		if (!recordingEnabled && data != null && lenght > 0) {
			InputPcmDataThread input = inputPcmDataThread;
			if (input != null) {
				input.writePcmData(data, offset, lenght);
			}
		}
	}

	/***
	 * 识别语音文件
	 * @param voiceFile
	 *            文件路径
	 */
	protected void recognitionOfSpeechFile(String voiceFile) {
		if (!DataStroe.checkVoiceFileValid(voiceFile)) {
			return;
		}
		inputPcmDataThread = new InputPcmDataThread(params, mRecognizer);
		mRecognizer.start(inputPcmDataThread);
		try {
			DataStroe.writeVoiceData(voiceFile, inputPcmDataThread);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			mRecognizer.stop();
		}
	}

	/**
	 * 皮肤界面状态回调
	 */
	private AsrSkinViewOperateListener asrSkinViewOperateListener = new AsrSkinViewOperateListener() {

		@Override
		public void onSkinViewStop() {
			runStop();
		}

		@Override
		public void onSkinViewStart() {
			runStart();
		}

		@Override
		public void onSkinViewCancel() {
			runCancel();
		}
	};

	protected void doRecordingStop() {
		addWaveHeader();
		// 判断是否给语音文件加入wav头
		if (isSaveRecordingData && isAddWaveHeader) {
			DataStroe.addWaveHeader(recordingDataFile);
		}
		resetSaveRecordInfo();
	}

	/**
	 * 根据requestID获得VPR语音
	 * @param requestID
	 * @param audioFilePath
	 * @return
	 */
	public boolean getRequestAudio(String requestID,final String audioFile) {
		final String urlString = "http://" + mRequestAudioServer + "/s/get.do?appKey=" + mAppkey + "&&rid=" + requestID;
		return VprHttpClient.getVPRAudio(urlString, audioFile);
	}
}
