/**
 * USCAsyncTask.java [V 1.0.0]
 * classes : cn.yunzhisheng.ttslib.USCAsyncTask
 * liujunjie Create  at 2014-3-6  下午7:29:57
 */
package com.unisound.sdk;

import android.os.AsyncTask;

import com.unisound.common.LogUtil;

/**
 * 异步加载工具类
 * 
 * @author liujunjie <br/>
 *         Create at 2014-3-6 下午7:29:57
 * 
 */
public class USCAsyncTask {

	private Object[] params;
	private boolean isRun = false;

	public interface USCAsyncTaskCallback {

		Object onRun(Object... params);

		void onEnd(Object obj);
	}

	class USCTask extends AsyncTask<Object, Object, Object> {

		USCAsyncTaskCallback callback;

		public void cancel() {
			callback = null;
		}

		public USCTask(USCAsyncTaskCallback callback) {
			super();
			this.callback = callback;
		}

		@Override
		protected void onPostExecute(Object result) {
			super.onPostExecute(result);
			isRun = false;
			this.callback.onEnd(result);
		}

		@Override
		protected void onPreExecute() {
			isRun = true;
			super.onPreExecute();

		}

		@Override
		protected Object doInBackground(Object... params) {
			LogUtil.e("USCAsyncTask:" + params);
			return this.callback.onRun(params);

		}

	}

	public void setParams(Object... params) {
		this.params = params;
	}

	USCAsyncTaskCallback callback;
	USCTask task = null;

	public USCAsyncTask(USCAsyncTaskCallback callback) {
		this.callback = callback;
	}

	public void start() {
		cancel();
		task = new USCTask(callback);
		if (params != null) {
			task.execute(params);
		}

	}

	public void cancel() {
		if (task != null) {
			task.cancel();
			task = null;
		}
	}

	public boolean isRunning() {
		return isRun;
	}

}
