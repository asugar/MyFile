package com.unisound.sdk;



public interface BasicRecognizerListener {

	public void onRecognizerStart();
	public void onVADTimeout();
	public void onUpdateVolume(int volume);
}
