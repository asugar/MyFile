/**
 * YzsNluListener.java [V 1.0.0]
 * classes : cn.yunzhisheng.nlu.YzsNluListener
 * liujunjie Create  at 2014-11-10  下午3:50:52
 */
package com.unisound.sdk;


/**
 * cn.yunzhisheng.nlu.YzsNluListener
 * @author  liujunjie <br/>
 * Create at 2014-11-10 下午3:50:52
 *
 */
public interface USCNluListener {
	
	public void  onResult(String result);
	public void  onEnd(int code);

}
