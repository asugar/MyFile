package com.unisound.sdk;
/**
 *	语言合成参数
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
class SpeechUnderstanderParams {
	private int updateVolume = 0;
	protected SpeechUnderstanderParams() {
	}

	protected String getParams(String key){
		return "";
	}

	protected int getUpdateVolume() {
		return updateVolume;
	}

	protected void setUpdateVolume(int updateVolume) {
		this.updateVolume = updateVolume;
	}
	
	
}
