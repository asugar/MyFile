package com.unisound.sdk;

/**
 *	语言合成参数
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
class SpeechSynthesizerParams {
	
	protected SpeechSynthesizerParams() {
	}

	protected String getParams(String key){
		return "";//TODO
	}
}
