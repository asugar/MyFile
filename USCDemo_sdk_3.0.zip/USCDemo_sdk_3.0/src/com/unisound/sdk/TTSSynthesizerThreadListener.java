package com.unisound.sdk;

/**
 * @author USC 合成线程接口
 */
public interface TTSSynthesizerThreadListener {

	/**
	 * 合成开始
	 */
	public void onSynthesizerBegin();

	/**
	 * 正在合成
	 * 
	 * @param pdata
	 * @param length
	 */
	public void onSynthesizerProcess(byte[] pdata, int length);

	/**
	 * 合成结束
	 */
	public void onSynthesizerEnd();
	
	/**
	 * 释放资源
	 */
	public void onSynthesizerRelease();
	
	// 目前之前上面三个接口方法

	/**
	 * 合成暂停
	 */
	public void onSynthesizerPause();

	/**
	 * 合成恢复
	 */
	public void onSynthesizerResume();

	/***
	 * 取消合成
	 */
	public void onSynthesizerCancel();
	
	/**
	 * 停止合成
	 */
	public void onSynthesizerStop();

	/**
	 * 合成错误
	 * 
	 * @param error
	 *            合成错误详情
	 */
	public void onSynthesizerError(USCError error);

}
