package com.unisound.sdk;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import cn.yunzhisheng.tts.offline.lib.YzsTts;

import com.unisound.client.IAudioSource;
import com.unisound.client.SpeechConstants;
import com.unisound.client.SpeechSynthesizerListener;
import com.unisound.common.DeviceInfoUtil;
import com.unisound.common.ErrorCode;
import com.unisound.common.LogUtil;
import com.unisound.common.MainMessageHandler;
import com.unisound.common.MainMessageHandler.HandlerMessageListener;
import com.unisound.common.MsgValue;
import com.unisound.common.SdkVersion;
import com.unisound.sdk.USCAsyncTask.USCAsyncTaskCallback;

/**
 * TTS合成基类 </br>
 * @author unisound 
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class SpeechSynthesizerInterface {

	public static final String TAG = "OfflineTTS";

	private YzsTts mTts = YzsTts.getInstance();

	private TTSOfflineSynthesizerThread mOfflineSynthesizeThread;// 离线合成线程
	private TTSOnlineSynthesizerThread mOnlineSynthesizerThread;// 在线合成线程
	// 合成监听器
	private TTSPlayThread mTTSPlayThread;// 播放线程
	// 播放监听器
	private SpeechSynthesizerListener mPlayerCallback;// 需要外部注册的监听器
	private MainMessageHandler msgHandler;

	private TtsModelData mModelData = TtsModelData.getInstance();
	private Context mContext;

	private boolean isSynthesizerEnd = true;
	private int status = 0;
	// private String mDebugDir;
	// private boolean mDebug = false;

	private TTSParams params = TTSParams.getInstance();
	private String sessionId = "";
	private boolean isOnlySynthesizer = false;

	// 合成监听器，在其关联类中注册
	private TTSSynthesizerThreadListener mSynthesizerListener = new TTSSynthesizerThreadListener() {

		@Override
		public void onSynthesizerBegin() {
			msgHandler.sendMessage(MsgValue.MESSAGE_SYNTHESIZE_BEGIN);
		}

		@Override
		public void onSynthesizerProcess(byte[] pdata, int length) {

			byte[] buffer = new byte[length];
			System.arraycopy(pdata, 0, buffer, 0, length);

			if (mTTSPlayThread != null) {
				mTTSPlayThread.addData(buffer);
			}

			if (mPlayerCallback != null) {
				// mPlayerCallback.onTtsData(buffer);
			}
		}

		@Override
		public void onSynthesizerEnd() {
			if (mTTSPlayThread != null) {
				mTTSPlayThread.dataOver();
				msgHandler.sendMessage(MsgValue.MESSAGE_SYNTHESIZE_END);
			}
		}

		@Override
		public void onSynthesizerRelease() {
			msgHandler.sendMessage(MsgValue.MESSAGE_RELEASE);
		}

		@Override
		public void onSynthesizerPause() {
		}

		@Override
		public void onSynthesizerResume() {
		}

		@Override
		public void onSynthesizerCancel() {
		}

		@Override
		public void onSynthesizerStop() {
		}

		@Override
		public void onSynthesizerError(USCError error) {
			msgHandler.sendMessage(MsgValue.MESSAGE_ERROR);
		}
	};

	// 播放监听器，在其关联类中注册，这个接口也是回调到外面的那个接口
	private TTSPlayThreadListener mPlayerListener = new TTSPlayThreadListener() {

		@Override
		public void onBufferBegin() {
			msgHandler.sendMessage(MsgValue.MESSAGE_BUFFER_BEGIN);
		}

		@Override
		public void onBufferReady() {
			msgHandler.sendMessage(MsgValue.MESSAGE_BUFFER_READY);
		}

		@Override
		public void onPlayBegin() {
			msgHandler.sendMessage(MsgValue.MESSAGE_PLAY_BEGIN);
		}

		@Override
		public void onPlayEnd(int code) {
			msgHandler.sendMessage(MsgValue.MESSAGE_PLAY_END);
			// 暂时
			isSynthesizerEnd = true;
		}

		@Override
		public void onPlayCancel() {
			msgHandler.sendMessage(MsgValue.MESSAGE_CANCEL);
		}

		@Override
		public void onPlayError(USCError error) {
			msgHandler.sendMessage(MsgValue.MESSAGE_ERROR, error);
		}

		@Override
		public void onPlayPause() {
			msgHandler.sendMessage(MsgValue.MESSAGE_PAUSE);
		}

		@Override
		public void onPlayResume() {
			msgHandler.sendMessage(MsgValue.MESSAGE_RESUME);
		}

		@Override
		public void onPlayStop() {
			msgHandler.sendMessage(MsgValue.MESSAGE_STOP);
		}

	};

	public void sendErrorMessage(int error) {
		msgHandler.sendMessage(MsgValue.MESSAGE_ERROR, ErrorCode.toError(error));
	}

	public SpeechSynthesizerInterface(Context context, String appKey, String secret) {
		mContext = context;
		params.setAppKey(appKey);
		params.setSecret(secret);
		msgHandler = new MainMessageHandler(handlerMessageListener);
		DeviceInfoUtil.init(context);
	}

	public String getVersion() {
		return SdkVersion.version;
	}

	// public void setDebug(boolean debug) {
	// params.setDebug(mDebug);
	// }

	private HandlerMessageListener handlerMessageListener = new HandlerMessageListener() {

		// private void doEnd(int error) {
		// sessionId = "";
		//
		// if (ttsThread != null) {
		// sessionId = ttsThread.getSessionId();
		// }
		//
		// if (listener != null) {
		// listener.onEnd(error);
		// }
		// }

		@Override
		public void onHandleMessage(Message msg) {
			SpeechSynthesizerListener listener = mPlayerCallback;
			if (listener == null) {
				return;
			}
			switch (msg.what) {

			// 错误消息
				case MsgValue.MESSAGE_ERROR:
					listener.onError(SpeechConstants.TTS_ERROR, ((USCError) msg.obj).toString());
					break;

				// 初始化成功事件
				case MsgValue.MESSAGE_INIT:
					listener.onEvent(SpeechConstants.TTS_EVENT_INIT);
					break;
				// 开始合成事件
				case MsgValue.MESSAGE_SYNTHESIZE_BEGIN:
					listener.onEvent(SpeechConstants.TTS_EVENT_SYNTHESIZER_START);
					break;
				// 结束合成事件
				case MsgValue.MESSAGE_SYNTHESIZE_END:
					listener.onEvent(SpeechConstants.TTS_EVENT_SYNTHESIZER_END);
					break;
				// 开始播放事件
				case MsgValue.MESSAGE_PLAY_BEGIN:
					listener.onEvent(SpeechConstants.TTS_EVENT_PLAYING_START);
					break;
				// 结束播放事件
				case MsgValue.MESSAGE_PLAY_END:
					listener.onEvent(SpeechConstants.TTS_EVENT_PLAYING_END);
					break;
				// 暂停播放事件
				case MsgValue.MESSAGE_PAUSE:
					listener.onEvent(SpeechConstants.TTS_EVENT_PAUSE);
					break;
				// 恢复播放事件
				case MsgValue.MESSAGE_RESUME:
					listener.onEvent(SpeechConstants.TTS_EVENT_RESUME);
					break;
				// 取消事件
				case MsgValue.MESSAGE_CANCEL:
					listener.onEvent(SpeechConstants.TTS_EVENT_CANCEL);
					break;
				// 停止事件
				case MsgValue.MESSAGE_STOP:
					listener.onEvent(SpeechConstants.TTS_EVENT_STOP);
					break;
				// 释放事件（引擎、模型、用户字典）
				case MsgValue.MESSAGE_RELEASE:
					listener.onEvent(SpeechConstants.TTS_EVENT_RELEASE);
					break;
				// 开始缓冲
				case MsgValue.MESSAGE_BUFFER_BEGIN:
					listener.onEvent(SpeechConstants.TTS_EVENT_BUFFER_BEGIN);
					break;
				// 缓冲结束
				case MsgValue.MESSAGE_BUFFER_READY:
					listener.onEvent(SpeechConstants.TTS_EVENT_BUFFER_READY);
					break;
			}
		}

	};

	// @Override
	protected int init(String jsonString) {
		if (params.getMode() == SpeechConstants.TTS_SERVICE_MODE_LOCAL) {
			String modelPath = mContext.getApplicationContext().getFilesDir().getPath();
			if (!asyncTask.isRunning() && !mTts.isInit()) {
				Object[] _params = new Object[] { modelPath, mContext };
				asyncTask.setParams(_params);
				asyncTask.start();
			} else if (mTts.isInit()) {
				msgHandler.sendMessage(MsgValue.MESSAGE_INIT);
			}
			return 0;
		} else {
			return 0;
		}
	}

	// @Override
	protected int release(int type, String dataName) {

		switch (type) {
			case SpeechConstants.TTS_RELEASE_ENGINE:
				// if (msgHandler != null) {
				// msgHandler.removeCallbacksAndMessages(null);
				// msgHandler = null;
				// }

				// if (asyncTask != null) {
				// asyncTask.cancel();
				// asyncTask = null;
				// }
				if (mOfflineSynthesizeThread != null) {
					mOfflineSynthesizeThread.cancel();
					mOfflineSynthesizeThread.release();
				}
				
				if (mTTSPlayThread != null) {
					mTTSPlayThread.cancel();
				}
				
				if (mOfflineSynthesizeThread != null) {
					mOfflineSynthesizeThread.waitEnd(10000);
				}
				
				if (mTTSPlayThread != null) {
					mTTSPlayThread.waitEnd(10000);
				}
				
				// 暂时
				isSynthesizerEnd = true;
				break;
			case SpeechConstants.TTS_RELEASE_MODEL_DATA:
				break;
			case SpeechConstants.TTS_RELEASE_USERDICT:
				break;

			default:
				Log.e("yi", "release type error");
				break;
		}
		return 0;

	}

	// 合成加播放
	// @Override
	protected int playText(String tts) {
		isOnlySynthesizer = false;
		return beginTts(tts, 0);
	}

	// 只合成
	// @Override
	protected void synthesizeText(String tts) {
		isOnlySynthesizer = true;
		beginTts(tts, 1);
	}

	// 只播放上次合成的
	// @Override
	protected void playSynWav() {
		if (mTTSPlayThread != null) {
			mTTSPlayThread.setIsPlay(true);
		}

	}

	private void waitLastplayingThreadStop() {
		if (mTTSPlayThread != null) {
			mTTSPlayThread.waitEnd(10000);
		}
	}

	public boolean isPlaying() {
		if (mTTSPlayThread != null) {
			return mTTSPlayThread.isPlaying();
		}
		return false;
	}

	private void cancelPlaying() {

		if (mTTSPlayThread != null) {
			mTTSPlayThread.cancel();
		}
	}

	private void cancelOnlineSynthesizerThread() {
		if (mOnlineSynthesizerThread != null) {
			if (mOnlineSynthesizerThread.isCancelled() == false) {
				mOnlineSynthesizerThread.cancel();
				// msgHandler.sendEmptyMessage(MsgValue.MESSAGE_CANCEL);
			}
		}
	}

	private int beginTts(String text, int type) {

		// 为了应付服务器直接setText程序卡死问题
		if (!isSynthesizerEnd) {
			return -1;
		}

		isSynthesizerEnd = false;
		if (TextUtils.isEmpty(text)) {
			return -2;
		}
		
		if (mOfflineSynthesizeThread != null) {
			mOfflineSynthesizeThread.reqStop();
		}
		if (mTTSPlayThread != null) {
			mTTSPlayThread.reqStop();
		}
		
		sessionId = "";
		
		cancelOnlineSynthesizerThread();
		
		if (mOfflineSynthesizeThread != null) {
			mOfflineSynthesizeThread.waitEnd(10000);
		}

		if (mTTSPlayThread != null) {
			mTTSPlayThread.waitEnd(10000);
		}

		setTtsField();
		if (params.getMode() == SpeechConstants.TTS_SERVICE_MODE_LOCAL) {
			// 离线合成部分
			mOfflineSynthesizeThread = new TTSOfflineSynthesizerThread(text, params.getDebug());
			mOfflineSynthesizeThread.setSynthesizerListener(mSynthesizerListener);
			// mTTSSynthesizeThread.setLog(1);
			mOfflineSynthesizeThread.setVoiceSpeed(params.getVoiceSpeed());
			mOfflineSynthesizeThread.setVoicePitch(params.getVoicePitch());
			mOfflineSynthesizeThread.setSampleRate(params.getSampleRate());
			mOfflineSynthesizeThread.setVoiceVolume(params.getVoiceVolume());
			mOfflineSynthesizeThread.start();
		} else {
			// 在线合成部分
			params.networkType = DeviceInfoUtil.getNetType();
			mOnlineSynthesizerThread = new TTSOnlineSynthesizerThread(params);
			mOnlineSynthesizerThread.setListener(mSynthesizerListener);
			mOnlineSynthesizerThread.start(text);
		}

		// 播放部分
		mTTSPlayThread = new TTSPlayThread(params.getDebug(), params.getStreamType());
		mTTSPlayThread.init(params.getDebugDir());
		mTTSPlayThread.setPlayBufferTime(params.getPlayStartBufferTime());
		mTTSPlayThread.setSampleRate(params.getSampleRate());
		mTTSPlayThread.setDebug(params.getDebug());
		mTTSPlayThread.setPlayerListener(mPlayerListener);

		// 处理只是合成不播放问题
		if (isOnlySynthesizer) {
			mTTSPlayThread.setIsPlay(false);
		}
		mTTSPlayThread.start();
		if (params.getDebug()) {
			Log.d(TAG, "initTTS  setSampleRate " + params.getSampleRate());
		}
		return 0;
	}

	// 暂时不知道该方法有什么作用
	public void start(List<byte[]> PLAYINGData) {

		sessionId = "";
		params.networkType = DeviceInfoUtil.getNetType();

		cancelOnlineSynthesizerThread();

		mOnlineSynthesizerThread = new TTSOnlineSynthesizerThread(params);
		mOnlineSynthesizerThread.setListener(mSynthesizerListener);
		mOnlineSynthesizerThread.start();

	}

	// @Override
	protected void stop() {
		// 停止离线合成线程
		// mTts.cancel();
		if (mTTSPlayThread != null) {
			mTTSPlayThread.reqStop();
			mTTSPlayThread = null;
		}

		if (mOfflineSynthesizeThread != null) {
			// mOfflineSynthesizeThread.reqStop();
			mOfflineSynthesizeThread.cancel();
		}
		// 停止在线合成线程
		cancelOnlineSynthesizerThread();

		// if (msgHandler != null) {
		// msgHandler.sendMessage(MsgValue.MESSAGE_STOP);
		// msgHandler.removeCallbacksAndMessages(null);
		// }

		// 暂时
		isSynthesizerEnd = true;
	}

	// 替换成 SpeechSynthesizerListener
	// @Override
	protected void setTTSListener(SpeechSynthesizerListener listener) {
		mPlayerCallback = listener;
	}

	// // 设置播放监听器，这个方法有什么用？
	// public void setPlayerListener(SpeechSynthesizerListener l) {
	// mPlayerCallback = l;
	// }

	// public void setDebugDir(String dir) {
	// mDebugDir = dir;
	// }

	// @Override
	protected void cancel() {
		// 取消离线合成线程
		if (mOfflineSynthesizeThread != null) {
			mOfflineSynthesizeThread.cancel();
		}

		// 取消在线合成线程
		cancelOnlineSynthesizerThread();
		// 取消播放
		// cancelPlaying();
		if (mTTSPlayThread != null) {
			mTTSPlayThread.cancel();
		}

		// 暂时
		isSynthesizerEnd = true;

	}

	USCAsyncTask asyncTask = new USCAsyncTask(new USCAsyncTaskCallback() {

		@Override
		public Object onRun(Object... params) {
			return initModel(params);
		}

		@Override
		public void onEnd(Object result) {
			LogUtil.d("OfflineTTS", "onEnd");

		}
	});

	private Object initModel(Object... params) {

		String modelPath = (String) params[0];
		modelPath += "/YunZhiSheng/offline/tts/models/";
		if (!mModelData.initModel((Context) params[1], modelPath)) {
			sendErrorMessage(ErrorCode.ERROR_GET_MODEL);
			return false;
		}

		if (!mTts.init(modelPath, "")) {
			sendErrorMessage(ErrorCode.ERROR_LOAD_MODEL);
			return false;
		}

		msgHandler.sendMessage(MsgValue.MESSAGE_INIT);

		return true;

	}

	public void setServer(String domain, short port) {
		params.setServer(new String(domain), port);
	}

	public TTSParams getParams() {
		return params;
	}

	public void setQuality(int quality) {
		params.spxQuality = quality;
	}

	public String getSessionId() {
		return sessionId;
	}

	// @Override
	protected void setOption(int key, Object value) {
		switch (key) {
			case SpeechConstants.TTS_KEY_VOICE_SPEED:
				params.setVoiceSpeed(value);
				break;
			case SpeechConstants.TTS_KEY_VOICE_PITCH:
				params.setVoicePitch(value);
				break;
			case SpeechConstants.TTS_KEY_VOICE_VOLUME:
				params.setVoiceVolume(value);
				break;
			case SpeechConstants.TTS_KEY_VOICE_NAME:
				params.setVoiceName(value);
				break;
			case SpeechConstants.TTS_KEY_PLAY_START_BUFFER_TIME:
				params.setPlayStartBufferTime(value);
				break;
			case SpeechConstants.TTS_KEY_SAMPLE_RATE:
				params.setSampleRate(value);
				break;
			case SpeechConstants.TTS_KEY_FIELD:
				params.addField(value);
				break;
			case SpeechConstants.TTS_KEY_SERVER_ADDR:
				// 两个方法有什么不同？
				// params.setServer(server, port);
				params.setServerAddress(value);
				break;
			case SpeechConstants.TTS_KEY_STREAM_TYPE:
				params.setStreamType(value);
				break;
			case SpeechConstants.TTS_SERVICE_MODE:
				params.setMode(value);
				break;
			case SpeechConstants.TTS_KEY_IS_DEBUG:
				params.setDebug(value);
				break;
			case SpeechConstants.TTS_KEY_DEBUG_DIR:
				params.setDebugDir(value);
				break;
			default:
				break;
		}
	}

	// @Override
	protected String getOption(int key) {
		switch (key) {
			case SpeechConstants.TTS_KEY_VOICE_VOLUME:
//				return params.getVoiceVolume();
				break;
			case SpeechConstants.TTS_KEY_VOICE_SPEED:

				break;
			case SpeechConstants.TTS_KEY_VOICE_PITCH:

				break;
			case SpeechConstants.TTS_KEY_VOICE_NAME:

				break;

			default:
				break;
		}
		return null;
	}

	private void setTtsField() {
		List<Integer> listField = params.getField();
		if (listField.size() > 0) {
			for (Integer field : listField) {
				mTts.setField(field);
				LogUtil.d("setTtsField...." + field);
			}
			listField.clear();
		}
	}

	// @Override
	protected void pause() {
		if (mTTSPlayThread != null) {
			mTTSPlayThread.reqPause();
		}
	}

	// @Override
	protected void resume() {
		if (mTTSPlayThread != null) {
			mTTSPlayThread.reqResume();
		}
	}
	
	private static final SimpleDateFormat mDateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault());
	private String generateFileName() {
		return mDateFormat.format(new Date(System.currentTimeMillis())) + ".pcm";
	}

	// 预留暂不支持
	// @Override
	protected int getStatus() {
		return status;
	}

	// 预留暂不支持
	// @Override
	protected int loadModel(String dataFile) {
		return 0;
	}

	// 预留暂不支持
	// @Override
	protected int loadUserDict(String userDictName, String userDictPath) {
		return 0;
	}

	// 预留暂不支持
	// @Override
	protected int setAudioSource(IAudioSource audioSource) {
		return 0;
	}

}
