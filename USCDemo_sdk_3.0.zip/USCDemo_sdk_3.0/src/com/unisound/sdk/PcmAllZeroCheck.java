package com.unisound.sdk;

/**
 * 录音全零检测
 * 
 * @author user
 * 
 */
public class PcmAllZeroCheck {

	public static boolean enabled = true;
	private boolean isAllZero = true;

	public void reset() {
		isAllZero = true;
	}

	public boolean isFirstActive(byte[] pcm, int offset, int lenght) {

		if (isAllZero && enabled) {			
			int count = 0;
			while (offset < lenght) {

				if (pcm[offset] != 0) {
					count++;
				}
				
				offset++;
			}

//			if (count > (lenght >> 2)) {
//				isAllZero = false;
//				return true;
//			}
			
			if (count > 1 ) {
				isAllZero = false;
				return true;
			}
		}
		return false;
	}
	
	
	public boolean isActive() {

		if (isAllZero && enabled) {			
			return false;
		}
		return true;
	}
}
