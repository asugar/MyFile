package com.unisound.sdk;

import cn.yunzhisheng.tts.JniClient;


public class TTSErrorCode {

	public static final int SUCCESS = 0;	
	public static final int PLAYING_EXCEPTION =  101;
	public static String toMessage(int code) {

		
		switch (code) {
		case PLAYING_EXCEPTION: return "播放异常";
		default:
			return JniClient.codeToString(code);
		}
	}
	

	public static String getMessage(int code) {

		String msg = toMessage(code);
		if(msg != null) {
			return msg;
		}
		return "错误:" + code;
	}
	


	public static USCError createError(int error){
		
		if(error == 0){
			return null;
		}

		return new USCError(error, getMessage(error) );
	}
	
}
