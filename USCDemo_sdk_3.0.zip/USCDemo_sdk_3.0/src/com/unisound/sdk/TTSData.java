package com.unisound.sdk;

public class TTSData {
	public String message = "";
	public String type = "0";
	public String speed = "1";
	public byte[] data;
}
