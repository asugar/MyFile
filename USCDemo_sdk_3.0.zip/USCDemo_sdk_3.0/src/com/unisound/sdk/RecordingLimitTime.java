package com.unisound.sdk;

public class RecordingLimitTime {

	
	private int recordingLength = 0;
	private int maxTime = -1;
	private boolean enabled = false;

	/**
	 * 数据时长计数
	 * @param enabled
	 * @param data
	 * @param offset
	 * @param lenght
	 */
	public boolean isTimeout(boolean enabled,  int lenght) {
		if (enabled && this.enabled) {
			recordingLength += lenght;
			if (recordingLength > maxTime) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * 设置最大时长门限值
	 * @param max
	 */
	public void setMaxTime(int max) {
		
		reset();
		if (max == -1) {
			enabled = false;
		} else {
			enabled = true;
			maxTime = max * 32; // ms to byte length
		}
	}

	/**
	 * 数据重置复位
	 */
	public void reset() {

		recordingLength = 0;
	}
}
