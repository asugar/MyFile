package com.unisound.sdk;

import cn.yunzhisheng.asr.VADParams;

import com.unisound.common.Addresser;

import com.unisound.common.Scene;
import com.unisound.sdk.USCNluParams;
import com.unisound.common.LogUtil;

public class RecognizerParams extends VADParams {

	public enum EngineFunction {
		VPR, ASR,NLU, ASR_NLU
	}
	
	public final String webPath = "/USCService/WebApi";
	public static String USER_DATA_SERVER = "http://u.hivoice.cn:8081/casr/upload";
	
	public static String MODEL_TYPE_GENERAL = "general";
	public static String MODEL_TYPE_POI = "poi";
	public static final String ENGLISH = "en";
	public static final String CANTONESE = "co";
	public static final String CHINESE = "cn";

	public static final String ORAL = "oral";
	public static final String CN_EN_MIX = "cn_en_mix";


	public boolean ASR_USRDATA_PROTOCOL_ENABLED = false;
	public boolean isTempResultEnabled = false;
	public boolean ENABLED_REQ_RSP_ENTITY = true;
	public boolean ASR_USRDATA_ENABLED = true;
	public boolean RATE_8K_ENABLED = true;

	
	private static Addresser addresser = new Addresser(RecognizerAddress.CHINESE_ADDRESS);

	private boolean isPunctuation = true;	
	
	/**
	 * 识别请求信息
	 */
	public int asrReqSpeakerInfo = 0;

	public boolean rateReal8k = false;

	/**
	 * 识别请求信息返回信息
	 */
	public int asrRspSpeakerInfo = 0;
	private String serviceKey = "";
	private String secret = "";
	private String sessionId = "";
	
	int networkType = 0;
	int spxQuality = 8;
	int enableVAD = 1;
	/**
	 * 前端VAD时间（毫秒）
	 */
	int VADTimeout = 3000;
	/**
	 * 网络识别结果反回超时时间 (秒)
	 */
	int resultTimeout = 20;

	private EngineParams engineParams = new EngineParams();
	
	/**
	 * 全语音场景ID
	 */
	private Scene mTempASRStartScene =  new Scene(Scene.SCENE_DISABLED,"");
	private Scene mTempNLUStartScene =  new Scene(Scene.SCENE_DISABLED,"");

	private USCNluParams mNLUParams = new USCNluParams();
	private VPRParams mVPRParams = new VPRParams();
	
	public VPRParams getVPRParams() {
		return mVPRParams;
	}

	public USCNluParams getNluParams() {
		return mNLUParams;
	}

	
	public Scene getASRStartScene() {
		return mTempASRStartScene;
	}
	
	public void setAppKey ( String appKey) {
		serviceKey = appKey;
	}
	
	public String getAppKey() {
		return serviceKey;
	}
	
	public EngineParams getEngineParams(){
		return engineParams;
	}

	public void setRateReal8k(boolean real8k) {
		rateReal8k = real8k;
	}


	Addresser getAddressser() {

		return addresser;
	}

	void resetDNS() {
		addresser.resetDNS();
	}

	// 设置是否添加标点符号
	public void setPunctuation(boolean isEnable) {
		this.isPunctuation = isEnable;
	}

	// 获取是否添加标点符号
	public boolean getPunctuation() {
		return isPunctuation;
	}

	void setServer(String server, int port) {

		addresser.setServer(server);
		addresser.setPort(port);

	}

	// 设置默认的服务器地址和端口号
	void setDefaultServer(String server, int port) {
		addresser.setDefaultServer(server);
		addresser.setDefaultPort(port);

		LogUtil.d("RecognizerParams:setDefaultServer server " + server
				+ ",port " + port);
	}

	public boolean setSampleRate(int rate) {
		return engineParams.setSampleRate(rate);
	}

	// 设置语言
	public void setLanguage(String lang) {
		if (lang == null) {
			LogUtil.e("RecognizerParams:setLanguage error language == null ");
			return;
		}

		LogUtil.d("RecognizerParams:setLanguage in " + lang);
		addresser.setAddresser(RecognizerAddress.getAddresser(lang));
		isFarFeildEnabled = false;
		UploadUserData.userDataServer = USER_DATA_SERVER;
		
		if (lang.equals(RecognizerParams.ENGLISH)) {
			
		} else if (lang.equals(RecognizerParams.CANTONESE)) {

		} else if (lang.equals(RecognizerParams.ORAL)) {

		} else if (lang.equals(RecognizerParams.CN_EN_MIX)) {
			// HTC address post user data			
			UploadUserData.userDataServer = "http://"+ addresser.getServer() +":9006/casr/upload";
		} else {
			LogUtil.d("RecognizerParams:setLanguage do " + RecognizerParams.CHINESE);
		}
	}
	
	/**
	 * 设置语种，暂时不支持 2015-01-27
	 * @param language
	 */
	public void setLanguage_(String language) {
		engineParams.setLanguage(language);
		LogUtil.d("RecognizerParams:setLanguage do " + language);
	}


	/**
	 * 设置识别领域 为了方便支持后续扩展，不再限定参数由服务器判断。(2014-08-11)
	 * 
	 * @param engine
	 * @return
	 */

	public boolean setModelType(String engine) {

		return engineParams.setModelType(engine);
	}

	/**
	 * 设置识别服务器地址
	 * 
	 * @param value
	 * @return
	 */
	public boolean setServer(String value) {
		if (value == null) {
			return false;
		}

		String items[] = value.split(":");
		if (items.length != 2) {
			return false;
		}

		if (items[0].length() == 0) {
			return false;
		}

		try {
			short port = (short) (int) Integer.valueOf(items[1]);
			setServer(items[0], port);
			setDefaultServer(items[0], port);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public void setStartScene(Scene scene) {
		this.mTempASRStartScene.setScene(scene);
		mTempNLUStartScene.setScene(scene);
	}

	public void setFarFeild(boolean farFeild) {
		engineParams.setVoiceField(farFeild? EngineParams.VOICE_FIELD_FAR: EngineParams.VOICE_FIELD_NEAR);
	}


	/**
	 *  设置录音线程VAD是否启用
	 * @param enabled
	 */
	public void setVADRecordingEnabled(boolean enabled) {
		this.setVADEnabled(enabled);
	}

	public void setVoiceField(String field) {
		engineParams.setVoiceField(field);		
	}
	

	public boolean isTempResultEnabled( ) {
		return isTempResultEnabled;
	}
	
	public void setTempResultEnabled(boolean enabled) {
		isTempResultEnabled = enabled;
	}

	public Scene getNLUStartScene() {

		return mTempNLUStartScene;
	}

	/**
	 * 识别任务ID
	 * @return
	 */
	public boolean isSessionIdEnabled() {
		return ENABLED_REQ_RSP_ENTITY;
	}

	public void setEngineFunction(EngineFunction function) {
		if(function == EngineFunction.VPR) {
			mNLUParams.setEnabled(false);
			mVPRParams.setEnabled(true);
		}
		else if(function == EngineFunction.ASR_NLU) {
			mVPRParams.setEnabled(false);
			mNLUParams.setEnabled(true);
		}
		else {
			mNLUParams.setEnabled(false);
			mVPRParams.setEnabled(false);
		}
		
	}
	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
}