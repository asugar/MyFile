package com.unisound.sdk;

import android.media.AudioRecord;
import cn.yunzhisheng.asr.VADParams;

import com.unisound.common.LogUtil;

public class RecordingThread extends InputSourceThread {
	public static final int FREQUENCY_16K = VADParams.FREQUENCY_16K;
	private static int FREQUENCY = FREQUENCY_16K;
	protected static RecordingThread mInstance;
	private static int bufferSizeInBytes;
	private AudioRecord audioRecord = null;
	protected static final int k = (16000 * 150) / 1000; // 100ms
	private byte[] buffer = new byte[k >> 1];// 37.5ms 1200bytes
	static {

		bufferSizeInBytes = (k * 4 * 16 * 1) / 8; // 200ms = 6400bytes
		int bufferSize = AudioRecord.getMinBufferSize(FREQUENCY, CHANNEL,
				ENCODING);
		if (bufferSizeInBytes < bufferSize) {
			bufferSizeInBytes = bufferSize;
		}
	}

	public RecordingThread(VADParams vadParams,RecordingDataListener listener) {
		super(vadParams,listener);
		mInstance = this;
	}


	protected boolean open() {
		
		audioRecord = new AudioRecord(vadParams.getAudioSource(),
				vadParams.getRecordingSampleRate(), CHANNEL, ENCODING, bufferSizeInBytes);

		if (audioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
			audioRecord.startRecording();
			return true;
		}


		return false;
	}
	
	protected void close() {
		
		if(audioRecord != null) {
		
			LogUtil.d("RecordingThread::close audioRecord.stop()");
 			if (audioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
 				audioRecord.stop();
 			}
			LogUtil.d("RecordingThread::close audioRecord.release()");
 			audioRecord.release();
 			audioRecord = null;
			LogUtil.d("RecordingThread::close ok");
 		}
		if(mInstance == this) {
			mInstance = null;
		}
	}


	@Override
	protected byte[] read() {
		if(audioRecord != null) {
			int read = audioRecord.read(buffer, 0, buffer.length);
			if(read > 0) {
				byte[] pcm = new byte[read];
				System.arraycopy(buffer, 0, pcm, 0, read);
				return pcm;
			}
		}
		return null;
	}
	

	public static void waitRecordingEnd() {
		
		if(mInstance != null) {
			mInstance.waitEnd();
		}
	}
}