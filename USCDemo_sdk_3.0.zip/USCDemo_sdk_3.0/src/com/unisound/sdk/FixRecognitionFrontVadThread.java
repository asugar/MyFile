package com.unisound.sdk;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import cn.yunzhisheng.asr.VAD;
import cn.yunzhisheng.asrfix.JniAsrFix;

import com.unisound.sdk.VADListener;
import com.unisound.client.ErrorCode;
import com.unisound.common.LogUtil;

public class FixRecognitionFrontVadThread extends FixRecognitionThreadInterface implements VADListener {

	private static final int ASR_STOP_CANCEL = 1;

	private BlockingQueue<byte[]> mVadQueue = new LinkedBlockingQueue<byte[]>();
	private boolean vadStop = false;
	private VAD vad;	
	
	public FixRecognitionFrontVadThread(JniAsrFix jac, String modelTag, FixRecognizerParams params) {
		super(jac, modelTag, params);
		
	}

	@Override
	public void run() {
		initVAD();
		onRun();
		unInitVAD();
	}

	private void initVAD() {

		vad = new VAD(params, this);
		vad.init_();
		vad.setEnabled(true);
		
	}

	private void resetVAD() {
		vadStop = false;
		if (vad != null) {
			vad.reset();
		}
	}

	private void unInitVAD() {
		if (vad != null) {
			vad.destory();
			vad = null;
		}
	}

	/**
	 * 识别任务过程中使用VAD切分任务
	 * 
	 * @return
	 */
	private int asrTask() {

		int result = JniAsrFix.ASRCLIENT_OK;

		if (isCanceled() || jac == null) {
			log_d("asrTask cancel or jac == null");
			return ASR_STOP_CANCEL;
		}
		
		boolean isVadStart = false;
		synchronized (jac) {
			

			int r = jac.start_(modelTag, params.getModelIndex());
			if (r < 0) {
				log_e("jac::start error="+ r +",model=" + modelTag + ",modelIndex=" + params.getModelIndex());
				doRecognitionError(JniAsrFix.transErrorCode(r));
				return r;
			}
			log_d("jac::start model=" + modelTag + ",modelIndex=" + params.getModelIndex());
			
			try {
				
				while (!isExit()) {
						
						byte[] vadQueueBuffer = mVadQueue.poll();
						if (vadQueueBuffer == null) {							
							
							byte[]	buffer = this.poll();	
							if (buffer != null) {
								// add vad
								writeToVad(buffer);
							}					
						}

						if (vadQueueBuffer != null) {
							
							if(isVadStart == false) {
								isVadStart = true;
								doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_START, LogUtil.LOG_TYPE_NULL, null);				
							}
							
							r = jac.recognize_(vadQueueBuffer,vadQueueBuffer.length);
	
							doRecogintionLogData(LogUtil.WHAT_TYPE_ASR_FEED, LogUtil.LOG_TYPE_BYTES,vadQueueBuffer);
							
							if (r == JniAsrFix.ASRCLIENT_PARTIAL_RESULT) {
	
								if (params.isFixAsrContinuous()) {
									String partial = jac.getResult_();
									if (partial != null && partial.length() > 0) {
										doRecognitionResult(partial, false);
										doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_PART_RESULT, LogUtil.LOG_TYPE_STRING, partial);
									}
								}
								vadStop = true;
								log_d("recognize=" + r);
							} else if (r == JniAsrFix.ASRCLIENT_VAD_TIMEOUT) {
								doRecognitionVADTimeout();

							} else if (r == JniAsrFix.ASR_MAX_SPEECH_TIMEOUT) {
								doRecognitionMaxSpeechTimeout();

							} else if (r == JniAsrFix.ASRCLIENT_NO_RESULT) {
	
							} else if (r < 0) {
								jac.stop_();
								doRecognitionError(JniAsrFix.transErrorCode(r));
								return r;
							}
						}
	
					if (vadStop || setToStopped && recordQueue.size() == 0) {
						log_i("recog break");
						break;
					}
				}
			} catch (InterruptedException e) {

				e.printStackTrace();				
			}
			
			jac.stop_();
			log_i("recog stopped");
			
			String partial = jac.getResult_();
			
			if(isVadStart) {
				doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_STOP_RESULT, LogUtil.LOG_TYPE_STRING, partial);
				doRecogintionLogData( LogUtil.WHAT_TYPE_ASR_END, LogUtil.LOG_TYPE_NULL, null);
			}
			doRecognitionResult(partial, true);
		}

		return result;
	}


	private boolean isExit() {
		
		if(isCanceled() || (setToStopped  && !isExistAsrData())) {
			return true;
		}
		return false;
	}
	
	/**
	 * 识别过程使用VAD断句，增加识别结果返回的实时度？
	 */
	protected void onRun() {

		// 识别准备回调
		int r = doPrepareRecognizer();
		if(r != ErrorCode.RECOGNIZER_OK) {
			doRecognitionError(r);
			return;
		}
		
		int result = JniAsrFix.ASRCLIENT_OK;
		while (!isExit()) {
			resetVAD();
			LogUtil.d( this.toString() + ".asrTask");
			result = asrTask();
			if (result < JniAsrFix.ASRCLIENT_OK) {
				break;
			}
		}

		if (result >= JniAsrFix.ASRCLIENT_OK) {
			doRecognitionEnd();
		}

	
	}


	private int writeToVad(byte[] pcm) {
		if (vad == null) {
			return VAD.ASR_VAD_HOLDING;
		}
		vad.write(pcm, 0, pcm.length);
		return 0;
	}

	@Override
	public void onRecordingData(boolean enabled, byte[] data, int offset,
			int lenght) {
		if (enabled) {
			mVadQueue.add(data);
			// log_d("onRecordingData enabled");
		} else {
			// log_d("onRecordingData disabled");
		}
	}

	@Override
	public void onSpeechStart() {

	}

	@Override
	public void onUpdateVolume(int volume) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onVADTimeout(VAD sender) {
		vadStop = true;
		mVadQueue.clear();
		vad.reset();
		log_d("onVADTimeout");
	}	
}


