package com.unisound.sdk;

import android.os.Message;
import cn.yunzhisheng.asr.VAD;
import cn.yunzhisheng.asrfix.JniAsrFix;

import com.unisound.client.ErrorCode;
import com.unisound.common.LogUtil;

public class FixRecognizer extends MainMessageHandler implements
		RecognitionListener, RecordingDataListener {

	private final static int MSG_RECORDING_START = 1;
	private final static int MSG_RECORDING_STOP = 2;
	private final static int MSG_RECORDING_ERROR = 3;
	private final static int MSG_RECORDING_DATA_START = 4;
	private final static int MSG_RECORDING_SPEECH_START = 5;

	private final static int MSG_RECOGNITION_RESULT = 11;
	private final static int MSG_RECOGNITION_STOP = 12;
	private final static int MSG_RECOGNITION_ERROR = 13;
	private final static int MSG_RECOGNITION_CANCEL = 14;
	private final static int MSG_RECOGNITION_EXCEPTION = 15;

	private final static int MSG_VAD_TIMEOUT = 21;
	private final static int MSG_UPDATE_VOLUMN = 22;
	private final static int MSG_MAX_SPEECH_TIMEOUT = 23;
	private final static int MSG_UPLOAD_USER_DATA = 24;
	public final static int MSG_MAX_WHAT_ID = 50;

	private InputSourceThread recordingThread = null;
	private PrepareRecognizerListener prepareRecognizer = null;
	private FixRecognitionThreadInterface recognitionThread = null;

	private PcmAllZeroCheck pcmAllZeroCheck = new PcmAllZeroCheck();
	private static JniAsrFix jac = new JniAsrFix();
	private FixRecognizerParams params = null;
	private boolean asrEnabled = true;

	static {
		System.loadLibrary("uscasr");
	}

	public FixRecognizer() {

	}

	public void setParams(FixRecognizerParams params) {
		this.params = params;
	}

	protected void log_i(String log) {
		LogUtil.i(log);
	}

	private void log_e(String log) {
		LogUtil.e(log);
	}

	private void log_d(String log) {
		LogUtil.d(log);
	}

	public boolean loadModel(String modelDir, String poiList, boolean reload) {

		waitRecognitionThreadEnd(false);
		
		synchronized (jac) {
			
			if(jac.isLoaded() && reload == false) {

				int code = jac.reset_(poiList, "");
				if(code != 0) {
					LogUtil.e( "Recognizer.loadModel reset error:" + code);
					return false;
				}		
				LogUtil.d( "Recognizer.loadModel reset ok");
			}
			else {
				int code = jac.load(modelDir, poiList);
	
				if (code != 0) {
					log_e("jac.init path=" + modelDir + ":" + poiList + " error:"
							+ code);
					return false;
				}
				jac.setOptionInt_(JniAsrFix.ASR_OPT_ENABLE_VAD, 1);
				jac.setOptionInt_(JniAsrFix.ASR_OPT_VAD_TIMEOUT, 3000);
				jac.setOptionInt_(JniAsrFix.ASR_OPT_PCM_COMPRESS, 8);
				jac.setOptionString_(JniAsrFix.ASR_OPT_SERVICE_KEY,
						params.getAppKey());
			}
		}

		return true;
	}

	public void waitLastRecordingThreadStop() {

		if(recordingThread != null) {
			recordingThread.waitEnd();
			recordingThread = null;
		}
	}

	/**
	 * 开始识别
	 * 
	 * @param tag
	 */
	public void start(String tag, InputSourceThread inputSource) {

		LogUtil.d("asrfix start:: wait last end");
		cancelRecognition();
		pcmAllZeroCheck.reset();

		if (asrEnabled) {
			LogUtil.d("asrfix start:: check isLoaded");
			if (jac.isLoaded()) {
				LogUtil.d("asrfix recognitionThread start");

				if (params.isFrontVadEnabled()) {
					recognitionThread = new FixRecognitionFrontVadThread(jac, tag,
							params);
				} else {
					recognitionThread = new FixRecognitionThread(jac, tag, params);
				}

				recognitionThread.setListener(FixRecognizer.this);
				recognitionThread.setPrepareRecognizer(prepareRecognizer);
				recognitionThread.start();
			} else {
				sendMessage(MSG_RECOGNITION_ERROR,
						MixErrorCode.FIX_RECOGNIZER_NO_INIT);
				// 是否放弃录音
				if (listener == null) {
					return;
				}
				if (listener.isStopRecording()) {
					return;
				}
			}
		}

		recordingThread = inputSource;

		LogUtil.d("asrfix start:: recordingThread start");
		recordingThread.start();
	}

	private void stopRecording() {
		if (recordingThread != null) {
			recordingThread.stopRecording();
		}
	}

	public void stop() {

		stopRecording();

		if (recordingThread == null) {
			// 外部输入语音数据直接识别。停止时返回Stop 回调
			if (recognitionThread != null) {
				if (recognitionThread.isSetToStopped() == false) {
					sendMessage(MSG_RECORDING_STOP);
				}
			}
		}
	}

	RecognizerListener listener;

	public void setListener(RecognizerListener uscRecognizer) {
		listener = uscRecognizer;
		setMessageLisenter(listener);
	}

	private void doEnd(int error) {

		if (listener != null) {
			if (listener.isStopRecording()) {
				waitLastRecordingThreadStop();
			}
		}

		if (listener != null) {
			LogUtil.d("msg:doEnd");
			listener.onEnd(error);
		}
	}

	@Override
	public boolean doHandleMessage(Message msg) {
		switch (msg.what) {

		case MSG_RECORDING_START:
			boolean isSuccess = (Boolean) msg.obj;
			if (isSuccess) {
				if (listener != null) {
					LogUtil.d("msg onRecordingStart true");
					listener.onRecordingStart();
				}
			} else {
				LogUtil.d("msg onRecordingStart false");
				cancelRecognition();
				doEnd(ErrorCode.FAILED_START_RECORDING);
			}
			break;

		case MSG_RECORDING_STOP:
			stopRecognition();
			if (listener != null) {
				LogUtil.d("msg onRecordingStop");
				listener.onRecordingStop();
			}

			break;

		case MSG_RECORDING_ERROR:
			cancelRecognition();
			doEnd(ErrorCode.RECORDING_EXCEPTION);
			break;
		case MSG_RECORDING_DATA_START:
			LogUtil.d("msg doRecordingStartData");
			doRecordingStartData();
			break;
		case MSG_RECORDING_SPEECH_START:
			doRecordingSpeechStart();
			break;
		case MSG_RECOGNITION_RESULT:
			if (listener != null) {
				RecognitionResult recognitionResult = (RecognitionResult) msg.obj;
				listener.onResult(recognitionResult.text,
						recognitionResult.isLast);
			}
			break;

		case MSG_RECOGNITION_STOP:
			doEnd(JniAsrFix.ASRCLIENT_OK);
			break;

		case MSG_RECOGNITION_ERROR:
			int code = (Integer) msg.obj;
			doEnd(code);
			break;

		case MSG_RECOGNITION_CANCEL:
			log_d("recognizer cancel");
			if (listener != null) {
				listener.onCancel();
			}
			break;

		case MSG_RECOGNITION_EXCEPTION:
			stopRecording();
			doEnd(ErrorCode.RECOGNITION_EXCEPTION);
			break;

		case MSG_VAD_TIMEOUT:
			if (listener != null) {
				listener.onVADTimeout((VAD) msg.obj);
			}
			break;

		case MSG_UPDATE_VOLUMN:
			if (listener != null) {
				int volume = (Integer) msg.obj;
				listener.onUpdateVolume(volume);
			}
			break;

		case MSG_MAX_SPEECH_TIMEOUT:
			cancelRecognition();
			stopRecording();

			doEnd(JniAsrFix.ASR_MAX_SPEECH_TIMEOUT);
			break;
		case MSG_UPLOAD_USER_DATA:
			if (listener != null) {
				code = (Integer) msg.obj;
				// recognitionListener.onUploadUserData(code);
			}
			break;
		default:
			return false;
		}
		return true;
	}

	public void cancel(boolean isSendMessage) {

		waitLastRecordingThreadStop();
		cancelRecognition();
		removeSendMessage();

		if (isSendMessage) {
			sendMessage(MSG_RECOGNITION_CANCEL);
		}
	}

	protected void doRecordingSpeechStart() {
		RecognizerListener ls = listener;
		if (ls != null) {
			ls.onSpeechStart();
		}
	}

	protected void cancelRecognition() {
		if (recognitionThread != null) {
			recognitionThread.cancel();
		}
	}

	public void stopRecognition() {
		if (recognitionThread != null) {
			recognitionThread.stopRecognition();
		}
	}

	protected void cancelRecording() {
		if (recordingThread != null) {
			recordingThread.cancel();
		}
	}

	private void doRecordingStartData() {
		RecognizerListener ls = listener;
		if (ls != null) {
			ls.onRecordingDataStart();
		}
	}

	@Override
	public void onRecognitionError(int error) {

		if (recordingThread != null) {
			recordingThread.stopRecording();
		}
		sendMessage(MSG_RECOGNITION_ERROR, error);
	}

	@Override
	public void onUpdateVolume(int volume) {
		sendMessage(MSG_UPDATE_VOLUMN, volume);
	}

	@Override
	public void onRecognitionResult(String partial, boolean isLast) {

		RecognitionResult res = new RecognitionResult();
		res.text = partial;
		res.isLast = isLast;
		sendMessage(MSG_RECOGNITION_RESULT, res);
	}

	@Override
	public void onRecognitionEnd() {
//		waitLastRecordingThreadStop();
		sendMessage(MSG_RECOGNITION_STOP);
	}

	@Override
	public void onRecordingStart(boolean success) {
		pcmAllZeroCheck.reset();
		sendMessage(FixRecognizer.MSG_RECORDING_START, success);
	}

	@Override
	public void onRecordingStop() {
		sendMessage(MSG_RECORDING_STOP);
		recordingThread = null;
	}

	@Override
	public void onRecordingError() {
		sendMessage(MSG_RECORDING_ERROR);
	}

	@Override
	public void onRecognitionVADTimeout() {
		if (recordingThread != null) {
			// recordingThread.stopRecording();
			// recordQueue.clear();
		}
	}

	@Override
	public void onRecognitionMaxSpeechTimeout() {
		sendMessage(FixRecognizer.MSG_MAX_SPEECH_TIMEOUT);
	}

	@Override
	public void onSpeechStart() {
		sendMessage(FixRecognizer.MSG_RECORDING_SPEECH_START);
	}

	@Override
	public void onRecordingData(boolean enabled, byte[] data, int offset,
			int lenght) {

		if (pcmAllZeroCheck.isFirstActive(data, offset, lenght)) {
			sendMessage(FixRecognizer.MSG_RECORDING_DATA_START);
		}

		if (enabled && pcmAllZeroCheck.isActive()) {
			if (recognitionThread != null) {
				recognitionThread.addData(data);
			}
		}

		RecognizerListener ls = listener;
		if (ls != null) {
			if (PcmAllZeroCheck.enabled) {
				ls.onRecordingData(pcmAllZeroCheck.isActive()&&enabled, data, offset,
						lenght);
			} else {
				ls.onRecordingData(enabled, data, offset, lenght);
			}
		}
	}

	@Override
	public void onVADTimeout(VAD sender) {

		if (recordingThread != null && recordingThread.isSetToStop()) {
			return;
		}

		sendMessage(FixRecognizer.MSG_VAD_TIMEOUT, sender);
	}

	private void waitRecognitionThreadEnd(boolean isCancle) {
		if (recognitionThread != null) {
			recognitionThread.waitEnd(isCancle);
			recognitionThread = null;
		}
	}

	// @Override
	// public void finalize() {
	// release();
	// }
	public void release() {

		if (recognitionThread == null) {
			return;
		}

		LogUtil.d("recordingThread : " + recordingThread);
		if (recordingThread != null) {
			recordingThread.stopRecording();
			LogUtil.d("recordingThread.stopRecording();");
		}
		jac.setTryRelease();

		waitRecognitionThreadEnd(true);

		jac.unLoad();
		LogUtil.d("jac.unLoad();");

	}

	public void setAsrEnabled(boolean b) {
		this.asrEnabled = b;
	}

	public String search(String poi, String words) {

		return jac.search_(poi, words);
	}

	public int reset(String model, String cmd) {
		// jac 内有多线程保护
		return jac.reset_(model, cmd);
	}

	public boolean isLoadModel() {
		return jac.isLoaded();
	}

	@Override
	public void onRecogintionRequestId(String id) {
		// TODO Auto-generated method stub

	}

	public void setPrepareRecognizerListener(
			PrepareRecognizerListener prepareRecognizer) {
		this.prepareRecognizer = prepareRecognizer;

	}

	/**
	 * 引擎是否正在运行中
	 * 
	 * @return
	 */
	public boolean isRunning() {

		if (recognitionThread != null) {
			return recognitionThread.isAlive();
		}
		return false;
	}

	@Override
	public void onLogData(int what, int type, Object object) {
		if (listener != null) {
			listener.onLogData(what, type, object);
		}
	}
}
