package com.unisound.sdk;

import java.util.HashMap;
import java.util.Map;

import com.unisound.common.LogUtil;

/**
 * 
 * @author zhangkj
 *
 */
public class EngineParams  {


	/**
	 * 16kto 8k
	 */
	public static final int RATE_8K = 8000;
	/**
	 * 16k
	 */
	public static final int RATE_16K = 16000;
	/**
	 * 8k语音输入
	 */
	public static final int RATE_REAL_8K = 80000;
	

	private static final String MODEL_TYPE = "modelType";
	
	private static final String KEY_VOICE_FIELD = "voiceField";
	private static final String KEY_LANGUAGE = "lang";
	private static final String KEY_SAMPLE_RATE = "sampleRate";
	
	public static final String VOICE_FIELD_FAR = "far";	
	public static final String VOICE_FIELD_NEAR = "near";
	public static final String SAMPLE_RATE_8K = "8k";
	public static final String SAMPLE_RATE_16K = "16k";
	public static final String SAMPLE_RATE_16K_TO_8K = "16kto8k";

	
	public static final String MODEL_TYPE_GENERAL = "general";
	public static final String MODEL_TYPE_POI = "poi";
	public static final String MODEL_TYPE_FOOD = "food";
	public static final String MODEL_TYPE_MEDICAL = "medical";
	public static final String MODEL_TYPE_MOVIETV = "movietv";
	
	
	/**
	 * 语言类型英语
	 */
	public static final String LANGUAGE_ENGLISH = "en";
	/**
	 * 语言类型粤语
	 */
	public static final String LANGUAGE_CANTONESE = "co";
	/**
	 * 语言类型汉语普通话
	 */
	public static final String LANGUAGE_CHINESE = "cn";
	
	private Map<String,String> mParams = new HashMap<String, String>();
	private StringBuffer mStringParam = new StringBuffer();
	private boolean mIsChange = true;
	private int mSampleRate = RATE_16K;
	private boolean mIsEnabled = true;
	
	private boolean mResultPunctuationEnabled = true;
	
	
	public EngineParams() {
//		setModelType(MODEL_TYPE_GENERAL);
		setVoiceField(VOICE_FIELD_NEAR);
		setSampleRate(RATE_16K);
	}
	
	public boolean isEnabled() {
		return mIsEnabled;
	}
	
	public void setEnabled(boolean enabled) {
		mIsEnabled = enabled;
	}
	
	
	public void setResultPunctuationEnable(boolean enabled) {
		mResultPunctuationEnabled = enabled;
	}
	
	
	public boolean isResultPunctuationEnable(boolean enabled) {
		return mResultPunctuationEnabled;
	}
	
	
	/**
	 * 设置语言 目前没有使用，待服务器支持 2015-01-27
	 * @param language
	 */
	public void setLanguage(String language) {
		mParams.put(KEY_LANGUAGE, language);
		setChanged();
	}
	
	public boolean setModelType( String value) {
		mParams.put(MODEL_TYPE, value);
		setChanged();
		return true;
	}
	
	public void setVoiceField( String value) {
		mParams.put(KEY_VOICE_FIELD, value);
		setChanged();
	}
	
	public void setSampleRate8k() {
		setSampleRate(SAMPLE_RATE_16K_TO_8K);
		mSampleRate = RATE_8K;
	}
	
	public void setSampleRateReal8k() {
		setSampleRate(SAMPLE_RATE_8K);
		mSampleRate = RATE_REAL_8K;	
	}
	
	public void setSampleRate16k() {
		setSampleRate(SAMPLE_RATE_16K);
		mSampleRate = RATE_16K;
	}
	
	public void setSampleRate(String value) {
		mParams.put(KEY_SAMPLE_RATE, value);
		setChanged();
	}
	
	
	
	public void reset() {
		mStringParam.delete(0, mStringParam.length());
		mParams.clear();
	}
	
	private void setChanged() {
		mIsChange = true;
	}
	
	private void update() {
		
		if(mIsChange) {
			mIsChange = false;
			mStringParam.delete(0, mStringParam.length());

			for(String key: mParams.keySet()) {
				mStringParam.append(key).append(":");
				mStringParam.append(mParams.get(key)).append("\n");				
			}
		}
	}
	
	public String toString() {
		update();
		return mStringParam.toString();
	}

	public int getRate() {
		return mSampleRate;		
	}

	public boolean setSampleRate(int rate) {
		switch(rate) {
		case RATE_8K:
			setSampleRate8k();
			return true;
		case RATE_16K:
			setSampleRate16k();
			return true;
		case RATE_REAL_8K:
			setSampleRateReal8k();
			return true;
		}
		
		LogUtil.e(this.toString() + ".setSampleRate param error " + rate);
		return false;
	}
	
}
