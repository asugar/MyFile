package com.unisound.sdk;

import android.content.Context;
import android.os.Message;

import com.unisound.client.SpeechConstants;
import com.unisound.client.TextUnderstanderListener;
import com.unisound.common.DeviceInfoUtil;


/**
 * 提供语义理解相关接口</br>
 * 通过setOption进行语义理解参数设置 </br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  通过setText传入文本,开始进行语义理解 </br>
 * (4)  获取回调,得到语义理解json结果 </br>
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class TextUnderstanderInterface extends MainMessageHandler{

	//放到常量类中
	private static final int MSG_NLU_RESULT = 100;
	private static final int MSG_NLU_END = 101;
	private static final int NLU_RESULT = 1000;
	private static final int NLU_END = 1001;
	
	private TextUnderstanderListener understanderListener;
	private USCNluThread nluThread;
	private USCNluParams nluParams;
	
	
	/**
	 * TextUnderstander构造方法
	 * @param context 上下文
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	protected TextUnderstanderInterface(Context context, String appKey ,String secret) {
		DeviceInfoUtil.init(context);		
		nluParams = new USCNluParams(appKey, secret);
		nluParams.setUdid(DeviceInfoUtil.imei);
		nluParams.setAppver(DeviceInfoUtil.packageName);
	}
	
	/**
	 * 根据JsonStr初始化NLU
	 * @param JsonStr
	 * @return 0 表示成功，否则返回相应错误码
	 */
	protected int init(String JsonStr) {
		return 0;
	}

	/**
	 * 传入文本开始语义理解,非阻塞
	 * @param   text  需要解析的文本
	 */
	protected void setText(String text) {
		if(text == null ) {
			sendMessage(MSG_NLU_RESULT, "");
		}
		else if(text.length() == 0){
			sendMessage(MSG_NLU_RESULT, "");
		}
		else {
			startNluThread(text);
		}
	};
	
	/**
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	protected void setListener(TextUnderstanderListener listener){
		this.understanderListener = listener;
	}

	/**
	 * 设置可选项</br>
	 * 设置语义理解场景   {@link com.unisound.client.SpeechConstants#NLU_SCENARIO} </br>
	 * 设置语义解析服务器 {@link com.unisound.client.SpeechConstants#NLU_SERVER_ADDR} server=ip:port </br>
	 * 设置云平台返回的历史信息 {@link com.unisound.client.SpeechConstants#GENERAL_HISTORY}</br>
	 * 设置解析城市信息 {@link com.unisound.client.SpeechConstants#GENERAL_CITY} </br>
	 * 设置语义日志ID     {@link com.unisound.client.SpeechConstants#GENERAL_VOICEID} </br>
	 * @param key
	 * @param value
	 * @see SpeechConstants
	 */
	protected void setOption(int key , Object value){
		switch (key) {
		//TODO Add Scene
		case SpeechConstants.NLU_SERVER_ADDR:
			nluParams.setNluServer((String)value);
			break;
		case SpeechConstants.NLU_SCENARIO:
			nluParams.setScenario((String)value);
			break;
		case SpeechConstants.GENERAL_HISTORY:
			nluParams.setHistory((String)value);
			break;
		case SpeechConstants.GENERAL_CITY:
			nluParams.setCity((String)value);
			break;
		case SpeechConstants.GENERAL_VOICEID:
			nluParams.setVoiceId((String)value);
			break;
		default:
			break;
		}
	}
	
	/**
	 * 获取可选项
	 * @param key
	 * @return value 返回可选项
	 */
	protected Object getOption(int key){
		switch (key) {
		//TODO Add Scene
		case SpeechConstants.NLU_SERVER_ADDR:
			return nluParams.getNluServer();
		case SpeechConstants.NLU_SCENARIO:
			return nluParams.getScenario();
		case SpeechConstants.GENERAL_HISTORY:
			return nluParams.getHistory();
		case SpeechConstants.GENERAL_CITY:
			return nluParams.getCity();
		case SpeechConstants.GENERAL_VOICEID:
			return nluParams.getVoiceId();
		default:
			return null;
		}
	}
	
	/**
	 * 取消
	 */
	protected void cancel(){
		if (nluThread != null) {
			nluThread.cancel();
			nluThread = null;
		}
	}
	
	// 回调给主线程访问
	private USCNluListener nluListener = new USCNluListener() {
		@Override
		public void onResult(String result) {
			sendMessage(MSG_NLU_RESULT, result);
		}

		@Override
		public void onEnd(int code) {
			sendMessage(MSG_NLU_END, code);
		}
	};

	// 回调语义结果给主线程
	@Override
	public void handleMessage(Message msg) {
		switch (msg.what) {
		case MSG_NLU_RESULT:
			String result = (String) msg.obj;
			doUnderstanderResult(result);
			break;
		case MSG_NLU_END:
			int code = (Integer) msg.obj;
			doUnderstandEnd(code);
			break;
		default:
			break;
		}

	}

	protected void doUnderstanderResult(String json) {
		if (understanderListener != null) {
			//NLU_RESULT
			understanderListener.onResult(NLU_RESULT, json);
		}
	}
	
	
	protected void doUnderstandEnd(int code){
		
		if (understanderListener != null) {
			understanderListener.onEvent(NLU_END);
		}
	}

	/**
	 * 启动语义线程
	 */
	private void startNluThread(String text) {
		if (nluThread != null) {
			nluThread.cancel();
		}
		nluThread = new USCNluThread(nluParams);
		nluThread.setData(text);
		nluThread.setNluListener(nluListener);
		nluThread.start();
	}

}
