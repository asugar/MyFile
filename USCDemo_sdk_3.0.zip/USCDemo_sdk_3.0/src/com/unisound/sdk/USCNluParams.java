/**
 * NluParams.java [V 1.0.0]
 * classes : cn.yunzhisheng.nlu.NluParams
 * liujunjie Create  at 2014-11-12  下午3:26:55
 */
package com.unisound.sdk;



/**
 * cn.yunzhisheng.nlu.NluParams
 * @author  liujunjie <br/>
 * Create at 2014-11-12 下午3:26:55
 *
 */
class USCNluParams extends NluRequestPo {

	/**
	 * @param appkey
	 * @param secret
	 */
	public USCNluParams(String appkey, String secret) {
		super(appkey, secret);
	}

	/**
	 * @param appkey
	 * @param secret
	 */
	public USCNluParams() {
		super();
	}
	
	private String filterName = "search";
	private boolean nluEnable = true;

	public void setNluServer(String nluServer) {
		this.nluServer = nluServer;
	}

	private String returnType = "json";
	
	private String nluServer = url;

	public boolean setNluServer(String Server, int nluPort) {
		if ((Server == null)) {
			return false;
		}
		this.nluServer = "http://" + Server + ":" + nluPort + "/service/iss";
		return true;
	}

	public String getNluServer() {
		return nluServer;
	}



	/***
	 * 设置语义字符串拼装
	 * @param params   filterName=search;returnType=json;city=上海
	 * @return
	 */
	public boolean  setNluParams(String params){
	
		return false;
		
	}
	
	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	
	public void setEnabled(boolean enable){
		this.nluEnable = enable;
	}
	
	public boolean isNluEnable(){
		return nluEnable;
	}
	
	public String  paramsToString(){
		return  FILTER_NAME+"="+getFilterName()+";"+
	                RETURN_TYPE+"="+getReturnType()+";"+
				    CITY +"="+getCity() +";" +
	                GPS +"=" + getGps() +";"  +
				    TIME +"=" + getTime() +";"+
	                SCENARIO +"=" + getScenario() +";"+
				    SCREEN +"=" + getScreen() +";" +
	                DPI +"=" + getDpi() +";" +
				    HISTORY + "=" + getHistory() +";" +
	                UDID + "=" + getUdid();
	}
}
