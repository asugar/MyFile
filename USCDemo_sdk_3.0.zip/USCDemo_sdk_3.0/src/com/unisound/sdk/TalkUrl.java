package com.unisound.sdk;

import java.util.HashMap;

import com.unisound.common.SDKUtils;

/**
 * 调用云知声语义云的URL的构造类
 */
public class TalkUrl {

	/**
	 * 构造调用语义云的URL
	 * 
	 * @param url
	 *            语义云服务访问域名
	 * @param method
	 *            方法的默认参数名
	 * @param appKey
	 *            语义云平台创建的应用的Appkey
	 * @param secret
	 *            语义云平台创建的应用的appSecret
	 * @param udid
	 *            终端用户的唯一标识，可以是手机的IMEI，设备序列号，微信ID等
	 * @param appver
	 *            开发者自己的应用的版本号
	 * @param gps
	 *            GPS数据
	 * @param ver
	 *            语义云服务协议版本号
	 * @param text
	 *            待解析文字
	 * @param history
	 *            上一次访问语义云平台返回的服务类别名称
	 * @param city
	 *            城市
	 * @param time
	 *            时间，格式：yyyy-MM-dd HH:mm:ss
	 * @param voiceId
	 *            语音日志ID
	 * @param scenario
	 *            场景
	 * @param screen
	 *            屏幕大小
	 * @param dpi
	 *            屏幕分辨率
	 * @return
	 */
	public static String getTalkUrl(String url, String method, String appKey, String secret,
			String udid, String appver, String gps, String ver, String text, String history,
			String city, String time, String voiceId, String scenario, String screen, String dpi,String platform,String viewid) {

		HashMap<String, String> needSignParams = new HashMap<String, String>();
		needSignParams.put(TalkParameterNames.APP_KEY, appKey);
		needSignParams.put(TalkParameterNames.METHOD, method);
		needSignParams.put(TalkParameterNames.VER, ver);
		needSignParams.put(TalkParameterNames.UDID, udid);
		needSignParams.put(TalkParameterNames.GPS, gps);
		needSignParams.put(TalkParameterNames.APPVER, appver);
		needSignParams.put(TalkParameterNames.TEXT, text);
		needSignParams.put(TalkParameterNames.HISTORY, history);
		needSignParams.put(TalkParameterNames.CITY, city);
		needSignParams.put(TalkParameterNames.TIME, time);
		needSignParams.put(TalkParameterNames.VOICE_ID, voiceId);
		needSignParams.put(TalkParameterNames.SCENARIO, scenario);
		needSignParams.put(TalkParameterNames.SCREEN, screen);
		needSignParams.put(TalkParameterNames.DPI, dpi);
		needSignParams.put(TalkParameterNames.PLATFORM, platform);
		needSignParams.put(TalkParameterNames.VIEWID, viewid);

		//构造签名
		String sign = SDKUtils.sign(needSignParams, secret);

		needSignParams.put(TalkParameterNames.APPSIGN, sign);

		return SDKUtils.buildGetUrl(url, needSignParams);
	}
	
}