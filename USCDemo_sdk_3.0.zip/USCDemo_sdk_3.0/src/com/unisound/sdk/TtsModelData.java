package com.unisound.sdk;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;

import com.unisound.common.FileUtil;
import com.unisound.common.LogUtil;
import com.unisound.common.MD5;

public class TtsModelData {

	private final String[][] MODELS = { { "yzsttsmodel", "2eb5fc5383feb649ce518bcfc395158d" } };

//	{"posmodel", "4feeee8f94025fe0972f505e534226a7"},
//	{"pynmodel", "94c2d52606ec7e8af0a66148b2511be0"},
//	{"segmodel", "e73ad7c7d76c423e8744275a699a75cf"},
//	{"ttsmodel", "6bc3f786cd5f0409942deff7fc4cc491"},
//	{"zhuyin.txt", "26a1cfbc3a25d9e925ddb812832a6e56"}};
	
	private static TtsModelData mInstance; 
	public static TtsModelData getInstance() {
		
		if(mInstance == null) {
			mInstance = new TtsModelData();
		}
		return mInstance;
	}

	private boolean getModelFile(Context context, String modelPath,String fileName, String md5) {
		
		File file = new File(modelPath + fileName);
		if( file.exists() && MD5.checkMD5(md5, file) ) {
			return true;
		}
		
		LogUtil.d("ModelData getModelFile:" +  fileName);
		return getAssetsModelFlie(context,fileName, file);
	}
	
	private boolean getAssetsModelFlie(Context context, String fileName, File fileTarget) {
		InputStream in = null;
		OutputStream fout = null;
		int count = 0;
		FileUtil.mkdirs(fileTarget.getAbsolutePath());
		try {
			in = context.getAssets().open(fileName);
			fout = new FileOutputStream(fileTarget);

			byte data[] = new byte[10240];
			while ((count = in.read(data, 0, 10240)) != -1) {
				fout.write(data, 0, count);
			}
			in.close();
			in = null;
			fout.close();
			fout = null;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
			if (fout != null) {
				try {
					fout.close();
				} catch (IOException e) {
				}
			}
		}
		
		return false;
	}
	
	public boolean initModel(Context context, String modelPath) {
		
		String dir = modelPath + "/";
		
		for (int i = 0; i <MODELS.length; i++) {
			String name = MODELS[i][0];
			String md5 = MODELS[i][1];
			if(false == getModelFile(context, dir,name, md5)) {
				LogUtil.e("ModelData initModel error:" + name);
				return false;
			}
		}		
		return true;
	}

}
