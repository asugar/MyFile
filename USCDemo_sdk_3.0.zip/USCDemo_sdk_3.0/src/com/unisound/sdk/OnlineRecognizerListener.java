package com.unisound.sdk;


public interface OnlineRecognizerListener extends BasicRecognizerListener {

	void onResult(String result, boolean isLast);
}
