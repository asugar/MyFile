// Copyright 2011 Google Inc. All Rights Reserved.

package com.unisound.sdk;

import android.media.AudioFormat;
import android.media.AudioTrack;
import android.util.Log;

import com.unisound.common.LogUtil;

/**
 * Exposes parts of the {@link AudioTrack} API by delegating calls to an
 * underlying {@link AudioTrack}. Additionally, provides methods like
 * {@link #waitAndRelease()} that will block until all audiotrack
 * data has been flushed to the mixer, and is estimated to have completed
 * playback.
 */
class BlockingAudioTrack {
	private static final String TAG = "TTS.BlockingAudioTrack";
	private static final boolean DBG = true;

	/**
	 * The minimum increment of time to wait for an AudioTrack to finish
	 * playing.
	 */
	private static final long MIN_SLEEP_TIME_MS = 20;

	/**
	 * The maximum increment of time to sleep while waiting for an AudioTrack
	 * to finish playing.
	 */
	private static final long MAX_SLEEP_TIME_MS = 2500;

	/**
	 * The maximum amount of time to wait for an audio track to make progress
	 * while
	 * it remains in PLAYSTATE_PLAYING. This should never happen in normal
	 * usage, but
	 * could happen in exceptional circumstances like a media_server crash.
	 */
	private static final long MAX_PROGRESS_WAIT_MS = MAX_SLEEP_TIME_MS;

	/**
	 * Minimum size of the buffer of the underlying
	 * {@link android.media.AudioTrack} we create.
	 */
	private static final int MIN_AUDIO_BUFFER_SIZE = 8192;

	private final int mStreamType;
	private final int mSampleRateInHz;
	private final int mAudioFormat;
	private final int mChannelCount;

	private final int mBytesPerFrame;
	/**
	 * A "short utterance" is one that uses less bytes than the audio
	 * track buffer size (mAudioBufferSize). In this case, we need to call
	 * {@link AudioTrack#stop()} to send pending buffers to the mixer, and
	 * slightly
	 * different logic is required to wait for the track to finish.
	 * 
	 * Not volatile, accessed only from the audio playback thread.
	 */
	private boolean mIsShortUtterance;
	/**
	 * Will be valid after a call to {@link #init()}.
	 */
	private int mAudioBufferSize;
	private int mBytesWritten = 0;

	private AudioTrack mAudioTrack;
	private volatile boolean mStopped;
	// Locks the initialization / uninitialization of the audio track.
	// This is required because stop() will throw an illegal state exception
	// if called before init() or after mAudioTrack.release().
	private final Object mAudioTrackLock = new Object();

	/**
	 * 
	 * @param streamType
	 * @param sampleRate
	 * @param audioFormat
	 * @param channelCount
	 * @param volume
	 * @param pan
	 */
	BlockingAudioTrack(int streamType, int sampleRate, int audioFormat, int channelCount) {
		mStreamType = streamType;
		mSampleRateInHz = sampleRate;
		mAudioFormat = audioFormat;
		mChannelCount = channelCount;

		mBytesPerFrame = getBytesPerFrame(mAudioFormat) * mChannelCount;
		mIsShortUtterance = false;
		mAudioBufferSize = 0;
		mBytesWritten = 0;

		mAudioTrack = null;
		mStopped = false;
	}

	public void init() {
		AudioTrack track = createStreamingAudioTrack();
		synchronized (mAudioTrackLock) {
			mAudioTrack = track;
		}
	}

	public void stop() {
		synchronized (mAudioTrackLock) {
			if (mAudioTrack != null) {
				mAudioTrack.stop();
			}
		}
		mStopped = true;
	}

	public int write(byte[] data) {
		if (mAudioTrack == null || mStopped) {
			return -1;
		}
		final int bytesWritten = writeToAudioTrack(mAudioTrack, data);
		mBytesWritten += bytesWritten;
		return bytesWritten;
	}

	public int write(byte[] audioData, int offsetInBytes, int sizeInBytes) {
		if (mAudioTrack == null || mStopped) {
			return -1;
		}
			
		return mAudioTrack.write(audioData, offsetInBytes, sizeInBytes);
	}
	
	public void waitAndRelease() {
		// For "small" audio tracks, we have to stop() them to make them
		// mixable,
		// else the audio subsystem will wait indefinitely for us to fill the
		// buffer
		// before rendering the track mixable.
		//
		// If mStopped is true, the track would already have been stopped, so
		// not
		// much point not doing that again.
		if(mAudioTrack==null) {
			return ;
		}
		
		if (mBytesWritten < mAudioBufferSize && !mStopped) {
			if (DBG) {
				Log.d(TAG, "Stopping audio track to flush audio, state was : " + mAudioTrack.getPlayState() + ",stopped= " + mStopped);
			}

			mIsShortUtterance = true;
			mAudioTrack.stop();
		}

		// Block until the audio track is done only if we haven't stopped yet.
		if (!mStopped) {
			if (DBG) Log.d(TAG, "Waiting for audio track to complete : " + mAudioTrack.hashCode());
			blockUntilDone(mAudioTrack);
		}

		// The last call to AudioTrack.write( ) will return only after
		// all data from the audioTrack has been sent to the mixer, so
		// it's safe to release at this point.
		if (DBG) Log.d(TAG, "Releasing audio track [" + mAudioTrack.hashCode() + "]");
		synchronized (mAudioTrackLock) {
			mAudioTrack.release();
			mAudioTrack = null;
		}
	}

	static int getChannelConfig(int channelCount) {
		if (channelCount == 1) {
			return AudioFormat.CHANNEL_OUT_MONO;
		} else if (channelCount == 2) {
			return AudioFormat.CHANNEL_OUT_STEREO;
		}

		return 0;
	}

	long getAudioLengthMs(int numBytes) {
		final int unconsumedFrames = numBytes / mBytesPerFrame;
		final long estimatedTimeMs = unconsumedFrames * 1000 / mSampleRateInHz;

		return estimatedTimeMs;
	}

	private static int writeToAudioTrack(AudioTrack audioTrack, byte[] data) {
		if (audioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
			if (DBG) Log.d(TAG, "AudioTrack not playing, restarting : " + audioTrack.hashCode());
			audioTrack.play();
		}
		
		int count = 0;
		while (count < data.length) {
			// Note that we don't take bufferCopy.mOffset into account because
			// it is guaranteed to be 0.

			int written = audioTrack.write(data, count, data.length);
			if (written <= 0) {
				break;
			}
			count += written;
		}
		return count;
	}

	private AudioTrack createStreamingAudioTrack() {
		final int channelConfig = getChannelConfig(mChannelCount);

		int minBufferSizeInBytes = AudioTrack.getMinBufferSize(mSampleRateInHz, channelConfig, mAudioFormat);
		int bufferSizeInBytes = Math.max(MIN_AUDIO_BUFFER_SIZE, minBufferSizeInBytes);

		AudioTrack audioTrack = new AudioTrack(mStreamType, mSampleRateInHz, channelConfig, mAudioFormat, bufferSizeInBytes, AudioTrack.MODE_STREAM);
		if (audioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
			Log.w(TAG, "Unable to create audio track.");
			audioTrack.release();
			return null;
		}

		mAudioBufferSize = bufferSizeInBytes;
		return audioTrack;
	}

	private static int getBytesPerFrame(int audioFormat) {
		if (audioFormat == AudioFormat.ENCODING_PCM_8BIT) {
			return 1;
		} else if (audioFormat == AudioFormat.ENCODING_PCM_16BIT) {
			return 2;
		}

		return -1;
	}

	private void blockUntilDone(AudioTrack audioTrack) {
		if (mBytesWritten <= 0) {
			return;
		}

		if (mIsShortUtterance) {
			// In this case we would have called AudioTrack#stop() to flush
			// buffers to the mixer. This makes the playback head position
			// unobservable and notification markers do not work reliably. We
			// have no option but to wait until we think the track would finish
			// playing and release it after.
			//
			// This isn't as bad as it looks because (a) We won't end up waiting
			// for much longer than we should because even at 4khz mono, a short
			// utterance weighs in at about 2 seconds, and (b) such short
			// utterances
			// are expected to be relatively infrequent and in a stream of
			// utterances
			// this shows up as a slightly longer pause.
			blockUntilEstimatedCompletion();
		} else {
			blockUntilCompletion(audioTrack);
		}
	}

	private void blockUntilEstimatedCompletion() {
		final int lengthInFrames = mBytesWritten / mBytesPerFrame;
		final long estimatedTimeMs = (lengthInFrames * 1000 / mSampleRateInHz);

		if (DBG) Log.d(TAG, "About to sleep for: " + estimatedTimeMs + "ms for a short utterance");

		try {
			Thread.sleep(estimatedTimeMs);
		} catch (InterruptedException ie) {
			// Do nothing.
		}
	}

	private void blockUntilCompletion(AudioTrack audioTrack) {
		final int lengthInFrames = mBytesWritten / mBytesPerFrame;

		int previousPosition = -1;
		int currentPosition = 0;
		long blockedTimeMs = 0;

		while ((currentPosition = audioTrack.getPlaybackHeadPosition()) < lengthInFrames && audioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING && !mStopped) {

			final long estimatedTimeMs = ((lengthInFrames - currentPosition) * 1000) / audioTrack.getSampleRate();
			final long sleepTimeMs = clip(estimatedTimeMs, MIN_SLEEP_TIME_MS, MAX_SLEEP_TIME_MS);

			// Check if the audio track has made progress since the last loop
			// iteration. We should then add in the amount of time that was
			// spent sleeping in the last iteration.
			if (currentPosition == previousPosition) {
				// This works only because the sleep time that would have been
				// calculated
				// would be the same in the previous iteration too.
				blockedTimeMs += sleepTimeMs;
				// If we've taken too long to make progress, bail.
				if (blockedTimeMs > MAX_PROGRESS_WAIT_MS) {
					Log.w(TAG, "Waited unsuccessfully for " + MAX_PROGRESS_WAIT_MS + "ms " + "for AudioTrack to make progress, Aborting");
					break;
				}
			} else {
				blockedTimeMs = 0;
			}
			previousPosition = currentPosition;

			if (DBG) {
				Log.d(TAG, "About to sleep for : " + sleepTimeMs + " ms," + " Playback position : " + currentPosition + ", Length in frames : " + lengthInFrames);
			}
			try {
				Thread.sleep(sleepTimeMs);
			} catch (InterruptedException ie) {
				break;
			}
		}
	}

	private static final long clip(long value, long min, long max) {
		if (value < min) {
			return min;
		}

		if (value > max) {
			return max;
		}

		return value;
	}


	public void start() {
		if(mAudioTrack != null) {
			if (mAudioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
				LogUtil.d(TAG, "AudioTrack not playing, restarting : " + mAudioTrack.hashCode());
				mAudioTrack.play();
			}
		}
	}

}
