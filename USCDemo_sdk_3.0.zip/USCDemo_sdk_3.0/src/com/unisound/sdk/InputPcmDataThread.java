package com.unisound.sdk;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import cn.yunzhisheng.asr.VADParams;

public class InputPcmDataThread extends InputSourceThread {

	private BlockingQueue<byte[]> recordQueue = new LinkedBlockingQueue<byte[]>();
	private static final int TIME_WAIT_RECORDING = 50;

	public InputPcmDataThread(VADParams vadParams, RecordingDataListener listener) {
		super(vadParams, listener);
	}

	protected boolean open() {
		recordQueue.clear();
		return true;
	}

	protected void close() {
	}

	public void writePcmData(byte[] data, int offset, int lenght) {
		
		if (!isSetToStop()) {
			
			byte[] pcm = new byte[lenght];
			System.arraycopy(data, offset, pcm, 0, lenght);
			vad.write(pcm, 0, pcm.length);
		}
		// recordQueue.add(pcm);
	}

	@Override
	protected byte[] read() {

		while (!isSetToStop() && !isCancel()) {

			byte[] queueHeadBuffer = null;
			try {
				queueHeadBuffer = recordQueue.poll(TIME_WAIT_RECORDING,
						TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (queueHeadBuffer != null) {
				return queueHeadBuffer;
			}
		}

		return null;
	}
}