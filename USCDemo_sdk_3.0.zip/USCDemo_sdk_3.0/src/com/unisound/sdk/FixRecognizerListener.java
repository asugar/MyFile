package com.unisound.sdk;

import com.unisound.sdk.BasicRecognizerListener;




public interface FixRecognizerListener extends BasicRecognizerListener {



}
