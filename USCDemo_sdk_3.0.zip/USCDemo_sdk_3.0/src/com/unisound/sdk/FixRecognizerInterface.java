package com.unisound.sdk;

import java.io.IOException;
import java.util.ArrayList;

import cn.yunzhisheng.asr.VAD;
import cn.yunzhisheng.asr.VADParams;
import cn.yunzhisheng.asrfix.JniAsrFix;
import cn.yunzhisheng.asrfix.SdkVersion;

import com.unisound.client.ErrorCode;
import com.unisound.client.SpeechConstants;

import android.content.Context;
import android.os.Message;

import com.unisound.sdk.AsrSkinViewHandle;
import com.unisound.sdk.InputPcmDataThread;
import com.unisound.sdk.ModelData;
import com.unisound.sdk.RecordingHandle;
import com.unisound.sdk.RecordingThread;
import com.unisound.sdk.VADTimeoutHandle;
import com.unisound.sdk.WakeUpRecordingDataListener;
import com.unisound.common.BeepPlayer;
import com.unisound.common.BluetoothSetting;
import com.unisound.common.DataStroe;
import com.unisound.common.AsrSkinViewInterface;
import com.unisound.common.VADTimeoutListener;
import com.unisound.common.AsrSkinViewInterface.AsrSkinViewOperateListener;
import com.unisound.common.RecordingListener;
import com.unisound.common.LogUtil;
import com.unisound.common.USCLogDataListener;

public class FixRecognizerInterface {

	public static final int DEFAULT_FRONT_SIL = VADParams.DEFAULT_FRONT_SIL;
	public static final int DEFAULT_BACK_SIL = VADParams.DEFAULT_BACK_SIL;

	public static final int SET_USER_DATA_OK = ModelData.SET_USER_DATA_OK;
	public static final int SET_USER_DATA_ERROR = ModelData.SET_USER_DATA_ERROR;
	public static final int SET_USER_DATA_WARNING = ModelData.SET_USER_DATA_WARNING;

	public static final int OPTION_SET_RESULT_FILTER = 3;
	public static final int OPT_SET_RESULT_FILTER = 3;


	/**
	 * 是否打印运行日志
	 */	
	public static final int OPT_SET_PRINT_LOG = 30;
	
	public static final int OPT_SET_SAVE_RECORDING_DATA = 48;
	
	public static final int OPT_SET_RECOGNIZER_VOICE_FILE = 49;
	
	public static final int OPTION_FIX_ASR_CONTINUOUS = 122;
	
	public static final int OPT_SET_RECORDING_ENABLED = 102;

	public static final int OPT_FRONT_VAD_ENABLED = 300;

	public static final int OPT_SET_LOG_LISTENER = 310;

	//添加json结果返回接口
	public static final int OPT_SET_RESULT_JSON = 4;
	
	private ArrayList<byte[]> recordingData = new ArrayList<byte[]>();
	private boolean isRecordingDataEnable = false;
	private boolean recordingEnabled = true;
	private String tag = null;
	


	protected FixRecognizeResult recognizeResult = new FixRecognizeResult();
	protected FixRecognizerParams params = new FixRecognizerParams();
	protected InputPcmDataThread inputPcmDataThread = null;
	private BeepPlayer beepPalyer = new BeepPlayer();
	protected ErrorCode errorCode = new MixErrorCode();
	protected FixRecognizer recognizer = new FixRecognizer();;
	protected static ModelData modelData = new ModelData();	
	
	protected WakeUpRecordingDataListener  dataListener = null;
	protected USCLogDataListener logListener;
	
	
	protected FixRecognizerHandle  fixRecognizerHandle = new FixRecognizerHandle();
	protected AsrSkinViewHandle asrSkinViewHandle = new AsrSkinViewHandle();
	protected VADTimeoutHandle vadTimeoutHandle = new VADTimeoutHandle();
	protected RecordingHandle recordingHandle = new RecordingHandle();
	private boolean isSaveRecordingData = false;
	private boolean isAddWaveHeader = false;
	private String recordingDataFile = "";
	protected Context context;
	public float DEFAULT_SCORE = -8;

	public FixRecognizerInterface(Context context, String appKey) {
		
		asrSkinViewHandle.setSkinViewOperateLinstener(asrSkinViewOperateListener);
		this.context = context;

		String modelDir = context.getApplicationContext().getFilesDir()
				+ "/YunZhiSheng/asrfix";
		modelData.setPath(modelDir);

		//离线结果返回json时生成的xml文件路径
		recognizeResult.setPath(context.getApplicationContext().getFilesDir()
				+ "/YunZhiSheng/");
		modelData.initModelList(context, ModelData.DEF_MODEL_CONFIG);
		beepPalyer.init(context);
		params.setPlayStartBeep(false);
		params.setVADTimeout(DEFAULT_FRONT_SIL, DEFAULT_BACK_SIL);
		params.setAppKey(appKey);
		
		recognizer.setParams(params);
		recognizer.setListener(recognizerListener);

		ModelData.MAX_DAT_FILE_COUNT = 1;
	}
	

	
	public RecognizerParams getParams() {
		return params;
	}
	
	protected void setListener(FixRecognizerListener listener) {
		this.fixRecognizerHandle.setListener(listener);
	}

	
	public void setVADTimeoutListener(VADTimeoutListener listener) {
		vadTimeoutHandle.setListener(listener);
	}
	
	public void setRecordingListener(RecordingListener listener) {
		recordingHandle.setListener(listener);
	}
	
	
	public void setSkinViewInterface(AsrSkinViewInterface skinView) {
		asrSkinViewHandle.setSkinViewInterface(skinView);
	}
	
	
	protected void updateListener() {
		recognizer.setPrepareRecognizerListener(prepareRecognizer);	
		recognizer.setListener(recognizerListener);			
		recognizer.setParams(params);
	}
	
	public boolean setEngine(String engine) {
		
		return false;
	}
	
	/**
	 * 引擎是否正在运行中
	 * @return
	 */
	public boolean isRunning() {
		return recognizer.isRunning();
	}

	/**
	 * 近讲、远讲选择 2014-08-27
	 * 
	 * @param
	 */
	protected boolean setFarFeild(boolean farFeild) {
		
		if (farFeild) {
			// 远讲
			// am1
			params.setModelIndex(1);
		}
		else {
			// 近讲
			// am0
			params.setModelIndex(0);
		}
		return true;
	}
	
	
	/**
	 * 
	 * @param path
	 * @param model
	 * @return
	 */
	public int reset(String model,String cmd) {
		return recognizer.reset(model,cmd);
	}
	/**
	 * 通过关键词查询词条
	 * @param poi
	 * @param words
	 * @return
	 */
	public String search(String poi,String words) {
		return recognizer.search(poi,words);		
	}
	
	protected void setOption(int id, Object value){
		if (id == SpeechConstants.ASR_OPT_ENGINE_TAG) {
			String str = (String) value;
			tag = str;			
		}
		
		//是否过滤 如果不过滤 显示标签[<s>]等
		else if( SpeechConstants.ASR_OPT_RESULT_FILTER == id) {
			boolean v = (Boolean) value;
			recognizeResult.filterResult = v;
		}
		
		//
		else if( SpeechConstants.ASR_OPT_PCM_DATA == id) {
			isRecordingDataEnable = (Boolean) value;
		}
		
		//设置录音是否可用 ， 送文件用
		else if (SpeechConstants.ASR_OPT_RECORDING_ENABLED  == id) {
			recordingEnabled = (Boolean) value;
		}
		
		//打印log
		else if (SpeechConstants.ASR_OPT_PRINT_LOG  == id) {
			LogUtil.DEBUG  = (Boolean) value;
		}
		
		//录音不暂停
		else if(SpeechConstants.ASR_OPT_FIX_ASR_CONTINUOUS == id) {
			params.setFixAsrContinuousEnabled((Boolean) value);
		}
		
		//前端vad是否可用
		if (SpeechConstants.ASR_OPT_FRONT_VAD_ENABLED == id) {
			params.setFrontVadEnabled((Boolean) value);
		}
		
		else if( SpeechConstants.ASR_OPT_LOG_LISTENER == id) {
			this.logListener = (USCLogDataListener) value;
		}
		
		//保存录音数据，传入路径
		else if(SpeechConstants.ASR_OPT_SAVE_RECORDING_DATA == id){
			this.recordingDataFile = (String) value;
		}
		
		//离线结果转为json
		else if (SpeechConstants.ASR_OPT_RESULT_JSON == id) {
			recognizeResult.result2Json = (Boolean)value;
		}
	}
	
	protected Object getOption(int id){
		if(SpeechConstants.ASR_OPT_ENGINE_TAG == id){
			return tag;
		}
		else if(SpeechConstants.ASR_OPT_PCM_DATA == id) {
			return recordingData;
		}
		else if(SpeechConstants.ASR_OPT_FIX_ASR_CONTINUOUS == id) {
			return params.isFixAsrContinuous();
		}
		else  if (SpeechConstants.ASR_OPT_FRONT_VAD_ENABLED == id) {
			return params.isFrontVadEnabled();
		}
		return null;
	}
	
	public boolean initByModelDir(String modelDir,boolean compileOptimizeEnabled) {

		if (modelDir == null || modelDir.length() == 0) {
			modelDir = context.getApplicationContext().getFilesDir()
					+ "/YunZhiSheng/asrfix";
		} else {
			modelDir = modelDir + "/YunZhiSheng/asrfix";
		}
		modelData.setPath(modelDir);
		modelData.initModelList(context, ModelData.DEF_MODEL_CONFIG);
		if (!modelData.initData(context,compileOptimizeEnabled)) {
			LogUtil.e("USCFixRecognizer.initByModelDir init data fail!");
			return false;
		}
		return true;
	}
	
		
	/**
	 * 
	 * @param compileOptimizeEnabled 
	 * @return
	 */
	public boolean initModel(boolean compileOptimizeEnabled) {
		return initByModelDir(null,compileOptimizeEnabled);
	}
	
	public boolean initModel() {
		return initByModelDir(null, false);
	}
	
	
	/**
	 * 保护标识加载模型
	 * @return
	 */
	protected int safeLoadMode(String pois, boolean reload) {
		
		modelData.setLoadModelBegin(context);
		LogUtil.d( "safeLoadMode "+ modelData.dataPath);
		if (false == recognizer.loadModel(modelData.dataPath, pois,reload)) {
			return -1;
		}
		modelData.setLoadModelSuccess(context);
		return 0;
	}
	
	/**
	 * 
	 * @param modelDir 模型目录
	 * @param pois  一个或多个用户数据模型文件逗号分割
	 * @param compileOptimizeEnabled 编译速度优化(编译用模型提前加入内存减少加载时间)
	 * @return
	 */
	public int loadByModelDir(String modelDir, String pois, boolean compileOptimizeEnabled) {

		if(!modelData.isInit) {
			initByModelDir(modelDir,compileOptimizeEnabled);
		}
		
		return safeLoadMode(pois,false);
	}
	
	public int loadByModelDir(String modelDir, String pois) {
	
		return loadByModelDir(modelDir,pois,false);
	}
	
	/**
	 * 
	 * @param pois
	 * @return
	 */
	protected int loadModel(String pois) {
		return safeLoadMode(pois, false);
	}
	
	/**
	 * 
	 * @return
	 */
	public int loadModel() {

		return safeLoadMode(modelData.getNetFile(), false);
	}
	

	/**
	 * 是否完成初始模型
	 * @return
	 */
	public boolean isInitModel() {
		return recognizer.isLoadModel();
	}
	
	public boolean isExistUserData() {
		return modelData.isExistUserData();
	}

	/**
	 * 重置AM模型,更新为SDK自带AM模型
	 * @return
	 */
	public boolean resetModel(){
		return modelData.resetModel(context);
	}

	
	
	/**
	 * 设置用户数据
	 * @param jsgf
	 * @param userData
	 * @param netDat
	 * @return
	 */
	public int setUserData(String jsgf, String userData, String netDat) {

		if(!modelData.initData(context)) {
			return SET_USER_DATA_ERROR;
		}
		
		int code = modelData.compileUserData(jsgf, userData, netDat);		
		return code;
	}

	
	/**
	 * 设置用户数据
	 * @param jsgf
	 * @param userData
	 * @return
	 */
	public int setUserData(String jsgf, String userData) {


		if(!modelData.initData(context)) {
			return SET_USER_DATA_ERROR;
		}
		
		
		int code = modelData.compileUserData(jsgf, userData, modelData.getNetFile());
		if(code == 0) {
			if(this.loadModel() == 0) {
				return this.loadModel();
			}
			else {
				return SET_USER_DATA_ERROR;
			}
		}
		return code;
	}
	
	
	public void writePcmData(byte[] data, int offset, int lenght) {
		
		if ( data != null && lenght > 0) {
			InputPcmDataThread input = inputPcmDataThread;
			if(input != null) {				
				input.writePcmData(data, offset, lenght);
			}
		}
	}
	
	/***
	 * 识别语音文件
	 * @param voiceFile  文件路径
	 */
	public void recognitionOfSpeechFile(String param,String voiceFile) {
		if (!DataStroe.checkVoiceFileValid(voiceFile)) {
			return;
		}
		inputPcmDataThread = new InputPcmDataThread(params, recognizer);
		recognizer.start(param,inputPcmDataThread);
		try {
			DataStroe.writeVoiceData(voiceFile, inputPcmDataThread);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			recognizer.stop();
		}
	}
	
	/**
	 * 默认main标签 开始识别
	 */
	protected void start() {
		start(modelData.ASR_DOMAIN);
	}
	
	
	protected void start(String param ) {
		updateListener();
		// reset status
		inputPcmDataThread = null;
		
		if (recordingEnabled) {
			RecordingThread.waitRecordingEnd();
			recognizer.start(param,new RecordingThread(params,recognizer));
		} else {
			inputPcmDataThread = new InputPcmDataThread(params,recognizer);
			recognizer.start(param,inputPcmDataThread);
		}
		
		
		if(isRecordingDataEnable) {
			recordingData = new ArrayList<byte[]>();
		}
		
		isSaveRecordingData = DataStroe.checkRecordingFileNameisValid(recordingDataFile);
		if(isSaveRecordingData){
			isAddWaveHeader = DataStroe.isWaveFile(recordingDataFile);
		}
	}
	

	protected void stop() {
		inputPcmDataThread = null;
		recognizer.stop();
		if(false == recordingEnabled) {
			recognizer.stopRecognition();
		}
	}

	protected void cancel() {
		recognizer.cancel(true);
	}

	protected String getVersion() {
		return SdkVersion.version;
	}

	public static String getFixEngineVersion() {
		return JniAsrFix.getVersion();
	}
	
	
	
	private AsrSkinViewOperateListener asrSkinViewOperateListener = new AsrSkinViewOperateListener() {
		
		@Override
		public void onSkinViewStop() {
	 		stop();	
		}
		
		@Override
		public void onSkinViewStart() {
			start();
			
		}
		
		@Override
		public void onSkinViewCancel() {
			cancel();			
		}
	};
	
	
	private RecognizerListener recognizerListener = new RecognizerListener(){

		@Override
		public void onResult(String result, boolean isLast) {
			asrSkinViewHandle.onResult(result, isLast);		
			doFixResult(result,  isLast);
		}

		@Override
		public void onEnd(int error) {
			asrSkinViewHandle.onEnd(error);
			doEnd(error);
		}

		@Override
		public void onUpdateVolume(int volume) {
			asrSkinViewHandle.onUpdateVolume(volume);
			doUpdateVolume(volume);
			recordingHandle.onUpdateVolume(volume);
		}

		@Override
		public void onUploadUserData(int error) {
			doUploadUserData(error);
		}

		@Override
		public void onRecordingStop() {
			asrSkinViewHandle.onRecordingStop();
			recordingHandle.onRecordingStop();
			doRecordingStop();
		}

		@Override
		public void onCancel() {
			doCancel();
		}

		@Override
		public void onRecordingStart() {
			asrSkinViewHandle.onRecordingStart();
			recordingHandle.onRecordingStart();
			doRecordingStart();
		}

		@Override
		public void onRecordingData(boolean enabled, byte[] data, int offset,
				int lenght) {
			doRecordingData(enabled, data, offset, lenght);
//			recordingHandle.onRecordingData(enabled, data);
		}

		@Override
		public void onRecordingDataStart() {
			doRecordingDataStart();
		}

		@Override
		public void onSpeechStart() {
			asrSkinViewHandle.onSpeechStart();
			doSpeechStart();			
		}

		@Override
		public boolean isStopRecording() {

			return FixRecognizerInterface.this.isStopRecording();
		}
		
		@Override
		public void onLogData(int what, int type, Object object) {
			doLogData( what, type, object);
			
		}

		@Override
		public void onVADTimeout(VAD sender) {
			asrSkinViewHandle.onVADTimeout();
			doVADTimeout(sender);
			
			if (!asrSkinViewHandle.isEnabled() && 
					!fixRecognizerHandle.isEnabled() && 
					!vadTimeoutHandle.isEnabled()) {
				// 主动sotp
				stop();
			}			
		}

		@Override
		public boolean onHandleMessage(Message msg) {
			return doHandleMessage(msg);			
		}

	};
	
	private PrepareRecognizerListener prepareRecognizer = new PrepareRecognizerListener() {
		@Override
		public int onPrepareRecognizer() {

			return doPrepareRecognizer();
		}
	};
	

	protected boolean doHandleMessage(Message msg) {
		return false;		
	}
	
	protected void doFixResult(String result, boolean isLast) {

	}

	protected void doLogData(int what, int type, Object object) {

		if(logListener != null) {
			logListener.onLogData(what, type, object);
		}		
	}

	protected int doPrepareRecognizer() {
		return ErrorCode.RECOGNIZER_OK;		
	}
	protected void doSpeechStart() {
	
	}

	/**
	 * 是否放弃启动录音
	 * @return
	 */
	protected boolean isStopRecording() {
		return false;
	}

	protected void doEnd(int error) {

		if (error != JniAsrFix.ASRCLIENT_OK) {
			recognizer.cancel(false);
		}
	}


	protected void doVADTimeout(VAD sender) {
			fixRecognizerHandle.onVADTimeout();
	}

	protected void doUpdateVolume(int volume) {
			fixRecognizerHandle.onUpdateVolume(volume);
	}

	protected void doUploadUserData(int error) {
	}


	protected void doRecordingStop() {
		//判断是否给语音文件加入wav头
		if(isSaveRecordingData && isAddWaveHeader){
			DataStroe.addWaveHeader(recordingDataFile);
		}
		resetSaveRecordInfo();
	}
	
	private void resetSaveRecordInfo() {
		recordingDataFile = "";
		isSaveRecordingData = false;
		isAddWaveHeader = false;
	}
	
	protected void doCancel() {
		
	}

	protected void doRecordingStart() {
		if (params.isPlayStartBeep()) {
			beepPalyer.playAsrStartBeep();
		}
		
		fixRecognizerHandle.onRecognizerStart();
	}

	protected void doRecordingData(boolean enabled, byte[] data, int offset,
			int length) {
		if(dataListener!=null){
			dataListener.onRecordingData(data, offset, length);
		}
		
		if(isRecordingDataEnable) {
			recordingData.add(data);
		}
		
		if (isSaveRecordingData) {
			DataStroe.saveRecordingData(data, recordingDataFile);
			LogUtil.d("doRecordingData........");
		}
	}

	protected void doRecordingDataStart() {

	}

	
	public static boolean checkModelFile(String modelFile) {
		
		return ModelData.checkAMFile(modelFile);
	}
	
	public void setVADTimeout(int frontSil, int backSil) {
		params.setVADTimeout(frontSil, backSil);
	}

	protected void release() {
		modelData.unInit();
		recognizer.release();
	}
	
	public void setRecordingDataListener(WakeUpRecordingDataListener listener){
		this.dataListener = listener;
	}
	
	/**
	 * 启用蓝牙耳机录音
	 * 
	 * @param context
	 */
	public boolean startBluetoothSco(Context context) {
		return BluetoothSetting.startBluetoothSco(context);
	}

	/**
	 * 停用蓝牙耳机录音,
	 * 
	 * @param context
	 */
	public boolean stopBluetoothSco(Context context) {
		
		return BluetoothSetting.stopBluetoothSco(context);
	}
}
