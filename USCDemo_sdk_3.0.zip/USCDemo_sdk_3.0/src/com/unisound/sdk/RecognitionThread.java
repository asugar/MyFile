package com.unisound.sdk;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import cn.yunzhisheng.asr.JniUscClient;
import cn.yunzhisheng.asrfix.SdkVersion;

import com.unisound.client.ErrorCode;
import com.unisound.common.Addresser;
import com.unisound.common.DeviceInfoUtil;
import com.unisound.common.Functions;
import com.unisound.common.LogUtil;
import com.unisound.common.Scene;

public class RecognitionThread extends Thread {

	private static final int TIME_WAIT_RECORDING = 200;
	private RecognitionListener recognitionListener = null;
	private BlockingQueue<byte[]> recordQueue = new LinkedBlockingQueue<byte[]>();
	private PcmAllZeroCheck pcmAllZeroCheck = new PcmAllZeroCheck();
	private RecognizerParams params;
	private String sessionId = "";
	private volatile boolean setToStopped = false;
	private String tempResult = "";
	
	public RecognitionThread(RecognizerParams params) {
		this.params = params;
		PcmAllZeroCheck.enabled = true;
	}

//	private void log_v(String log) {
//		LogUtil.v("RecognitionThread -- " + log);
//	}
	

	public boolean isSetToStop() {

		return setToStopped;
	}

	public void stopRecognition() {
		setToStopped = true;
	}

	public void cancel() {
		recognitionListener = null;
		setToStopped = true;
	}

	public boolean isCancelled() {
		return (recognitionListener == null);
	}

	private JniUscClient initUscClient() {

		JniUscClient juc = new JniUscClient();

		// address
		Addresser addresser = params.getAddressser();
		long ret = juc.create(addresser.getIP(), addresser.getPort());
        LogUtil.d("server :"+ addresser.getIP() +" prot: "+addresser.getPort());
		if (ret == 0) {
			LogUtil.d(this.toString() + "juc.create() returns " + ret);
		}
		

		addVPRParams(juc);
		addNluParams(juc);
		addAsrParams(juc);
		addColectedInfo(juc);
	

		LogUtil.erron = 0;
		LogUtil.d("juc init success");
		return juc;
	}

	/**
	 * 声纹参数设置
	 * @param juc
	 */
	private void addVPRParams(JniUscClient juc) {
		VPRParams vpr = params.getVPRParams();
		if(vpr.isEnabled()) {
			juc.setOptionInt(JniUscClient.VPR_INIT, 8);
			juc.setOptionInt(JniUscClient.VPR_MD5_CHECK, 1);
			juc.setOptionString(JniUscClient.VPR_OPT_SECRET, params.getSecret());
			StringBuilder sb = new StringBuilder();
			sb.append("type=");
			if (vpr.getVPRType() == VPRParams.VPR_TYPE_REGISTERED) {
				sb.append("register");
			} else if (vpr.getVPRType() == VPRParams.VPR_TYPE_VERIFY) {
				sb.append("matchSingle");
			}
			sb.append(";");
			sb.append("userName=").append(vpr.getUserName()).append(";");
			sb.append("appkey=").append(params.getAppKey()).append(";");
			sb.append("filterName=").append("vpr").append(";");
			sb.append("returnType=").append("json").append(";");
			LogUtil.d("vpr params:  " + sb.toString());
			juc.setOptionString(JniUscClient.VPR_SEND_PARAMS, sb.toString());
		}		
	}

	/**
	 * 语义参数设置
	 * @param juc
	 */
	private void addNluParams(JniUscClient juc) {
		USCNluParams  nluParams = params.getNluParams();
		if (nluParams!=null && nluParams.isNluEnable()) {
				juc.setOptionString(JniUscClient.ASR_NLU_PARAMETER,
						nluParams.paramsToString());
				LogUtil.d("nluParams: " + nluParams.paramsToString());
		}	
	}
	
	/**
	 * 设备信息收集
	 * @param juc
	 */
	private void addColectedInfo(JniUscClient juc) {

		// collected info
		StringBuilder sb = new StringBuilder();
		sb.append(DeviceInfoUtil.packageName).append(":");
		sb.append(JniUscClient.DEVICE_OS_Android).append(":");
		sb.append(DeviceInfoUtil.carrier).append(":");
		sb.append(params.networkType).append(":");
		sb.append(DeviceInfoUtil.model).append(":");
		sb.append(SdkVersion.version);
		sb.append("\t" + LogUtil.erron + ":" + JniUscClient.state + ":"
				+ JniUscClient.erron);

//		juc.setOptionInt(JniUscClient.ASR_OPT_NET_PACKAGE_SIZE, 9600);// 9600bytes  
		juc.setOptionString(JniUscClient.ASR_OPT_COLLECTED_INFO, sb.toString());
	}

	/**
	 * 设置识别参数
	 * @param juc
	 */
	private void addAsrParams(JniUscClient juc) {

		// 2014-12-26 update engine params
		EngineParams engineParams = params.getEngineParams();

		if(engineParams.isEnabled()) {
			juc.setOptionString(JniUscClient.ASR_ENGINE_PARAMETER,	engineParams.toString());
			LogUtil.d(this.toString() +"initUscClient engineParams " + engineParams.toString());
			
			updateAsrScene(juc, params.getASRStartScene());
		}

		if (params.ASR_USRDATA_PROTOCOL_ENABLED) {

			if (params.ASR_USRDATA_ENABLED) {
				juc.setOptionString(JniUscClient.ASR_USRDATA_FLAG,
						JniUscClient.ASR_USRDATA_FLAG_OPEN);
			} else {
				juc.setOptionString(JniUscClient.ASR_USRDATA_FLAG,
						JniUscClient.ASR_USRDATA_FLAG_CLOSE);
			}
		}

		if (params.asrReqSpeakerInfo != 0) {
			juc.setOptionInt(JniUscClient.ASR_REQ_SPEAKER_INFO,
					params.asrReqSpeakerInfo);
		}

		// temp result enabled
		juc.setTempResultEnabled(params.isTempResultEnabled());
		
		juc.setOptionInt(JniUscClient.ASR_OPT_ENABLE_VAD, params.enableVAD);
		juc.setOptionInt(JniUscClient.ASR_OPT_VAD_TIMEOUT, params.VADTimeout);
		juc.setOptionInt(JniUscClient.ASR_OPT_PCM_COMPRESS, params.spxQuality);
		juc.setOptionInt(JniUscClient.ASR_OPT_RESULT_TIMEOUT,
				params.resultTimeout);
		juc.setOptionString(JniUscClient.ASR_OPT_SERVICE_KEY, params.getAppKey());
		juc.setOptionString(JniUscClient.ASR_OPT_DEVICE_IMEI,DeviceInfoUtil.imei);


		// user id
		juc.setOptionString(JniUscClient.ASR_USER_ID, DeviceInfoUtil.imei);

		if (params.isSessionIdEnabled()) {
			// session id
			juc.setOptionString(JniUscClient.ASR_REQ_RSP_ENTITY,
					JniUscClient.ASR_OPT_RSP_ENTITY);
		}
	}
	
	
	private void updateAsrScene(JniUscClient juc, Scene scene) {
		//scene id
		if(scene != null && scene.isEnabled()){
			int res = juc.setOptionInt(JniUscClient.ASR_SCENE_ID, scene.getSceneId());
			LogUtil.e("updateAsrScene "+scene.getSceneId() +" res : " + res);
			scene.setEnabled(false);
		}		
	}

	private void onRecognitionEnd() {
		RecognitionListener listener = recognitionListener;
		stopRecognition();
		if (listener != null) {
			listener.onRecognitionEnd();
		}
	}

	private void onRecognitionMaxSpeechTimeout() {
		RecognitionListener listener = recognitionListener;
		stopRecognition();
		if (listener != null) {
			listener.onRecognitionMaxSpeechTimeout();
		}
	}

	private void onRecognitionError(int code) {
		RecognitionListener listener = recognitionListener;
		stopRecognition();
		if (listener != null) {
			listener.onRecognitionError(code);
		}
	}

	private void onRecognitionResult(String result, boolean isLast) {
		RecognitionListener listener = recognitionListener;
		if (listener != null) {
			listener.onRecognitionResult(result, isLast);
		}
	}

	@Override
	public void run() {

		JniUscClient juc = initUscClient();

		sessionId = "";
		LogUtil.d("recogniton -> run");
		int startCode = 0;
		if ((startCode = juc.start()) != JniUscClient.ASRCLIENT_CREATE_SERVICE_OK) {
			LogUtil.d("recogniton -> start error=" + startCode);
			onRecognitionError(startCode);
			juc.destroy();
			params.resetDNS();
			return;
		}
		
		LogUtil.d("recogniton -> start");

		// cancel
		if (isCancelled()) {
			juc.cancel();
			LogUtil.d("recogniton -> cancel(start)");
			juc.destroy();
			return;
		}

		byte[] queueHeadBuffer = null;
		while (true) {

			try {

				queueHeadBuffer = recordQueue.poll(TIME_WAIT_RECORDING,
						TimeUnit.MILLISECONDS);
				if (queueHeadBuffer != null) {
					int recognizeCode = juc.recognize(queueHeadBuffer,
							queueHeadBuffer.length);

					if (recognizeCode == JniUscClient.ASRCLIENT_RECOGNIZER_OK
							|| recognizeCode == JniUscClient.ASRCLIENT_RECOGNIZER_NO_RESULT) {

					} else if (recognizeCode == JniUscClient.ASRCLIENT_RECOGNIZER_PARTIAL_RESULT) {

						String partial = juc.getResult();
						if (partial != null && !"".equals(partial) || params.isTempResultEnabled()) {
							LogUtil.i("recogniton -> partial=" + partial);
							tempResult = juc.getOptionValue(JniUscClient.SSUP_RSP_RESULT_PARAMETER);
							onRecognitionResult(partial, false);
						}						
						
					} else if (recognizeCode == JniUscClient.ASRCLIENT_MAX_SPEECH_TIMEOUT) {
						LogUtil.d("recogniton -> max speech timeout");
						onRecognitionMaxSpeechTimeout();
					} else if (recognizeCode == JniUscClient.ASRCLIENT_VAD_TIMEOUT) {
						LogUtil.d("recogniton -> vad timeout");
					} else {
						LogUtil.d("recogniton -> error:" + recognizeCode);
						onRecognitionError(recognizeCode);
						juc.destroy();
						params.resetDNS();
						return;
					}
				}

				if (setToStopped && recordQueue.size() == 0) {
					LogUtil.d("recogniton -> break");
					break;
				}

				// cancel
				if (isCancelled()) {
					juc.cancel();
					LogUtil.d("recogniton -> cancel(recognizer)");
					juc.destroy();
					return;
				}

			} catch (Exception e) {
				LogUtil.e("recogniton -> exception");
				onRecognitionError(ErrorCode.RECOGNITION_EXCEPTION);
				JniUscClient.state = ErrorCode.RECOGNITION_EXCEPTION;
				JniUscClient.erron = 0;
				juc.destroy();
				return;
			}
		}

		tempResult = "";
		int stopCode = juc.stop();
		if (stopCode < 0) {
			onRecognitionError(stopCode);
			juc.destroy();
			return;
		}

		LogUtil.d("recogniton -> stop");
		sessionId = juc.getOptionValue(JniUscClient.SSUP_RSP_AUDIO_URL);
		params.setSessionId(sessionId);

		if (params.asrReqSpeakerInfo != 0) {
			params.asrRspSpeakerInfo = Functions.strToInt(juc
					.getOptionValue(JniUscClient.SSUP_RSP_SPEAKER_INFO));
			LogUtil.d("recogniton -> asrRspSpeakerInfo="
					+ params.asrRspSpeakerInfo);
		}

		String partial = juc.getResult();
		LogUtil.d("recogniton -> last=" + partial);
		onRecognitionResult(partial, true);
		onRecognitionEnd();

		LogUtil.d("recognition -> released");
		juc.destroy();
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setRecognitionListener(RecognitionListener listener) {
		recognitionListener = listener;
	}

	public void addData(byte[] data) {
		pcmAllZeroCheck.isFirstActive(data, 0, data.length);

		if (false == pcmAllZeroCheck.isActive()) {
			return;
		}

		recordQueue.add(data);
	}

	public void addData(List<byte[]> recordingData) {

		for (byte[] data : recordingData) {
			recordQueue.add(data);
		}
	}

	public void waitEnd() {
		cancel();
		if (isAlive()) {
			try {
				join(39000);
				LogUtil.d("RecognitionThread::waitEnd()");
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}
	}

	public String getTempResult() {
		return tempResult;
	}
}
