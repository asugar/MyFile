package com.unisound.sdk;

import cn.yunzhisheng.asrfix.JniAsrFix;
import com.unisound.common.LogUtil;



public class Compiler {

	public static final int OK = 0;
	public static final int LOAD_ERROR = -1;

	
	private  long handle = 0;

	public boolean init(String szModelPath) {

		handle = JniAsrFix.initUserDataCompiler(szModelPath);
		LogUtil.d("compile  initUserDataCompiler handle="  + handle);
		if(handle != 0){

			return true;
		}
		return (handle == 0);
	}

	public boolean isInit() {
		return handle != 0;
	}

	
	public static int compileUserData(String jsgf, String szContent, String modelPath, String netDat) {

		return JniAsrFix.compileUserData_(jsgf, szContent,modelPath,netDat);
	}
	
	public int compile(String jsgf, String szContent, String netDat) {

		if (handle == 0) {		
			LogUtil.d("compile  compileUserData fail handle=0");
			return MixErrorCode.FIX_COMPILE_NO_INIT;
		}
		
		int code = JniAsrFix.compileUserData(handle, jsgf, szContent,netDat);
		if(code == 0) {
			LogUtil.d("compile  compileUserData ok");	
		}
		else {
			LogUtil.d("compile  compileUserData fail code = " + code);		
		}
		
		return code;
	}
	
	
	

	public void unInit() {
		if (handle != 0) {
			LogUtil.d("compile  destroyUserDataCompiler");
			JniAsrFix.destroyUserDataCompiler(handle);
			handle = 0;
		}
	}
}
