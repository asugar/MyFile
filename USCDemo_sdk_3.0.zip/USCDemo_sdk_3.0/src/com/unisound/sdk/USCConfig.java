package com.unisound.sdk;

public class USCConfig {

	// type
	public static final int NAME  = 1;
	public static final int APP   = 2;
	public static final int SONG  = 3;
	
	/** 2014-06-10 add */
	public static final int SINGER  = 4;
	public static final int ALBUM   = 5;
	public static final int COMMAND  = 6;
	public static final int POI  = 7;	

	// max size
	public static final int MAX_NAME  = 4000;
	public static final int MAX_APP   = 1000;
	public static final int MAX_SONG  = 1000;
	

	/** 2014-06-10 add */
	public static final int MAX_SINGER  = 1000;
	public static final int MAX_ALBUM   = 1000;
	public static final int MAX_COMMAND  = 1000;
	public static final int MAX_POI  = 1000;
}
