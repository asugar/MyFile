package com.unisound.sdk;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import android.util.Log;
import com.unisound.common.ResultToJsonUtil;


public class FixRecognizeResult {
	
	public List<String> items = new ArrayList<String>();
	public boolean filterResult = true;
	//添加json结果返回接口
	public boolean result2Json = false;
	public String text;
	public float score;
	private String xmlPath;
	
//	public void setResult(String text) {
//		String item[] = text.split("\n");
//		score = -25;
//		int len = item.length - 1;
//		if (len > 0) {
//			score = getFloat(item[len]);
//			this.text = text.replace(item[len],"").trim();
//		}
//		else {
//			this.text = "";
//		}		
//	}

	public String toString(){
		if(text != null && text.length() > 0){
			return text + "\n" + score;
		}
		return "";
	}
	
	public String getText() {
		
		for(String text: items) {
			return text;
		}
		
		return "";
	}
	
	public boolean setResult(String text) {
		this.text = "";
		if( text == null ){
			return false;
		}

		if( text.length() == 0 ){
			return false;
		}

		
		final Pattern dels = Pattern.compile("<s>|</s>");
		final Pattern key = Pattern.compile("<[\\w]*>");
		final Pattern del = Pattern.compile("<[\\w]*>");
		text = dels.matcher(text).replaceAll("");
		text = key.matcher(text).replaceAll("\n");
		text = text.replaceAll("/","");
		text = text.replaceAll("\n\n","\n");	
//		text = text.replaceAll(" ","");
		text = del.matcher(text).replaceAll("");
		
		String item[] = text.split("\n");		
		score = -25;
		int len = item.length - 1;
		if (len > 0) {
			score = getFloat(item[len]);
			if(len == 1 ){
				this.text = item[0];	
			}
			else {
				this.text = item[0] + item[len-1];
			}	
			return true;
		}
		
		return false;		
	}
	
	public boolean setResultList(String text) {
	    this.items.clear();
	    if (text == null) {
	      return false;
	    }
	    
	    if(text.length() == 0 ){
	    	return false;
	    }

	    if (result2Json == true) {
            String[] arrayOfString = text.split("\n");
		    this.score = -25.0F;
		    int i = arrayOfString.length - 1;
		    Log.d("RecognizeResult", "setResultList : arrayOfstring.length =" + arrayOfString.length);
		    if (i > 0) {
		      this.score = getFloat(arrayOfString[i]);
		      for (int j = 0; j < i; j++) {
                  //将得到Json类型的字符串添加到回调的集合中
                  try {
					String jsonString =
							ResultToJsonUtil.getResultJsonUsePullParser(arrayOfString[j], this.score, xmlPath + "result.xml")
							.toString().replace(" ", "").replace("_" ,"");
					this.items.add(jsonString);
				} catch (Exception e) {
					e.printStackTrace();
				}
		      }
		      return true;
		    }
		    return false;
	    }
	    if(false == filterResult) {
	        String[] arrayOfString = text.split("\n");
		    this.score = -25.0F;
		    int i = arrayOfString.length - 1;
		    if (i > 0) {
		      this.score = getFloat(arrayOfString[i]);
		      for (int j = 0; j < i; j++)
		        this.items.add(arrayOfString[j]);
		      return true;
		    }
	    	return false;
	    }
	    
	    Pattern localPattern1 = Pattern.compile("<s>|</s>");
	    Pattern localPattern2 = Pattern.compile("<[\\w]*>");
	    Pattern localPattern3 = Pattern.compile("<[\\w]*>");
	    text = localPattern1.matcher(text).replaceAll("");
	    text = localPattern2.matcher(text).replaceAll("");
	    text = text.replaceAll("/", "");
	    text = localPattern3.matcher(text).replaceAll("");

	    String[] arrayOfString = text.split("\n");
	    this.score = -25.0F;
	    int i = arrayOfString.length - 1;
	    if (i > 0) {
	      this.score = getFloat(arrayOfString[i]);
	      for (int j = 0; j < i; j++)
	        this.items.add(arrayOfString[j]);
	      return true;
	    }
	    return false;
	  }
	
	public static String getText( float gate , String text) {

		String item[] = text.split("\n");
		int len = item.length - 1;
		if (len > 0) {
			if (gate > getFloat(item[len])) {
				return "";
			}
			text = text.replace(item[len],"").trim();
		}
		
		return text;
	}

	public static float getFloat(String value) {
		try {
			return Float.parseFloat(value);
		} catch (Exception e) {
		}
		return -100;
	}

	//生成的xml的存放目录
	public void setPath(String dirpath) {
		this.xmlPath = dirpath;
	}
}
