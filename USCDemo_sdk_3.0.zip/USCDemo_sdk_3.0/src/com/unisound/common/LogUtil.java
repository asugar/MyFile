package com.unisound.common;


import android.util.Log;

public class LogUtil {

	public static final int WHAT_TYPE_ASR_START = 0;
	public static final int WHAT_TYPE_ASR_FEED = 1;
	public static final int WHAT_TYPE_ASR_END = 2;
	public static final int WHAT_TYPE_ASR_PART_RESULT = 3;
	public static final int WHAT_TYPE_ASR_STOP_RESULT = 4;
	public static final int WHAT_TYPE_LOG = 5;
	
	public static final int LOG_TYPE_NULL = 0;
	public static final int LOG_TYPE_INT = 1;
	public static final int LOG_TYPE_STRING = 2;
		
	public static final int LOG_TYPE_BYTES = 3;
	
	private static USCLogDataListener listener = null;
	
	public static boolean DEBUG = false;
	public static final String TAG = "USC";
	public static int erron = 0;
	
	public static void v(String tag, String msg){
		if(DEBUG){
			Log.v(tag, msg);
			writeLog(msg);
		}
	}
	
	public  static void setListener(USCLogDataListener listener) {
		LogUtil.listener = listener;
	}
	
	private static void writeLog(String str) {
		if(listener != null) {
			listener.onLogData(WHAT_TYPE_LOG, LOG_TYPE_STRING, str);
		}
	}
	
	
		
	public static void v(String msg){
		if(DEBUG){
			Log.v(TAG, msg);
			writeLog(msg);
		}
	}
	
	public static void i(String tag, String msg){
		if(DEBUG){
			Log.i(tag, msg);
			writeLog(msg);
		}
	}
	
	public static void i(String msg){
		if(DEBUG){
			Log.i(TAG, msg);
			writeLog(msg);
		}
	}
	
	
	public static void d(String tag, String msg){
		if(DEBUG){
			Log.d(tag, msg);
			writeLog(msg);
		}
	}
	
	public static void d(String msg){
		if(DEBUG){
			Log.d(TAG, msg);
			writeLog(msg);
		}
	}
	
	public static void w(String tag, String msg){
		if(DEBUG){
			Log.w(tag, msg);
			writeLog(msg);
		}
	}
	
	public static void w(String msg){
		if(DEBUG){
			Log.w(TAG, msg);
			writeLog(msg);
		}
	}
	
	public static void e(String tag, String msg, Throwable tr) {
		if (DEBUG) {
			android.util.Log.e(tag, msg, tr);
		}
	}
	
	public static void e(String msg, Throwable tr) {
		e(TAG, msg, tr);
	}
	
	public static void e(String tag, String msg){
		if(DEBUG){
			Log.e(tag, msg);
			writeLog(msg);
		}
	}
	
	public static void e(String msg){
		//if(DEBUG){
			Log.e(TAG, msg);
			writeLog(msg);
		//}
	}
	
}
