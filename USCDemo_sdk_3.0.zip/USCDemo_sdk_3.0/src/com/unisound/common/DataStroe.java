/**
 * DataStroe.java [V 1.0.0]
 * classes : cn.yunzhisheng.asr.utils.DataStroe
 * liujunjie Create  at 2014-1-10  上午10:29:32
 */
package com.unisound.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;

import android.content.Context;
import android.text.TextUtils;

import com.unisound.sdk.InputPcmDataThread;

/**
 * cn.yunzhisheng.asr.utils.DataStroe
 * 
 * @author liujunjie <br/>
 *         Create at 2014-1-10 上午10:29:32
 * 
 */
public class DataStroe {

	public enum extensionName {
		NO_EXTENSION_NAME, PCM_EXTENSION_NAME, WAV_EXTENSION_NAME, OTHER_EXTENSION_NAME
	};

	private static void mkdirs(String path) {
		if (path == null) {
			return;
		}
		int index = path.lastIndexOf('/');
		if (index >= 0) {
			File file = new File(path.substring(0, index));
			file.mkdirs();
		}
	}

	private static boolean getAssetsModelFlie(Context context, String fileName,
			File fileTarget) {
		InputStream in = null;
		OutputStream fout = null;
		int count = 0;
		mkdirs(fileTarget.getAbsolutePath());
		try {

			in = context.getAssets().open(fileName);
			fout = new FileOutputStream(fileTarget);

			byte data[] = new byte[10240];
			while ((count = in.read(data, 0, 10240)) != -1) {
				fout.write(data, 0, count);
			}
			in.close();
			in = null;
			fout.close();
			fout = null;
			return true;
		} catch (Exception e) {
			LogUtil.v("getAssetsModelFlie Exception fileName=" + fileName);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
			if (fout != null) {
				try {
					fout.close();
				} catch (IOException e) {
				}
			}
		}

		return false;
	}

	public static boolean saveVoiceToDataDir(Context context,
			String assetsFileName, String targetPath, String md5) {

		File targetFile = new File(targetPath);
		if (targetFile.exists() && MD5.checkMD5(md5, targetFile)) {
			return true;
		}

		return getAssetsModelFlie(context, assetsFileName, targetFile);
	}

	public static boolean saveRecordingData(byte[] recordingData, String path) {
		mkdirs(path);
		RandomAccessFile accessFile = null;
		try {
			accessFile = new RandomAccessFile(path,"rw");
			long length = accessFile.length();
			accessFile.seek(length);
			accessFile.write(recordingData);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (accessFile != null) {
				try {
					accessFile.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return false;
	}

	/**
	 * 获取文件扩展名
	 * 
	 * @param fileName
	 * @return extensionName
	 */
	private static extensionName getExtensionName(String fileName) {
		extensionName name = null;
		if (TextUtils.isEmpty(fileName)) {
			return name;
		}
		int index = fileName.lastIndexOf(".");
		String fileHeader = "";
		if (index > 0) {
			fileHeader = fileName.substring(index + 1);
			if (TextUtils.isEmpty(fileHeader)) {
				name = extensionName.NO_EXTENSION_NAME;
			} else if (fileHeader.equalsIgnoreCase("pcm")) {
				name = extensionName.PCM_EXTENSION_NAME;
			} else if (fileHeader.equalsIgnoreCase("wav")) {
				name = extensionName.WAV_EXTENSION_NAME;
			} else {
				name = extensionName.OTHER_EXTENSION_NAME;
			}
		}
		LogUtil.d("getExtensionName : " + name.toString());
		return name;
	}

	/**
	 * 给语音文件添加WAV头
	 * 
	 * @param filePath
	 * @return
	 */
	public static boolean addWaveHeader(String filePath) {
		File file = new File(filePath);
		RandomAccessFile accessFile = null;
		if (!file.exists()) {
			return false;
		}
		try {
			accessFile = new RandomAccessFile(file, "rw");
			int length = (int) accessFile.length();
			accessFile.seek(0);
			byte[] header = WaveHeader.getHeader(length, 1, 16000);
			if (header != null) {
				accessFile.write(header);
				return true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (accessFile != null) {
				try {
					accessFile.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	/**
	 * 检查录音文件格式是否合法
	 * 
	 * @param recordingDataFile
	 * @return
	 */
	public static boolean checkRecordingFileNameisValid(String recordingDataFile) {
		if (TextUtils.isEmpty(recordingDataFile)) {
			return false;
		}
		return isExtensionValid(recordingDataFile);
	}


	public static boolean isWaveFile(String fileName) {
		extensionName mExtName = getExtensionName(fileName);
		if (mExtName == extensionName.WAV_EXTENSION_NAME) {
			return true;
		}
		return false;
	}
	
	public static boolean checkVoiceFileValid(String voiceFile) {
		File file = new File(voiceFile);
		if (!file.exists() ) {
			return false;
		}
		return isExtensionValid(voiceFile);
	}
	
	
	private static boolean isExtensionValid(String recordingDataFile) {
		extensionName mExtensionName = getExtensionName(recordingDataFile);
		if (mExtensionName == extensionName.PCM_EXTENSION_NAME
				|| mExtensionName == extensionName.WAV_EXTENSION_NAME) {
			return true;
		}
		LogUtil.e("fileName illegal");
		return false;
	}
	
	public static void writeVoiceData(String voiceFile,
			InputPcmDataThread inputPcmDataThread) throws IOException {
		InputStream in = null;
		try {
			byte[] buffer = new byte[640];
			in = new FileInputStream(voiceFile);
			while (true) {
				int read = in.read(buffer, 0, buffer.length);
				if (read < 0) {
					break;
				}
				inputPcmDataThread.writePcmData(buffer, 0, read);
			}
		}  finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
