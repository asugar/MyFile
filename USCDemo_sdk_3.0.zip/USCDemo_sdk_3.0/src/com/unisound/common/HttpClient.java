package com.unisound.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * SDK中默认的HTTP客户端
 */
public class HttpClient {
	
	public static String httpGet(String urlString) {
		return httpGet(urlString, 30*1000);
	}
	
	public static String httpGet(String urlString, int timeoutMillis) {
		URL url = null;
		InputStream in = null;
		BufferedReader reader = null;
		HttpURLConnection conn = null;
		String response = "";
		try {
			url = new URL(urlString);
			conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(timeoutMillis);
			conn.setRequestMethod("GET");
			conn.connect();
			int status_code = conn.getResponseCode();
			if (status_code == HttpURLConnection.HTTP_OK) {
				in = conn.getInputStream();
				reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
				String readLine = "";
				while ((readLine = reader.readLine()) != null) {
					response = response + readLine;
				}
			} else {
				response = "{}";
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			url = null;
			urlString = null;
			try {
				if (in != null) {
					in.close();
					in = null;
				}
				if (reader != null) {
					reader.close();
					reader = null;
				}
				if (conn != null) {
					conn.disconnect();
					conn = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return response;
	}

	public static String httpPost(String urlString, byte[] data) {
		return httpPost(urlString, data, 30*1000);
	}
	
	
	public static String httpPost(String urlString, byte[] data,int timeoutMillis) {
		HttpURLConnection conn = null;
		String response = "";
		try {
			URL url = new URL(urlString);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestProperty("Accept-Charset", "UTF-8");
			conn.setRequestMethod("POST");
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setConnectTimeout(timeoutMillis);

			OutputStream out = conn.getOutputStream();
			out.write(data);
			out.flush();
			out.close();

			if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
				BufferedReader resultReader = new BufferedReader(new InputStreamReader(
						conn.getInputStream(), "utf-8"));
				String line = "";
				while ((line = resultReader.readLine()) != null) {
					response += line;
				}
				resultReader.close();
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		
		return response;
	}

	public static String httpPost(String url, String data) {
		return httpPost(url, data.getBytes());
	}
}