package com.unisound.common;

import android.content.Context;
import android.media.AudioManager;

public class BluetoothSetting {

	
	/**
	 * 启用蓝牙录音输入
	 * 
	 * @param context
	 */
	public static boolean  startBluetoothSco(Context context) {
		
		if(checkPermission(context)) {
			
			AudioManager audioManager = (AudioManager) context
					.getSystemService(Context.AUDIO_SERVICE);
			if(audioManager != null) {
				audioManager.setBluetoothScoOn(true);
				audioManager.startBluetoothSco();
			}
		}
		
		return true;
	}

	/**
	 * 蓝牙权限检测，防止无权限异常
	 * @param context
	 * @return
	 */
	public static boolean checkPermission(Context context) {
		
//		if(CheckPermission.check(context, CheckPermission.INTERNET)) {
//			return true;
//		}
//		LogUtil.e("BluetoothSetting.checkPermission fail");
//		return false;
		return true;
	}
	
	
	/**
	 * 停用蓝牙录音输入,
	 * 
	 * @param context
	 */
	public static boolean stopBluetoothSco(Context context) {

		
		if(checkPermission(context)) {
			
			AudioManager audioManager = (AudioManager) context
					.getSystemService(Context.AUDIO_SERVICE);
			if(audioManager != null) {
				audioManager.setBluetoothScoOn(false);
				audioManager.stopBluetoothSco();
			}
		}
		
		return true;
	}
}
