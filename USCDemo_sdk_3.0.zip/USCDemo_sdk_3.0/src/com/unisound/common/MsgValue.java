package com.unisound.common;

public final class MsgValue {

	// 获取模型文件错误
	public static final int ERROR_GET_MODEL = -90001;
	// 加载模型文件错误
	public static final int ERROR_LOAD_MODEL = -90002;
	
	// 错误消息
	public static final int MESSAGE_ERROR = 25;

	// 初始化成功事件
	public final static int MESSAGE_INIT = 1;
	// 开始合成事件
	public final static int MESSAGE_SYNTHESIZE_BEGIN = 2;
	// 结束合成事件
	public final static int MESSAGE_SYNTHESIZE_END = 3;
	// 开始缓冲
	public static final int MESSAGE_BUFFER_BEGIN = 4;
	// 缓冲就绪
	public static final int MESSAGE_BUFFER_READY = 5;
	// 开始播放事件
	public final static int MESSAGE_PLAY_BEGIN = 6;
	// 结束播放事件
	public final static int MESSAGE_PLAY_END = 7;
	// 暂停播放事件
	public final static int MESSAGE_PAUSE = 8;
	// 恢复播放事件
	public final static int MESSAGE_RESUME = 9;
	// 取消事件
	public final static int MESSAGE_CANCEL = 10;
	// 停止事件
	public final static int MESSAGE_STOP = 11;
	// 释放事件（引擎、模型、用户字典）
	public final static int MESSAGE_RELEASE = 12;
	// 加载模型
	public final static int MESSAGE_MODEL_LOAD = 13;

}
