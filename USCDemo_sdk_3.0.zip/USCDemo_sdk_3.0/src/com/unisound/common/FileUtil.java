/**
 * Copyright (c) 2012-2012 Yunzhisheng(Shanghai) Co.Ltd. All right reserved.
 * @FileName : FileHelper.java
 * @ProjectName : iShuoShuo2
 * @PakageName : cn.yunzhisheng.ishuoshuo.util
 * @Author : Brant
 * @CreateDate : 2012-11-9
 */
package com.unisound.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.os.Environment;

public class FileUtil {

	public static boolean isSDCardExists() {
		return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
	}

	public static String getSDCardPath() {
		String path = Environment.getExternalStorageDirectory().getPath();
		if (path != null && !path.endsWith(File.separator)) {
			path += File.separator;
		}
		return path;
	}

	public static boolean copyFile(String source, String target, boolean append) {
		boolean result = true;

		File fileSource = new File(source);
		File fileTarget = new File(target);

		if (fileSource.isFile() && fileTarget.isFile()) {
			try {
				fileTarget.getParentFile().mkdirs();

				result = copyFile(new FileInputStream(fileSource), new FileOutputStream(fileTarget, false));
			} catch (FileNotFoundException e) {
				result = false;
				e.printStackTrace();
			} catch (Exception e) {
				result = false;
				e.printStackTrace();
			}
		} else {
			result = false;
		}

		return result;
	}

	public static boolean copyFile(InputStream source, OutputStream target) {
		boolean result = true;

		if (source != null && target != null) {
			byte[] buffer = new byte[1024];
			int byteSize = 0;

			try {
				while ((byteSize = source.read(buffer)) > 0) {
					target.write(buffer, 0, byteSize);
				}
			} catch (IOException e) {
				result = false;
				e.printStackTrace();
			} finally {
				try {
					target.close();
					source.close();
				} catch (IOException e) {
					result = false;
					e.printStackTrace();
				}
			}
		} else {
			result = false;
		}

		return result;
	}

	public static void mkdirs(String path) {
		if (path == null) {
			return;
		}
		int index = path.lastIndexOf('/');
		if (index >= 0) {
			File file = new File(path.substring(0, index));
			file.mkdirs();
		}
	}
}
