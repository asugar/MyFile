package com.unisound.common;

public interface RecordingListener {
	
	public void onUpdateVolume(int volume);
	public void onRecordingStart();
	public void onRecordingStop();	
}
