package com.unisound.common;

public class USCSpeakerInformation  {
	
	public enum Gender {
		MAN,
		FEMALE,
		/*信息不足不能判断*/
		UNKOWN,
	}
	
	private static final int SPEAKER_INFO_GENDER_MAN = 0x000001;
	private static final int SPEAKER_INFO_GENDER_FEMALE = 0x000002;
//	private static final int SPEAKER_INFO_GENDER_UNKOWN = 0x000000;
	int reqInfo = 0;
	int info = 0;
	
	public USCSpeakerInformation() {

	}
	
	public USCSpeakerInformation(int info, int reqInfo) {
		this.reqInfo = reqInfo;
		this.info = info;		
	}

	
	/**
	 * 启用获取性别信息
	 * @return
	 */
	public boolean isGenderEnabled() {
		
		if( (reqInfo & USCSpeakerInfoSetting.SPEAKER_INFO_GENDER) != 0) {
			return true;
		}
		
		return false;		
	}
	
	public void setSpeakerInfo(int info) {
		this.info = info;
	}
	
	public Gender getGender() {
		
		if( (info & SPEAKER_INFO_GENDER_MAN) != 0) {
			return Gender.MAN;
		}
		else if((info & SPEAKER_INFO_GENDER_FEMALE) != 0) {
			return Gender.FEMALE;
		}
		
		return Gender.UNKOWN;
	}
}
