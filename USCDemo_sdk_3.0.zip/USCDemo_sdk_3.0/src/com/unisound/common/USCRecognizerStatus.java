package com.unisound.common;
/**
 * 当前识别状态
 */
public enum USCRecognizerStatus {

	idle, 
	recording, 
	recognizing
}
