package com.unisound.common;

import java.net.InetAddress;
import java.net.UnknownHostException;

import com.unisound.common.LogUtil;

public class Addresser 
{
	private String server = "117.121.55.35";
	private int port = 80;
	private String ip = "";	
	private String defaultIP = "117.121.55.35"; 
	private int defaultPort = 80;
	private boolean isInitIP = false;
	private boolean isChanged = true;
	
	public Addresser(String server, int port, String ip, int defaultPort) {
		
		this.server = server;
		this.port = port;
		
		this.defaultPort = defaultPort;	
		this.defaultIP = ip; 
		isChanged = true;
	}
	
	public Addresser(Addresser address) {
		
		this.server = address. server;
		this.port = address.port;
		
		this.defaultIP = address.defaultIP; 
		this.defaultPort = address.defaultPort;	
		isChanged = true;
	}
	
	public void setAddresser(Addresser address) {
		
		this.server = address. server;
		this.port = address.port;
		
		this.defaultIP = address.defaultIP; 
		this.defaultPort = address.defaultPort;	
		
		isInitIP = false;
		isChanged = true;
	}

	public void setDefaultServer(String defaultServer) {
		this.defaultIP = defaultServer;
		isChanged = true;
	}

	public String getIP() {
		
		updateHostAddress();
		
		if(isInitIP) {
			return ip;
		}
		return defaultIP;
	}

	public void setDefaultPort(int defaultPort) {
		this.defaultPort = defaultPort;
		isChanged = true;
	}

	public String getServer() 
	{
		return server;
	}
	
	public void setServer(String server) 
	{
		this.server = server;
		isInitIP = false;
		isChanged = true;
	}
	
	public int getPort() 
	{
		return port;
	}
	
	public void setPort(int port) 
	{
		this.port = port;
	}

	public void setChanged(boolean changed) {
		isChanged = changed;
	}
	
	public boolean isChanged() {
		return isChanged;
	}
	
	/**
	 * 设置识别服务器地址
	 * 
	 * @param value
	 * @return
	 */
	public boolean setAddress(String address) {

			if (address == null) {
				return false;
			}

			String items[] = address.split(":");
			if (items.length != 2) {
				return false;
			}

			if (items[0].length() == 0) {
				return false;
			}

			try {
				port = (short) (int) Integer.valueOf(items[1]);
				server = items[0];
				defaultIP = items[0];
				defaultPort = port;
				isChanged = true;
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}

			return false;
	}
	
	 /**
	 * 域名解析
	 */
	private void updateHostAddress() {

		// LogUtil.v("updateHostAddress begin");
		if (isInitIP == false) {
			try {
				InetAddress addr = InetAddress.getByName(server);
				ip = addr.getHostAddress();
				isInitIP = true;
			} catch (UnknownHostException e) {
				LogUtil.e("InetAddress.getByName fail");
			}
		}

		// LogUtil.v("updateHostAddress end");
	}

	public void resetDNS() {
		isInitIP = false;
	}
}
