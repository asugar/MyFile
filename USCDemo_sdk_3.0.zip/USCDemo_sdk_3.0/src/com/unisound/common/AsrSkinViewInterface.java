package com.unisound.common;


/**
 * 皮肤界面事件监听，用于SDK 关联皮肤界面，二次封装类
 * 
 * @author zhangkj
 * 
 */

public abstract class AsrSkinViewInterface {

	private AsrSkinViewOperateInterface mAsrSkinViewOperateInterface = new AsrSkinViewOperateInterface();
	
	public interface AsrSkinViewOperateListener {
		void onSkinViewStart();
		void onSkinViewStop();
		void onSkinViewCancel();
	}
	
	/**
	 * 二次封装类
	 * @author zhangkj
	 *
	 */
	public class AsrSkinViewOperateInterface {
		AsrSkinViewOperateListener mListener = null;
		
		void setLinstener(AsrSkinViewOperateListener listener) {
			mListener = listener;
		}
		
		void onSkinViewStart() {
			AsrSkinViewOperateListener listener = mListener;
			if (listener != null) {
				listener.onSkinViewStart();
			}
		}
		void onSkinViewStop() {
			AsrSkinViewOperateListener listener = mListener;
			if (listener != null) {
				listener.onSkinViewStop();
			}
		}
		void onSkinViewCancel() {
			AsrSkinViewOperateListener listener = mListener;
			if (listener != null) {
				listener.onSkinViewCancel();
			}
		}
	}
	

	public void doStart() {
		mAsrSkinViewOperateInterface.onSkinViewStart();
	}
	
	public void doStop() {
		mAsrSkinViewOperateInterface.onSkinViewStop();
	}
	
	public void doCancel() {
		mAsrSkinViewOperateInterface.onSkinViewCancel();
	}
	
	
	public void setSkinViewOperateLinstener(AsrSkinViewOperateListener listener) {
		mAsrSkinViewOperateInterface.setLinstener(listener);
	}
	
	/**
	 * 录音超时
	 */
	public void onVADTimeout() {
		doStop();
	}
	
	/**
	 * 音量更新
	 * @param volume
	 */
	public abstract void onUpdateVolume(int volume);

	/**
	 * 启动识别
	 */
	public abstract void onStart();
	
	/**
	 * 识别结果状态回调
	 * @param result
	 * @param isLast
	 */
	public abstract void onResult(String result, boolean isLast);

	/**
	 * 识别停止回调
	 * @param error
	 */
	public abstract void onEnd(int error);

	/**
	 * 停止录音状态回调
	 */
	public abstract void onRecordingStop();

	/**
	 * 录音开始状态回调
	 */
	public abstract void onRecordingStart();

	/**
	 * 检测到说话开始状态回调
	 */
	public void onSpeechStart() {
		
	}

	/**
	 * 取消状态回调
	 */
	public abstract void onCancel();
	
}
