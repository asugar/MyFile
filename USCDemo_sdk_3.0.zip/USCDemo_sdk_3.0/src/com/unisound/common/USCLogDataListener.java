package com.unisound.common;

public interface USCLogDataListener {
	public void onLogData(int what,int type, Object object);
}
