package com.unisound.common;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import cn.yunzhisheng.asr.JniUscClient;

public class DeviceInfoUtil {

    // network type
    public static final int NETWORK_TYPE_NONE = 0;
    public static final int NETWORK_TYPE_WIFI = 1;
    public static final int NETWORK_TYPE_3G = 2;
    public static final int NETWORK_TYPE_2G = 3;
    public static final int NETWORK_TYPE_MOBILE = 4;
    
	private static final String INVALID_IMEI = "000000000000000";
	private static boolean isInit = false;
	public static String imei = "";
	public static String carrier = "";
	public static String packageName = "";
	public static String model = "";
	public static TelephonyManager telManager;
	public static NetworkInfo networkInfo;
	public static ConnectivityManager connectivityManager;
	
	public static void init(Context context) {

		if (isInit == false) {
			connectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			telManager = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
			if (connectivityManager != null) {
				networkInfo = connectivityManager
						.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
			}
			packageName = context.getPackageName();
			carrier = getCarrier(context);
			imei = getIMEI(context);
			model = Build.MODEL;
			isInit = true;
		}
	}

	public static String getModel() {
		return Build.MODEL;
	}

	public static String getIMEI(Context context) {
		String imei = "";

		imei = ((TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
		if (imei != null && !"".equals(imei) && !imei.equals(INVALID_IMEI)) {
			return imei;
		}

		imei = Secure
				.getString(context.getContentResolver(), Secure.ANDROID_ID);
		if (imei != null && !"".equals(imei) && !imei.equals(INVALID_IMEI)) {
			return imei;
		}

		WifiManager wifi = (WifiManager) context
				.getSystemService(Context.WIFI_SERVICE);
		WifiInfo info = wifi.getConnectionInfo();
		if (info != null) {
			return info.getMacAddress();
		}

		return "unknow android device";
	}

	public static String getCarrier(Context context) {
		TelephonyManager telManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		String netOperator = telManager.getNetworkOperator();
		if (netOperator != null && !"".equals(netOperator)) {
			return netOperator;
		} else {
			return "0";
		}
	}

	public static boolean checkNetwork(Context context) {
		ConnectivityManager con = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkinfo = con.getActiveNetworkInfo();
		if (networkinfo == null || !networkinfo.isAvailable()) {
			return false;
		}

		return true;
	}

	public static int getNetType() {
		
		NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		if (wifi != null && wifi.isAvailable() ) {
			return JniUscClient.NETWORK_TYPE_WIFI;
		}

		return getMobileType();
	}

	public static int getMobileType() {

		if (networkInfo != null && networkInfo.isAvailable()) {
			int type = telManager.getNetworkType();
			switch (type) {
			case TelephonyManager.NETWORK_TYPE_GPRS:
			case TelephonyManager.NETWORK_TYPE_EDGE:
			case TelephonyManager.NETWORK_TYPE_CDMA:
				return JniUscClient.NETWORK_TYPE_2G;

			case TelephonyManager.NETWORK_TYPE_UMTS:
			case TelephonyManager.NETWORK_TYPE_HSDPA:
			case TelephonyManager.NETWORK_TYPE_EVDO_0:
			case TelephonyManager.NETWORK_TYPE_EVDO_A:
				return JniUscClient.NETWORK_TYPE_3G;
			default:
				return JniUscClient.NETWORK_TYPE_MOBILE;
			}
		}

		return JniUscClient.NETWORK_TYPE_NONE;
	}

}
