/**
 * classes : com.example.cn.test.PlayTools
 * liujunjie Create  at 2014-1-8  下午1:46:03
 */
package com.unisound.common;

import java.io.File;
import java.io.FileInputStream;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;

public class USCMediaPlayer {
	
	private MediaPlayer mMediaPlayer;

	private Context      context;
	private OnCompletionListener  listener;
	private int resId;
    private  String  targetPath;

	public String getTargetPath() {
		return targetPath;
	}

	public void setTargetPath(String targetPath) {
		resId = 0;
		this.targetPath = targetPath;
	}

	public int getResId() {
		return resId;
	}

	public void setResId(int resId) {
		targetPath = null;
		this.resId = resId;
	}

	public USCMediaPlayer(Context context) {
		this.context = context;
	}

	public OnCompletionListener getListener() {
		return listener;
	}

	// 设置播放完毕监听
	public void setListener(OnCompletionListener listener) {
		this.listener = listener;
	}

	// 播放文件
	public void play() {
		stop();
		try {
			playerBuild();
			mMediaPlayer.setOnCompletionListener(getListener());
			mMediaPlayer.start();
			mMediaPlayer.setLooping(false);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 停止播放
	public void stop() {

		if (mMediaPlayer != null) {
			mMediaPlayer.stop();
			mMediaPlayer.release();
			mMediaPlayer = null;
		}
	}

	// 是否正在播放
	public boolean isPlaying() {
		if (mMediaPlayer != null) {
			return mMediaPlayer.isPlaying();
		}
		return false;
	}

	private void playerBuild() throws Exception {
		if ( targetPath != null) {
			mMediaPlayer = new MediaPlayer();
			mMediaPlayer.setDataSource(new FileInputStream(new File(targetPath)).getFD());
			mMediaPlayer.prepare();
		} else if (getResId() != 0) {
			mMediaPlayer = MediaPlayer.create(context, getResId());
		}
	}

}
