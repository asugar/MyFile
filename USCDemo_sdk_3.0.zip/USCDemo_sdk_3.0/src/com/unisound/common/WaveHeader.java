package com.unisound.common;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class WaveHeader {
	private static char fileID[] = { 'R', 'I', 'F', 'F' };
	private static char wavTag[] = { 'W', 'A', 'V', 'E' };
	private static char fmtHdrID[] = { 'f', 'm', 't', ' ' };
	private static int fmtHdrLeth = 16;
	private static short formatTag = 1;
	public short channels = 1;
	public short sampleRate = 16000;
	public static short bitsPerSample = 16;
	private static char dataHdrID[] = { 'd', 'a', 't', 'a' };
	/**
	 * @return byte[] 44个字节
	 * @throws IOException
	 */
	public static byte[] getHeader(int fileLength, int channels,
			int sampleRate) {
		
		byte[] ret = null;
		
		try {
			short blockAlign = (short) (channels * bitsPerSample / 8);
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			WriteChar(bos, fileID);

			WriteInt(bos, fileLength + (44 - 8));

			WriteChar(bos, wavTag);
			WriteChar(bos, fmtHdrID);
			WriteInt(bos, fmtHdrLeth);
			WriteShort(bos, formatTag);
			WriteShort(bos, (short)channels);
			WriteInt(bos, sampleRate);
			WriteInt(bos, blockAlign * sampleRate);
			WriteShort(bos, blockAlign);
			WriteShort(bos, bitsPerSample);
			WriteChar(bos, dataHdrID);
			WriteInt(bos, fileLength);
			bos.flush();
			ret = bos.toByteArray();
			bos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ret;
	}

//	/**
//	 * @return byte[] 44个字节
//	 * @throws IOException
//	 */
//	public byte[] getHeader() throws IOException {
//		ByteArrayOutputStream bos = new ByteArrayOutputStream();
//		WriteChar(bos, fileID);
//		WriteInt(bos, fileLength);
//		WriteChar(bos, wavTag);
//		WriteChar(bos, fmtHdrID);
//		WriteInt(bos, fmtHdrLeth);
//		WriteShort(bos, formatTag);
//		WriteShort(bos, channels);
//		WriteInt(bos, sampleRate);
//		WriteInt(bos, avgBytesPerSec);
//		WriteShort(bos, blockAlign);
//		WriteShort(bos, bitsPerSample);
//		WriteChar(bos, dataHdrID);
//		WriteInt(bos, dataHdrLeth);
//		bos.flush();
//		byte[] r = bos.toByteArray();
//		bos.close();
//		return r;
//	}

	private static void WriteShort(ByteArrayOutputStream bos, short s)
			throws IOException {
		byte[] mybyte = new byte[2];
		mybyte[1] = (byte) (s>> 8);
		mybyte[0] = (byte) ((s << 8) >> 8);
		bos.write(mybyte);
	}

	private static void WriteInt(ByteArrayOutputStream bos, int n)
			throws IOException {
		byte[] buf = new byte[4];
		buf[3] = (byte) (n >> 24);
		buf[2] = (byte) ((n << 8) >> 24);
		buf[1] = (byte) ((n << 16) >> 24);
		buf[0] = (byte) ((n << 24) >> 24);
		bos.write(buf);
	}

	private static void WriteChar(ByteArrayOutputStream bos, char[] id) {
		for (int i = 0; i < id.length; i++) {
			char c = id[i];
			bos.write(c);
		}
	}
}