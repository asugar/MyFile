package com.unisound.common;

import android.os.Handler;
import android.os.Message;

/**
 * Handler 回调封装
 * 
 * @author zhangkaijun@yunzhisheng.cn
 * 
 */
public class MainMessageHandler extends Handler {

	public interface HandlerMessageListener {
		public void onHandleMessage(Message msg);
	}

	private HandlerMessageListener listener;

	public MainMessageHandler(HandlerMessageListener listener) {
		super();
		this.listener = listener;
	}

	public void setListener(HandlerMessageListener listener) {
		this.listener = listener;
	}

	@Override
	public void handleMessage(Message msg) {
		HandlerMessageListener ls = listener;
		if (ls != null) {
			ls.onHandleMessage(msg);
		}
	}


	public void sendMessage(int what, Object obj) {

		obtainMessage(what, obj).sendToTarget();
	}

	public void sendMessage(int what) {
		sendEmptyMessage(what);
	}
}
