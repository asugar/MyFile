package com.unisound.common;

import java.io.File;

import android.content.Context;

public class BeepPlayer {

	private static String 	START_BEEP_FILE = "asr_start_beep.mp3";
//	private static String 	TO_SLEEP_BEEP_FILE = "to_sleep.ogg";
	
	private static String 	WAKE_UP_BEEP_MD5 = "wake_up_success.wav";
//	private static String 	TO_SLEEP_BEEP_MD5 = "to_sleep.ogg";


	
	private USCMediaPlayer player;
	private String startBeep;
	private String toSleepBeep;
	
	public BeepPlayer() {
		
	}
	
	private boolean playBeep( String file) {
		
		if(file == null) {
			return false;
		}
		
		player.setTargetPath(file);
		player.play();
		
		return true;
	}
	
	public void init(Context context) {
		player = new USCMediaPlayer(context);
		String path = context.getFilesDir().toString() + File.separator;		
		startBeep = path + START_BEEP_FILE;
//		toSleepBeep = path + TO_SLEEP_BEEP_FILE;
		DataStroe.saveVoiceToDataDir(context,  "usc" + File.separatorChar + START_BEEP_FILE, startBeep, WAKE_UP_BEEP_MD5);
//		DataStroe.saveVoiceToDataDir(context,  "usc" + File.separatorChar + TO_SLEEP_BEEP_FILE, toSleepBeep, TO_SLEEP_BEEP_MD5);
	}
	
	public boolean playAsrStartBeep() {
		
		return playBeep(startBeep);
	}
	
	public boolean playSleepBeep() {
		
		return playBeep(toSleepBeep);
	}	
}
