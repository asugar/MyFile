package com.unisound.common;

import android.text.TextUtils;
import com.unisound.sdk.MixErrorCode;

public class WakeUpErrorCode extends MixErrorCode{


	public static final int WAKEUP_COMMAND_LIST_EMPTY  = -63601;
	public static final int WAKEUP_ERROR_MAX_CODE  = -63700;

	@Override
	public String toMessage(int code) {
		
		String msg = super.toMessage(code);
		if(!TextUtils.isEmpty(msg)){
			return msg;
		}
		
		if(code <= WAKEUP_COMMAND_LIST_EMPTY && code < WAKEUP_ERROR_MAX_CODE) {
			return "语音唤醒加载错误";
		}
		
		return "";
	}
	
}
