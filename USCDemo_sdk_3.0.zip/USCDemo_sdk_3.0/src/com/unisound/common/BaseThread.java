package com.unisound.common;

/**
 * @author USC 线程基类
 */
public class BaseThread extends Thread {

	protected int mOSPriority = android.os.Process.THREAD_PRIORITY_DEFAULT;

	public BaseThread() {
		setOSPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
		setPriority(Thread.MIN_PRIORITY); 
	}
	
	
	public void setOSPriority(int p) {  
		mOSPriority = p;  
	}  
	
	@Override
	public void run() {
		android.os.Process.setThreadPriority(mOSPriority);
	}
}
