package com.unisound.common;

public class SdkVersion {
	
	public static final String version = "1.3.60";

	public static String getVersion() {
		return version;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.print(version);		  
	}
}
