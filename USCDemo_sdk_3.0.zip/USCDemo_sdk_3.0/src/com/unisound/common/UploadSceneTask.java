package com.unisound.common;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import org.json.JSONObject;

import com.unisound.client.ErrorCode;
import com.unisound.common.SceneManage.UploadSceneDataListener;

/**
 * <NAME><APP><SONG>
 */

public class UploadSceneTask extends Thread {

	public String userDataServer = "";
	private UploadSceneDataListener mListener;
	private String mUploadData;
	private Scene mScene = null;
	private ErrorCode errorCode = new ErrorCode();
	public Scene getScene() {
		return mScene;
	}

	public void setServer(String server){
		this.userDataServer = server;
	}

	void setListener(UploadSceneDataListener listener) {
		this.mListener = listener;
	}
	
	private void uploadDataEnd(int code) {
		UploadSceneDataListener ls = mListener;
		if (ls != null) {
			ls.onUploadSceneDataEnd(this, errorCode.createProfessionError(code));
		}
	}

	protected void log_e(String error) {
		LogUtil.e("UploadSceneTask:" + error);
	}

	void postData(String serviceKey, Scene scene, List<String> list) {
		mScene = scene;
		mScene.setEnabled(false);
		userDataServer += "?ak=" + serviceKey + "&imei="
				+ DeviceInfoUtil.imei +"&an=wechar" +"&si=" + scene.getSceneId()+"&av=1.0"+"&sn=abcdefg"+"&trace=1";

		StringBuilder sb = new StringBuilder();
		sb.append("data=<SCENE>\n");
		for (String data : list) {
			sb.append(data).append("\n");
		}
		sb.append("</SCENE>");
		postData(sb.toString());
	}

	private void postData(String data) {
		mUploadData = data;
		start();
	}

	public void canel() {
		mListener = null;
	}
	
	@Override
	public void run() {
		int error = ErrorCode.RECOGNIZER_OK;
		try {

//			String  temp = "<SCENE>\n 123\n</SCENE>";
		//	byte[] imeiByte = DeviceInfoUtil.imei.getBytes();
			byte[] sourceByte = mUploadData.getBytes();
		//	byte[] encodeByte = new byte[imeiByte.length + sourceByte.length+ 10];

//			if (0 != encode
//					.EncodeTotalContent(imeiByte, sourceByte, encodeByte)) {
//				error = ErrorCode.UPLOAD_SCENE_ENCODE_ERROR;
//			} else {

				URL url = new URL(userDataServer );
				HttpURLConnection conn = (HttpURLConnection) url
						.openConnection();
//				conn.setRequestProperty("Content-Type", "text/plain"); 
				conn.setRequestMethod("POST");
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setConnectTimeout(30 * 1000);

				OutputStream out = conn.getOutputStream();
				out.write(sourceByte);
				out.flush();
				out.close();
                int resultCode = conn.getResponseCode();
				if (resultCode == 200) {
					InputStreamReader reader = new InputStreamReader(
							conn.getInputStream());
					BufferedReader bufferReader = new BufferedReader(reader);
					String  response = bufferReader.readLine();
//					int code = Integer.parseInt(codeStr);
//					Gson  gson = new Gson();
//					RtcTracerVO tracerVO = gson.fromJson( response, new TypeToken< RtcTracerVO >() { }.getType() ); 
//					String codeStr = tracerVO.getErrorCode();
					JSONObject  json = new JSONObject(response);
					String codeStr = json.has("errorCode") ? json.getString("errorCode") : "";
					int code = Integer.parseInt(codeStr);
					LogUtil.d("upload userdata code=" + code);
					if (code == 0) {
						mScene.setEnabled(true);
						error = ErrorCode.RECOGNIZER_OK;
					}else if(code == -1){
						error = ErrorCode.UPLOAD_SCENE_GENERAL_ERROR;
					}else if(code == -5){
						error = ErrorCode.UPLOAD_SCENE_INVALID_KEY;
					}  else if(code == -8){
						error = ErrorCode.UPLOAD_SCENE_STREAM_IO_ERR;
					}else if(code ==-11){
						error = ErrorCode.UPLOAD_SCENE_UNKNOWN_ERR;
					}else if(code ==-12){
						error = ErrorCode.UPLOAD_SCENE_DATA_SIZE_IS_FORBIDDEN;
					}else if(code ==-13){
						error = ErrorCode.UPLOAD_SCENE_INVALID_VER;
				    }else if (code == -6) {
						error = ErrorCode.UPLOAD_SCENE_DATA_TOO_FAST;
					}else {
						error = ErrorCode.UPLOAD_SCENE_DATA_SERVER_REFUSED;
					} 
				}else {
					error = ErrorCode.UPLOAD_SCENE_DATA_NETWORK_ERROR;
			}
		} catch (Exception e) {
			e.printStackTrace();
			error = ErrorCode.UPLOAD_SCENE_DATA_NETWORK_ERROR;
		}
		uploadDataEnd(error);
	}
}
