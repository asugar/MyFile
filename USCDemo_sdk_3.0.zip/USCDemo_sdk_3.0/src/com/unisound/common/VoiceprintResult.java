package com.unisound.common;

import org.json.JSONException;
import org.json.JSONObject;
import android.text.TextUtils;


public class VoiceprintResult {

	private String  jsonRes;
	private  int  status = 0;
	private String userName = "";
	private float score = 0;

	public VoiceprintResult(String result) {
		this.jsonRes = result;
		stringFormat(result);
	}
	
	public String getString(){
		return jsonRes;
	}
	
	public int getStatus(){
		return status;
	}
 
	public float getScore(){
		return score;
	}
	
	public String getUserName(){
		return userName;
	}
	
	private boolean stringFormat(String result) {
		if (TextUtils.isEmpty(result)) {
			return false;
		}
		LogUtil.d(result);
		String res = removeExcessJson(result);
		try {
			JSONObject json = new JSONObject(res);
			if (json != null) {
				status = (Integer) (json.has("status") ? json.getInt("status") : 0);
				userName = json.has("username") ? json.getString("username") : "";
				score =  Float.valueOf((json.has("score") ? json.getString("score"):"0"));
			}
			return true;
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	private String removeExcessJson(String res) {
		if (res.contains("}{")) {
			int index = res.indexOf("}");
			String jsonStr = res.substring(index + 1);
			LogUtil.e("jsonStr: " + jsonStr);
			return jsonStr;
		}
		return res;
	}
	
	
}
