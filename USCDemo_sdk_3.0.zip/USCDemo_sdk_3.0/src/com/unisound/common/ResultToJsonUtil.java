package com.unisound.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.util.Log;

public class ResultToJsonUtil {
	private static boolean DEBUG = true;
	private static final String TAG = "ResultToJsonUtil";

	/**
	 * @param inputStream //xml相关的输入流
	 * @param score //返回结果的得分
	 * @return
	 * @throws Exception
	 */
	public static JSONObject getJsonResult(InputStream inputStream,float score)
			throws Exception {
		JSONObject json = new JSONObject();
		JSONArray jsoncmdArray = new JSONArray();
		JSONArray jsonChoiseArray = new JSONArray();

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		// 解析一个XML文件，得到Document对象(根节点)
		Document document = builder.parse(inputStream);
		NodeList sNodes = document.getChildNodes();
		Element childElement = (Element) sNodes.item(0);
		NodeList childNodes = childElement.getChildNodes();
		for (int j = 0; j < childNodes.getLength(); j++) {

			if (childNodes.item(j).getNodeType() == Node.ELEMENT_NODE) {
				//统一Tag的加载
				String tagName = childNodes.item(j).getNodeName();
				String tagValue = childNodes
						.item(j).getFirstChild().getNodeValue();
				JSONObject tagsOfJson = new JSONObject();
				JSONArray tagItemsArray = new JSONArray();
				setJSONArrayData(tagsOfJson, jsoncmdArray,
						tagItemsArray, 0, tagName, tagValue);
			}

		}
		json.put("l", jsoncmdArray);
		json.put("score", score);
		jsonChoiseArray.put(json);
		return new JSONObject().put("c", jsonChoiseArray);
	}

	/**
	 * 同行者自定义json格式
	 * @param json
	 * @param jsoncmdArray
	 * @param jsonItemArray
	 * @param s
	 * @param t
	 * @param w
	 */
	private static void setJSONArrayData(JSONObject json,
			JSONArray jsoncmdArray, JSONArray jsonItemArray, float s, String t,
			String w) {
		try {
			json.put("s", s);
			json.put("t", t);
			json.put("w", w);
			jsonItemArray.put(json);
			jsoncmdArray.put(new JSONObject().put("c", jsonItemArray));
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param str //利用Dom解析将字符串转为json
	 * @param score //当前结果的得分
	 * @return
	 * @throws Exception
	 */
	public static JSONObject getResultJsonUseDomParser(String result,float score,String xmlpath)
			throws Exception {
		

		WriteStringToFile(xmlpath, result);

		JSONObject json = new JSONObject();
		JSONArray jsoncmdArray = new JSONArray();
		JSONArray jsonChoiseArray = new JSONArray();

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		// 解析一个XML文件，得到Document对象(根节点)
		Document document = builder.parse(new File(xmlpath));
		NodeList sNodes = document.getChildNodes();
		if (DEBUG)
		Log.d(TAG, "FileUtiles -Node.length =" + sNodes.getLength()
				+ ", node:value =" + sNodes.item(0).getNodeName());

		Element childElement = (Element) sNodes.item(0);
		NodeList childNodes = childElement.getChildNodes();
		if (DEBUG)
		Log.d(TAG,
				"FileUtiles -childElement =" + childElement.getNodeValue());
		for (int j = 0; j < childNodes.getLength(); j++) {

			if (childNodes.item(j).getNodeType() == Node.ELEMENT_NODE) {
				
				//根据Tag加载生成相应的json数据
				String tagName = childNodes.item(j).getNodeName().replace("_", "");
				String tagValue = childNodes
						.item(j).getFirstChild().getNodeValue();
				JSONObject tagsOfJson = new JSONObject();
				JSONArray tagItemsArray = new JSONArray();
				setJSONArrayData(tagsOfJson, jsoncmdArray,
						tagItemsArray, 0, tagName, tagValue);
			}

		}

		json.put("l", jsoncmdArray);
		json.put("score", score);
		jsonChoiseArray.put(json);
		return new JSONObject().put("c", jsonChoiseArray);
	}

	/**
	 * 将返回的语音结果生成xml文件
	 * @param filePath
	 * @param result
	 */
	public static void WriteStringToFile(String filePath, String result) {
		try {
			// 根据String生成一个xml文件
			String temp = result.replace("[", "").replace("]", "").trim();
			String xmlText = "<?xml version='1.0' encoding='utf-8'?>" + temp;
			if (DEBUG)
			Log.d(TAG, "xmlText = " + xmlText);
			
			//根据路径创建相关路径的xml文件
			File file = new File(filePath);
			createFile(file);
			
			FileWriter fw = new FileWriter(filePath, true);
			fw.write(xmlText);
			fw.flush();
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static boolean createFile(File file) throws IOException {
		if (!file.exists()) {
			makeDir(file.getParentFile());
		}
		//未避免重复添加內容到文件，每次创建时先删除先前的文件
		file.delete();
		return file.createNewFile();
	}

	private static void makeDir(File dir) {
		if (!dir.getParentFile().exists()) {
			makeDir(dir.getParentFile());
		}
		dir.mkdir();
	}
	
	public static JSONObject getResultJsonUsePullParser(String result,float score,String xmlpath)
			throws Exception {
		if (DEBUG)
		Log.d("ResultTOJsonUtil", "result before format : " + result);
		String origResult = result.replace("[", "").replace("]", "").trim();
		WriteStringToFile(xmlpath, result);
		
		JSONObject json = new JSONObject();
		JSONArray jsoncmdArray = new JSONArray();
		JSONArray jsonChoiseArray = new JSONArray();

		// 创建一个xml解析的工厂
		XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
		// 获得xml解析类的引用
		XmlPullParser parser = factory.newPullParser();
		parser.setInput(new FileInputStream(new File(xmlpath)), "utf-8");
		// 获得事件的类型
		int eventType = parser.getEventType();
		while (eventType != XmlPullParser.END_DOCUMENT) {
			switch (eventType) {
			case XmlPullParser.START_DOCUMENT:
				if (DEBUG)
				Log.d("ResultTOJsonUtil", "START_DOCUMENT : " + parser.getName());
				break;
			case XmlPullParser.START_TAG:
				if (DEBUG)
				Log.d("ResultTOJsonUtil", "START_TAG : " + parser.getName());
				String start_tag = parser.getName();
				// 统一Tag的加载
				if (!"s".equals(parser.getName())) {
					String tagValue = "";
					String tagName = parser.getName();
					try {
						tagValue = parser.nextText();
					} catch (Exception e) {
						Log.w("ResultTOJsonUtil", start_tag
								+ "的nextText不存在或其TAG没有正常结束 ********");
						e.printStackTrace();
						String missedTagvalue = origResult.substring(origResult
								.lastIndexOf(">") + 1);
						Log.w("ResultTOJsonUtil", "MissedTagValue =" + missedTagvalue);
						if (!"".equals(missedTagvalue)) {
							if (missedTagvalue.contains("<")) {
								tagValue = missedTagvalue.substring(0,missedTagvalue.indexOf("<"));
							} else {
								tagValue = missedTagvalue;
							}
						}
					}
					if (!"".endsWith(tagValue)) {
						if (DEBUG)
						Log.d("ResultTOJsonUtil", "START_TAG : tagName =" + tagName
								+ ", tagValue =" + tagValue);
						JSONObject tagsOfJson = new JSONObject();
						JSONArray tagItemsArray = new JSONArray();
						setJSONArrayData(tagsOfJson, jsoncmdArray,
								tagItemsArray, 0, tagName, tagValue);
					}
				}
				break;
			case XmlPullParser.END_TAG:
				if (DEBUG)
				Log.d("ResultTOJsonUtil", "END_TAG : " + parser.getName());
				break;
			}
			try {
				eventType = parser.next();
			} catch (Exception e) {
				e.printStackTrace();
				Log.w("ResultTOJsonUtil", "TAG 名称不全 ****************");
			}
		}

		json.put("l", jsoncmdArray);
		json.put("score", score);
		jsonChoiseArray.put(json);
		return new JSONObject().put("c", jsonChoiseArray);
	}
}
