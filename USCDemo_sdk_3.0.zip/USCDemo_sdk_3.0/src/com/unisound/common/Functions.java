package com.unisound.common;

public class Functions {

	public static int strToInt(String optionValue) {

		try {
			return Integer.valueOf(optionValue);
		}
		catch (Exception e) {
		}
		return 0;
	}

}
