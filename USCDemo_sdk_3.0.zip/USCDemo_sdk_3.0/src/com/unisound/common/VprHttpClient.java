package com.unisound.common;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.util.Log;

public class VprHttpClient {

	public static boolean getVPRAudio(String urlString, String filePath) {
		HttpURLConnection conn = null;
		InputStream in = null;
		FileOutputStream outStream = null;
		try {
			File vpraudioFile = createAudioFile(filePath);
			URL url = new URL(urlString);
			conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(30 * 1000);
			conn.setRequestMethod("GET");
			conn.connect();
			if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
				in = conn.getInputStream();
				byte[] data = readInputStream(in);
				outStream = new FileOutputStream(vpraudioFile);
				outStream.write(data);
				outStream.flush();
			}
		} catch (Exception e) {
			Log.d("VprHttpClient : ", "getVPRAudio wrong!");
			e.printStackTrace();
			return false;
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
			try {
				if (outStream != null) {
					outStream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return true;
	}
		
	   public static byte[] readInputStream(InputStream inStream) throws Exception{  
	        ByteArrayOutputStream outStream = new ByteArrayOutputStream();  
	        byte[] buffer = new byte[1024];  
	        int len = 0;  
	        while( (len=inStream.read(buffer)) != -1 ){  
	            outStream.write(buffer, 0, len);  
	        }  
	        inStream.close();
	        return outStream.toByteArray();  
	    }

	private static File createAudioFile(String filename) {
		File vpraudioFile = new File(filename);
		if (!vpraudioFile.getParentFile().exists()) {
			if (!vpraudioFile.getParentFile().mkdirs()) {
				Log.d("VprHttpClient : ", "create filedir failure!");
			}
		}
		try {
			vpraudioFile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
		return vpraudioFile;
	}
}
