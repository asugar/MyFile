/*
 * Copyright (C) 2012 The CyanogenMod Project
 * * Licensed under the GNU GPLv2 license
 * The text of the license can be found in the LICENSE file
 * or at https://www.gnu.org/licenses/gpl-2.0.txt
 */

package com.unisound.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import android.text.TextUtils;

public class MD5 {
	private static final String TAG = "MD5";

	public static boolean checkMD5(String md5, File file) {
		if (TextUtils.isEmpty(md5) || file == null) {
			LogUtil.e(TAG + " String NULL or File NULL");
			return false;
		}

		String calculatedDigest = calculateMD5(file);
		if (calculatedDigest == null) {
			LogUtil.e(TAG + " calculatedDigest NULL");
			return false;
		}

		LogUtil.i(TAG + "Calculated digest: " + calculatedDigest);
		LogUtil.i(TAG + "Provided digest: " + md5);
		return calculatedDigest.equalsIgnoreCase(md5);
	}

	public static String calculateMD5(File file) {
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			LogUtil.e(TAG + "Exception while getting Digest", e);
			e.printStackTrace();
			return null;
		}

		InputStream is;
		try {
			is = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			LogUtil.e(TAG + "Exception while getting FileInputStream", e);
			e.printStackTrace();
			return null;
		}

		byte[] buffer = new byte[8192];
		// tts使用的buffer
//		byte[] buffer = new byte[8192*4];
		int read;
		try {
			while ((read = is.read(buffer)) > 0) {
				digest.update(buffer, 0, read);
			}
			byte[] md5sum = digest.digest();
			BigInteger bigInt = new BigInteger(1, md5sum);
			String output = bigInt.toString(16);
			// Fill to 32 chars
			output = String.format("%32s", output).replace(' ', '0');
			return output;
		} catch (IOException e) {
			throw new RuntimeException("Unable to process file for MD5", e);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
				LogUtil.e(TAG + "Exception on closing MD5 input stream", e);
			}
		}
	}

}