package com.unisound.common;

import com.unisound.sdk.USCError;

public class ErrorCode {

	public static final int OK = 0;
	
	public static final int ERROR_GET_MODEL = -90001;
	public static final int ERROR_LOAD_MODEL = -90002;


	public static String toMessage(int code) {

		switch (code) {
		case ERROR_GET_MODEL:						return "模型生成失败！";
		case ERROR_LOAD_MODEL:						return "模型加载失败！";		
		}

	
		return null;
	}
	
	public static USCError toError(int code ) {
		return new USCError(code, getMessage(code));
	}
	
	public static String getMessage(int code) {

		String msg = toMessage(code);
		if(msg != null) {
			return msg;
		}
		return "错误:" + code;
	}	
}
