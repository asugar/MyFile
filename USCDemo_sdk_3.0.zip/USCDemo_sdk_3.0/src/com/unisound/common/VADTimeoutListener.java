package com.unisound.common;

public interface VADTimeoutListener {
	
	public void onVADTimeout();
}
