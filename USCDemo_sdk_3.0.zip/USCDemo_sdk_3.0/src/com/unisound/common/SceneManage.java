package com.unisound.common;

import java.util.ArrayList;
import java.util.List;
import com.unisound.client.ErrorCode;
import com.unisound.sdk.RecognizerParams;
import android.text.TextUtils;

public class SceneManage {
	
	/**
	 * 全语音场景ID -1为不使用。
	 */
	private static int SCENE_MAX_COUNT = 6;
	
	public static String userDataServer = "http://10.30.2.13:8089/data-process-service/rtc";
	
    private List<Scene> mItems = new ArrayList<Scene>();
//    private UploadSceneDataListener mListener;
    private RecognizerParams mParams;
    
	/**
	 * 
	 * @param name
	 * @return
	 */
	public Scene findScene(String name) {
	
		if( TextUtils.isEmpty(name)) {
			return null;
		}
		
		for(Scene scene :mItems) {
			if(scene.getSceneName().equals(name)) {
				return scene;
			}
		}
		return null;	
	}
	
	public void setParams( RecognizerParams params) {
		mParams = params;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getSceneCount() {
		return mItems.size();
	}
	
	public Scene getItemByIndex(int i) {
		
		if(mItems.size() > i && i > -1) {
			return mItems.get(i);
		}
		
		return null;
	}
	
	public void setSceneServer(String server, int port){
		userDataServer = "http://" + server + ":" + port +"/data-process-service/rtc";
	}
	
	public UploadSceneTask uploadSceneData( String name, List<String> words,UploadSceneDataListener listener) {
		
		UploadSceneTask task = new UploadSceneTask();
		task.setServer(userDataServer);
		Scene scene = findScene(name);
		ErrorCode errorCode = new ErrorCode();
		if(scene == null) {
			if( getSceneCount() >= SCENE_MAX_COUNT) {
				listener.onUploadSceneDataEnd(task, errorCode.createProfessionError(ErrorCode.UPLOAD_SCENE_OUT_MAX_COUNT));
				return task;
			}
			scene = createScene(name);
			if( scene  == null) {
				listener.onUploadSceneDataEnd(task, errorCode.createProfessionError(ErrorCode.UPLOAD_SCENE_OUT_MAX_COUNT));
				return task;
			}
		}
				
		task.postData(mParams.getAppKey(), scene, words);
		task.setListener(listener);
		
		return task;
	}

	private Scene findSceneById(int id) {
		
		if(id == Scene.SCENE_DISABLED) {
			return null;
		}
		
		for(Scene scene :mItems) {
			if(scene.getSceneId() == id) {
				return scene;
			}
		}
		
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	private int getNewSceneId() {
		
		int newId = Scene.SCENE_DISABLED;
		for( int i = 1; i < SCENE_MAX_COUNT;i ++) {
			Scene scene = findSceneById(i);
			if(scene == null) {
				newId = i;
				break;
			}
		}
		
		return newId;
	}
	
	public void remove(Scene scene) {
		
		for(Scene item :mItems) {
			if(item == scene) {
				mItems.remove(scene);
			}
		}
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	private Scene createScene(String name) {
		
		if( TextUtils.isEmpty(name)) {
			return null;
		}		
		
		Scene scene = findScene(name);
		if(scene !=null) {
			return scene;
		}
		
		int newId = getNewSceneId();
		if(newId == Scene.SCENE_DISABLED) {
			return null;
		}
		
		scene = new Scene(newId,name);
		mItems.add(scene);
		
		
		return scene;		
	}

	/**
	 * @param sceneHomeName
	 */
	public void removeByName(String name) {
		Scene scene = findScene(name);
		if(scene !=null) {
			remove(scene);
		}		
	}
	public interface UploadSceneDataListener {
		
		public void onUploadSceneDataEnd( UploadSceneTask sender, com.unisound.sdk.USCError  uscError);
	}

}
