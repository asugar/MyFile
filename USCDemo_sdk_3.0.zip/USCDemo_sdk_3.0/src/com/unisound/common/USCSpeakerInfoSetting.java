package com.unisound.common;

public class USCSpeakerInfoSetting  {

	static final int SPEAKER_INFO_GENDER = 0x000001;
	int reqInfo = 0;
	
	public USCSpeakerInfoSetting() {

	}
	
	public int getReqInfo() {
		return reqInfo;
	}
	
	public void setGenderEnabled(boolean enabled) {
		
		if(enabled) {
			reqInfo = reqInfo | SPEAKER_INFO_GENDER;
		}
		else {
			reqInfo = reqInfo & (~SPEAKER_INFO_GENDER);
		}		
	}
	
	/**
	 * 启用获取性别信息
	 * @return
	 */
	public boolean isGenderEnabled() {
		
		if( (reqInfo & SPEAKER_INFO_GENDER) != 0) {
			return true;
		}
		
		return false;		
	}	
}
