package com.unisound.tmp;

public class Scene {
	
	/**
	 * 全语音场景ID -1为不使用。
	 */
	public static final int SCENE_DISABLED = -1;
	private boolean mIsEnabled = false; 
	int mSceneId = SCENE_DISABLED;
	String mSceneName = ""; 
	
	public Scene( int sceneId, String name){
		mSceneId = sceneId;
		mSceneName = name;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isEnabled() {
		return mIsEnabled;
	}
	
	public String getSceneName() {
		return mSceneName ;
	}
	
	/**
	 * 
	 * @param sceneName
	 */
	void setSceneName(String sceneName) {
		mSceneName = sceneName;
	}

	public int getSceneId() {
		return mSceneId;
	}

	public void setScene(Scene scene) {
		this.mSceneId = scene.mSceneId;
		this.mSceneName = scene.mSceneName;
		this.mIsEnabled = scene.mIsEnabled;
	}

	public void setEnabled(boolean enabled) {
		mIsEnabled = enabled;
	}



}
