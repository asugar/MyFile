package com.unisound.tmp;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <pre>
 * 请求参数对象
 * 向语义云平台发送语义理解请求所需的参数封装在这个对象中。
 * 	固定值参数：url, method, ver 	开发者无需设置或更改（SDK版本升级会修改这些固定值参数）。
 * 	必填参数：appkey, secret, text
 * 	选填参数：appver, udid, gps, city, time, history
 * 选填参数在某些语义理解场景下需要填写。如查询天气时，可能需要填city或gps; 
 * 需要上下文理解时(如对话)需要填写history和udid;
 * 需要使用客户端时间时，如设置提醒，填写time
 * </pre>
 */
public class NluRequestPo {
	
	public static final String FILTER_NAME = "filterName";
	public static final String RETURN_TYPE = "returnType";
	public static final String CITY = "city";
	public static final String GPS = "gps";
	public static final String TIME = "time";
	public static final String SCENARIO  = "scenario";
	public static final String SCREEN = "screen";
	public static final String DPI = "dpi";
	public static final String HISTORY = "history";
	public static final String UDID = "udid";
	
	// 语义云服务访问域名（请勿更改）
	public static String url = "http://scv2.hivoice.cn/service/iss";
	// 方法的默认参数名（请勿更改）
	private final String method = "iss.getTalk";
	// 语义云服务协议版本号(一般情况下不需要更改)
	private final String ver = "2.0";

	// 语义云平台创建的应用的appKey;
	private String appkey = "";
	// 语义云平台创建的应用的appSecret, 仅用于签名;
	private String secret = "";
	// 您自己的应用的版本号
	private String appver = "";

	// 您的终端用户的唯一标识，可以是手机的IMEI，设备序列号，微信ID等（用于唯一标识用户，在对话场景下是必需的）
	private String udid = "";
	// GPS数据
	private String gps = "";
	// 城市
	private String city = "";
	// 时间，格式：yyyy-MM-dd HH:mm:ss
	private String time = getCurrentTime();

	// 待解析文字
	private String text = "";
	// 上一次访问语义云平台返回的history信息
	private String history = "";
	// 语音日志ID
	private String voiceid = "";
	// 场景
	private String scenario = "";
	// 屏幕大小
	private String screen = "";
	// 屏幕分辨率
	private String dpi = "";
	//平台
	private String platform = "";
	//用户终端当前视图ID
	private String viewid = "";
	

	/**
	 * 构造方法，默认将time设置为当前时间。
	 * 
	 * @param appkey
	 *            语义云平台上申请的应用的Appkey
	 * @param secret
	 *            语义云平台上申请的应用生成的secret
	 */
	public NluRequestPo(String appkey, String secret) {
		this.appkey = appkey;
		this.secret = secret;
	}

	public static String getCurrentTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = sdf.format(new Date());
		sdf = null;
		return time;
	}
	
	/**
	 * 构造方法，默认将time设置为当前时间。
	 * 
	 * @param appkey
	 *            语义云平台上申请的应用的Appkey
	 * @param secret
	 *            语义云平台上申请的应用生成的secret
	 */
	public NluRequestPo() {
		
	}
	
	/**
	 * 构造方法，根据所给参数将对象初始化
	 * 
	 * @param appkey
	 *            语义云平台上申请的应用的Appkey
	 * @param secret
	 *            语义云平台上申请的应用生成的secret
	 * @param udid
	 *            终端用户唯一标识，如设备IMEI，设备SN，终端用户微信ID。用于统计终端用户数。
	 * @param appver
	 *            调用本SDK的应用程序的版本号
	 * @param gps
	 *            GPS坐标
	 * @param text
	 *            准备提交进行语义理解的文本信息
	 * @param history
	 *            上次语义理解请求返回的history
	 * @param city
	 *            城市信息（如北京，上海，广州...）
	 * @param time
	 *            时间，格式：yyyy-MM-dd HH:mm:ss
	 * @param voiceId
	 *            语音日志ID
	 * @param scenario
	 *            场景
	 * @param screen
	 *            屏幕大小
	 * @param dpi
	 *            屏幕分辨率
	 */
	public NluRequestPo(String appkey, String secret, String udid, String appver, String gps,
			String text, String history, String city, String time, String voiceid, String scenario,
			String screen, String dpi) {
		this.appkey = appkey;
		this.secret = secret;
		this.udid = udid;
		this.appver = appver;
		this.gps = gps;
		this.text = text;
		this.history = history;
		this.city = city;
		this.time = time;
		this.voiceid = voiceid;
		this.scenario = scenario;
		this.screen = screen;
		this.dpi = dpi;
	}

	public String getUrl() {
		return url;
	}
	
	public void setUrl(String  url) {
		NluRequestPo.url  = url;
	}

	public String getAppkey() {
		return appkey;
	}

	public void setAppkey(String appkey) {
		this.appkey = appkey;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public String getVer() {
		return ver;
	}

	public String getUdid() {
		return udid;
	}

	public void setUdid(String udid) {
		this.udid = udid;
	}

	public String getGps() {
		return gps;
	}

	public void setGps(String gps) {
		this.gps = gps;
	}

	public String getAppver() {
		return appver;
	}

	public void setAppver(String appver) {
		this.appver = appver;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getHistory() {
		return history;
	}

	public void setHistory(String history) {
		this.history = history;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getMethod() {
		return method;
	}

	public String getVoiceId() {
		return voiceid;
	}

	public void setVoiceId(String voiceid) {
		this.voiceid = voiceid;
	}

	public String getScenario() {
		return scenario;
	}

	public void setScenario(String scenario) {
		this.scenario = scenario;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

	public String getDpi() {
		return dpi;
	}

	public void setDpi(String dpi) {
		this.dpi = dpi;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getViewid() {
		return viewid;
	}

	public void setViewid(String viewid) {
		this.viewid = viewid;
	}
}