package com.unisound.tmp;
/***
 * 错误对象
 * @author  unisound <br/>
 *
 */
public class USCError {

	/***
	 * 错误码
	 */
	public int code;
	/***
	 * 错误描述
	 */
	public String msg;
	
	public USCError(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}
	
	public USCError(){}

	@Override
	public String toString() {
		return "USCError [code=" + code + ", msg=" + msg + "]";
	}

}
