package com.unisound.client;

import com.unisound.common.VoiceprintResult;

/**
 * 声纹回调
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public interface VoicePrintRecognizerListener {
	//VPR_RecordingStart
	//VPR_RecordingStop
	//VPR_End
	/**
	 * 扩展接口
	 * @param type
	 * @see SpeechConstants
	 */
	public int onEvent(int type , int times);
	
	/**
	 * 声纹处理结果状态回调
	 * VPR_REGISTER
	 * VPR_LOGIN
	 * @param type 
	 */
	public void onResult(int type , VoiceprintResult vprResult);
	
	/**
	 * 错误信息
	 * @param type 请参考上面的错误类型
	 * @param errorMSG 相应的错误描述
	 */
	public void onError(int type , String errorMSG);
}
