package com.unisound.client;

/**
 * 语言合成回调
 * @author unisound 
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public interface SpeechSynthesizerListener {

	/**
	 * 在合成过程中的事件的回调
	 *  TTS_EVENT_INIT
	 *  TTS_EVENT_SYNTHESIZER_START
	 *  TTS_EVENT_SYNTHESIZER_END
	 *  TTS_EVENT_BUFFER_BEGIN
	 *  TTS_EVENT_BUFFER_READY
	 *  TTS_EVENT_PLAYING_START
	 *  TTS_EVENT_PLAYING_END
	 *  TTS_EVENT_PAUSE
	 *  TTS_EVENT_RESUME
	 *  TTS_EVENT_CANCEL
	 *  TTS_EVENT_STOP
	 *  TTS_EVENT_RELEASE
	 *  TTS_EVENT_MODEL_LOAD
	 * @param type 请参考 上面的那些状态变量
	 * @see SpeechConstants
	 */
	public void onEvent(int type);

	/**
	 * 错误信息
	 * @param type 请参考上面的错误类型
	 * @param errorMSG 相应的错误描述
	 * @see SpeechConstants
	 */
	public void onError(int type, String errorMSG);

}
