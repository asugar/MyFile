package com.unisound.client;

import android.content.Context;

import com.unisound.sdk.SpeechSynthesizerInterface;

/**
 * 提供在线和离线语音合成的相关接口</br>
 * 通过setOption进行识别参数设置 </br>
 * 合成流程:</br>
 * (1)  通过init方法初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  配置audiosource,如果不配置将使用内置音频处理 </br>
 * (4)  通过playText合成并播放语音</br>
 * (5)  通过synthesizeText只合成语音 & playSynWav只播放语音</br>
 * (6)  通过pause和resume暂停和恢复播放 </br>
 * (7)  通过cancel和stop取消和停止 </br>
 * (8)  通过release结束本次合成，并释放资源 </br>
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class SpeechSynthesizer extends SpeechSynthesizerInterface {

	public SpeechSynthesizer(Context context, String appKey, String secret) {
		super(context, appKey, secret);
	}

	/**
	 * 判断当前状态 READY, SYNTHESIZING, PAUSE, PLAYING, STOPPED （暂时不支持）
	 */
	public int getStatus() {
		return super.getStatus();
	}

	/**
	 * 根据JsonStr初始化TTS引擎文件，完成后回调onEvent type = TTS_EVENT_INIT
	 * @param jsonStr
	 * @return 0成功
	 */
	public int init(String jsonStr) {
		return super.init(jsonStr);
	}

	/**
	 * 加载 TTS 相关声音文件,非阻塞 完成后回调onEvent type = TTS_LOADMODEL_END（预留，暂不支持）
	 */
	public int loadModel(String dataFile) {
		return super.loadModel(dataFile);
	}

	/**
	 * 加载用户字典。 用户字典用来对于一些用户自定义的特殊发音做标记。 （预留，暂不支持）
	 */
	public int loadUserDict(String userDictName, String userDictPath) {
		return super.loadUserDict(userDictName, userDictPath);
	}

	/**
	 * 暂停播放,非阻塞
	 */
	public void pause() {
		super.pause();
	}

	/**
	 * 合成并播放utf8的文本,直到播放结束,非阻塞
	 */
	public int playText(String utfTxt) {
		return super.playText(utfTxt);
	}

	/**
	 * 设置需要合成的utf8的文本，并开始合成,非阻塞
	 */
	public void synthesizeText(String utfTxt) {
		super.synthesizeText(utfTxt);
	}

	/**
	 * 将前面合成的声音播放出来,非阻塞
	 */
	public void playSynWav() {
		super.playSynWav();
	}

	/**
	 * 暂停后恢复合成,非阻塞
	 */
	public void resume() {
		super.resume();
	}

	/**
	 * 取消
	 */
	public void cancel() {
		super.cancel();
	}

	/**
	 * 停止播放,非阻塞
	 */
	public void stop() {
		super.stop();
	}

	/**
	 * 释放资源
	 */
	public int release(int type, String dataName) {
		return super.release(type, dataName);
	}

	/**
	 * 用来设置 audiosource IAudioSource （暂不支持）
	 */
	public int setAudioSource(IAudioSource audioSource) {
		return super.setAudioSource(audioSource);
	}

	/**
	 * 设置合成相关参数
	 */
	public void setOption(int key, Object params) {
		super.setOption(key, params);
	}

	/**
	 * 获取合成相关参数设置
	 */
	public String getOption(int key) {
		return super.getOption(key);
	}

	/**
	 * 设置SynthesizerListener回调接口 SpeechSynthesizerListener listener
	 */
	public void setTTSListener(SpeechSynthesizerListener listener) {
		super.setTTSListener(listener);
	}

}
