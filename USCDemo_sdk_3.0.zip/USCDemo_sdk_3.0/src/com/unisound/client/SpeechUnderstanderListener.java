package com.unisound.client;

/**
 * 语音识别理解回调
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public interface SpeechUnderstanderListener {

//	/**
//	 * 识别结果返回
//	 * @param result   识别结果，非一次返回
//	 * @param isLast    true 表示识别结果已取完，false 表示识别结果未取完
//	 */
//	public void onResult(SpeechUnderstanderResult result, boolean isLast);
//	
//	/**
//	 * 语音识别理解解析回调
//	 * @param result  语音识别理解结果
//	 * @see SpeechUnderstanderResult 更多信息参考 SpeechUnderstanderResult
//	 */
//	public void onEndResult(SpeechUnderstanderResult result);
//	
	/*
	final int YZH_ASR_EVENT_SPEECH_DETECTED = 0;
	final int YZH_ASR_EVENT_SPEECH_END = 1;
	final int YZH_ASR_EVENT_FX_VOLUME_CHANGE = 2;
	final int YZH_ASR_EVENT_FX_ABNORMAL_TOO_LOUD = 3;
	final int YZH_ASR_EVENT_FX_ABNORMAL_TOO_QUIET = 4;
	final int YZH_ASR_EVENT_FX_ABNORMAL_SNR_BAD = 5;
	final int YZH_ASR_EVENT_FX_ABNORMAL_NO_LEADINGSILENCE = 5;
	
	/**
	 * 由于本地和云端返回结果的速度不同，有可能云端结果由于网络因素，迟迟不归，那么直接使用本地的结果 
	 * 在得到下面任何一个消息后，请调用 getResult 来获得消息内容
	 */
	//final int YZH_ASR_EVENT_LOCAL_RESULT_READY = 6;
	//final int YZH_ASR_EVENT_REMOTE_RESULT_READY = 7;
	/*final int YZH_ASR_EVENT_RESULT_READY = 8;
	*/
	
	/**
	 * SPPEECHSTART
	 * RECORDINGSTART
	 * RECORDINGSTOP
	 * 在timeMs 时刻 获得type类型的事件
	 * @param type 请参考上面的类型列表
	 * @param timeMs
	 * @see SpeechConstants
	 */
	public void onEvent(int type, int timeMs) ;
	/**
	 * 在处理timeMs 毫秒的语音时，发现有人声，该回调被触发
	 * @param timeMS
	 */
	
	
	/**
	 * 错误信息
	 * @param type 请参考上面的错误类型
	 * @param errorMSG 相应的错误描述
	 */
	public void onError(int type , String errorMSG);
	
	/**
	 * ASR_FIX_RESULT
	 * ASR_ONLINE_RESULT
	 * ASR_ONLINE_LAST_RESULT
	 * ASR_NLU_RESULT
	 * @param type
	 * @param result 识别结果，非一次返回
	 */
	public void onResult(int type , String jsonResult);
}
