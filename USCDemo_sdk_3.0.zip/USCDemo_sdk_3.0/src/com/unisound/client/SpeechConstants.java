package com.unisound.client;

/**
 * 公共常量
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class SpeechConstants {
	//常量定义
	//ASR & NLU-> 1
	//TTS -> 2
	//WakeUp -> 3
	//VPR -> 4
	
	//key ->0
	//event ->1
	//result ->2
	//error ->3
	//release type ->4

	//Example:
	//ASR event 10xx
	//ASR event 11xx
	//ASR result 12xx
	//ASR error 13xx


	/**
	 * 识别模式。如云端识别、本地识别、云+端的混合模式
	 */
	public static final int ASR_SERVICE_MODE = 1001 ; //如云端识别、本地识别、云+端的混合模式。 服务模式，如用户可以在无网络的情况下选择本地识别。
	
	/**
	 * 在线识别带宽
	 */
	public static final int ASR_BANDWIDTH = 1002 ;	//在线识别带宽
	
	/**
	 * 远近讲语言模型<br>
	 */
	public static final int ASR_VOICE_FIELD=1003;//远近讲语言模型
	
	/**
	 * 语言
	 */
	public static final int ASR_LANGUAGE = 1004 ;//取值 "chinese"中文，"english"英文，"cantonese"粤语
	
	/**
	 * 预留，暂不支持
	 * 方言
	 */
	public static final int ASR_DIALECT = 1005;
	
	/**
	 * 预留，目前只支持opus
	 * 音频编解码算法名称，用户可以根据网络状况等实际情况选择合适的压缩等级。
	 */
	public static final int ASR_AUDIO_ENCODE = 1006 ;//音频编解码算法名称，用户可以根据网络状况等实际情况选择合适的压缩等级。
	
	/**
	 * 不同领域有不同的词汇集，指明所属领域更有利于提高识别率
	 */
	public static final int ASR_DOMAIN = 1008 ; //不同领域有不同的词汇集，指明所属领域更有利于提高识别率

	/**
	 * 识别服务器地址
	 */
	public static final int ASR_SERVER_ADDR = 1009 ;
	
	/**
	 * 设置vad前段超时
	 */
	public static final int ASR_VAD_TIMEOUT_FRONTSIL = 1010;
	
	/**
	 * 设置vad后端超时
	 */
	public static final int ASR_VAD_TIMEOUT_BACKSIL = 1011;

	/**
	 * 设置识别sessionid
	 */
	public static final int ASR_SESSION_ID = 1012 ;
	
	/**
	 * 设置唤醒词
	 */
	public static final int ASR_WAKEUP_WORD = 1013 ;
	
	/**
	 * 设置网络交互超时
	 */
	public static final int ASR_NET_TIMEOUT = 1014 ;
	
	/**
	 * 同步请求语义结果
	 */
	public static final int NLU_ENABLE = 1020 ;
	/**
	 * 设置语义识别场景
	 */
	public static final int NLU_SCENARIO = 1021 ;
	/**
	 * 设置语义服务器
	 */
	public static final int NLU_SERVER_ADDR = 1022 ;
	
	/**
	 * 设置历史
	 */
	public static final int GENERAL_HISTORY = 1030 ;
	
	/**
	 * 设置城市
	 */
	public static final int GENERAL_CITY = 1031 ;
	
	/**
	 * 设置voiceid
	 */
	public static final int GENERAL_VOICEID = 1032 ;
	
	/**
	 * 设置GPS信息
	 */
	public static final int GENERAL_GPS = 1033 ;
	
	/**
	 * 设置时间
	 */
	public static final int GENERAL_TIME = 1034 ;
	
	/**
	 * 设置屏幕dpi
	 */
	public static final int GENERAL_DPI = 1035 ;
	
	/**
	 * 设置识别udid
	 */
	public static final int GENERAL_UDID = 1036 ;
	
	/**
	 * 设置imei
	 */
	public static final int GENERAL_IMEI = 1037 ;
	
	/**
	 * 设置appname
	 */
	public static final int GENERAL_APP_NAME = 1038 ;
	
	/**
	 * 设置carrier
	 */
	public static final int GENERAL_CARRIER = 1039 ;
	
	/**
	 * 设置phonemodel
	 */
	public static final int GENERAL_PHONE_MODEL = 1040 ;
	
	/**
	 * 设置操作系统
	 */
	public static final int GENERAL_PHONE_OS = 1041 ;
	
	/**
	 * 设置操作系统版本
	 */
	public static final int GENERAL_PHONE_OS_VERSION = 1042 ;
	
	/**
	 * 设置设备网络类型
	 */
	public static final int GENERAL_PHONE_NETWORK = 1043 ;
	
	/**
	 * 采样率
	 */
	public static final int ASR_SAMPLING_RATE = 1044 ;	//采样率
	
	/**
	 * 音量更新
	 */
	public static final int GENERAL_UPDATE_VOLUME = 1045 ;
	
	/**
	 * TAG
	 */
	public static final int ASR_OPT_ENGINE_TAG = 1050 ;	
	
	/**
	 * 是否过滤 如不过滤，显示离线标签
	 */
	public static final int ASR_OPT_RESULT_FILTER = 1051 ;	
	
	/**
	 * 
	 */
	public static final int ASR_OPT_PCM_DATA = 1052 ;
	
	/**
	 * 设置录音是否可用
	 */
	public static final int ASR_OPT_RECORDING_ENABLED = 1053 ;
	
	/**
	 * 打印log
	 */
	public static final int ASR_OPT_PRINT_LOG = 1054 ;
	
	/**
	 * 录音不暂停
	 */
	public static final int ASR_OPT_FIX_ASR_CONTINUOUS = 1055 ;
	
	
	/**
	 * 前端 vad是否可用
	 */
	public static final int ASR_OPT_FRONT_VAD_ENABLED = 1056 ;
	
	/**
	 * 
	 */
	public static final int ASR_OPT_LOG_LISTENER = 1057 ;	
	
	/**
	 * 保存录音数据，传入路径
	 */
	public static final int ASR_OPT_SAVE_RECORDING_DATA = 1058 ;	

	/**
	 * 离线结果转为 json
	 */
	public static final int ASR_OPT_RESULT_JSON = 1059 ;	

	/**
	 * 释放引擎类型,释放整个引擎
	 */
	public static final int ASR_RELEASE_ENGINE = 1401 ;	
	/**
	 * 释放引擎类型,释放用户字典
	 */
	public static final int ASR_RELEASE_USERDICT = 1402 ;	
	/**
	 * 释放引擎类型,释放语法
	 */
	public static final int ASR_RELEASE_GRAMMAR = 1403 ;	
	/**
	 * 释放引擎类型,释放词表
	 */
	public static final int ASR_RELEASE_VOCAB = 1404 ;	
	
	/**
	 * 识别模式</br>
	 * ASR_SERVICE_MODE可选项</br>
	 * ASR_SERVICE_MODE_LOCAL 本地识别
	 */
	public static final int ASR_SERVICE_MODE_LOCAL = 2 ;
	/**
	 * 识别模式</br>
	 * ASR_SERVICE_MODE可选项</br>
	 * ASR_SERVICE_MODE_NET 在线识别
	 */
	public static final int ASR_SERVICE_MODE_NET = 1 ;
	/**
	 * 识别模式</br>
	 * ASR_SERVICE_MODE可选项</br>
	 * ASR_SERVICE_MODE_MIX 在线离线混合识别
	 */
	public static final int ASR_SERVICE_MODE_MIX = 0 ;
	
	/**
	 * 语言模型 </br>
	 * ASR_VOICE_FIELD可选项 </br>
	 * VOICE_FIELD_FAR 远讲</br>
	 */
	public static final String VOICE_FIELD_FAR = "far";	
	
	/**
	 * 语言模型 </br>
	 * ASR_VOICE_FIELD可选项 </br>
	 * VOICE_FIELD_NEAR 近讲</br>
	 */
	public static final String VOICE_FIELD_NEAR = "near";
	
	
//	/**
//	 * 语言 </br>
//	 * ASR_LANGUAGE可选项</br>
//	 * LANGUAGE_MANDARIN 普通话</br>
//	 */
//	public static final String LANGUAGE_MANDARIN = "mandarin";
//	
//	/**
//	 * 语言 </br>
//	 * ASR_LANGUAGE可选项</br>
//	 * LANGUAGE_CANTONESE 粤语</br>
//	 */
//	public static final String LANGUAGE_CANTONESE = "cantonese";
//	
//	/**
//	 * 语言 </br>
//	 * ASR_LANGUAGE可选项</br>
//	 * LANGUAGE_ENGLISH 英语</br>
//	 */
//	public static final String LANGUAGE_ENGLISH = "english";
	
	/**
	 * 语言 </br>
	 * ASR_LANGUAGE可选项</br>
	 * LANGUAGE_ENGLISH 英语</br>
	 */
	public static final String LANGUAGE_ENGLISH = "en";
	/**
	 * 语言 </br>
	 * ASR_LANGUAGE可选项</br>
	 * LANGUAGE_CANTONESE 粤语</br>
	 */
	public static final String LANGUAGE_CANTONESE = "co";
	/**
	 * 语言 </br>
	 * ASR_LANGUAGE可选项</br>
	 * LANGUAGE_MANDARIN 普通话</br>
	 */
	public static final String LANGUAGE_MANDARIN = "cn";
//	public static final String ORAL = "oral";
//	public static final String CN_EN_MIX = "cn_en_mix";
	
	
	/**
	 * 采样率 </br>
	 * ASR_SAMPLING_RATE可选项</br>
	 * ASR_SAMPLING_RATE_BANDWIDTH_AUTO 自动</br>
	 */
	public static final int ASR_SAMPLING_RATE_BANDWIDTH_AUTO = 100;
	/**
	 * 采样率 </br>
	 * ASR_SAMPLING_RATE可选项</br>
	 * ASR_SAMPLING_RATE_8K 16kto 8k</br>
	 */
	public static final int ASR_SAMPLING_RATE_8K = 8000;
	/**
	 * 采样率 </br>
	 * ASR_SAMPLING_RATE可选项</br>
	 * ASR_SAMPLING_RATE_16K 16k</br>
	 */
	public static final int ASR_SAMPLING_RATE_16K = 16000;
	/**
	 * 是否同步请求语义</br>
	 * NLU_ISENABLE可选项</br>
	 * NLU_ISENABLE_ENABLE 不同步请求语义
	 */
	public static final String NLU_ISENABLE_DISABLE = "nlu_isEnable_disable";

	/**
	 * tts使用到的key 20
	 */
	/**
	 * 设置合成语速</br>
	 */
	public static final int TTS_KEY_VOICE_SPEED = 2001;
	/**
	 * 设置合成音高</br>
	 */
	public static final int TTS_KEY_VOICE_PITCH = 2002;
	/**
	 * 设置合成音量</br>
	 */
	public static final int TTS_KEY_VOICE_VOLUME = 2003;
	/**
	 * 设置合成码率</br>
	 */
	public static final int TTS_KEY_SAMPLE_RATE = 2004;
	/**
	 * 设置合成角色</br>
	 */
	public static final int TTS_KEY_VOICE_NAME = 2005;

	/**
	 * 设置合成领域</br>
	 */
	public static final int TTS_KEY_FIELD = 2010;

	/**
	 * 设置TTS服务器地址</br>
	 */
	public static final int TTS_KEY_SERVER_ADDR = 2011;

	/**
	 * 设置播放开始延迟时间</br>
	 */
	public static final int TTS_KEY_PLAY_START_BUFFER_TIME = 2012;

	/**
	 * 设置语音采样率</br>
	 */
	public static final int TTS_KEY_STREAM_TYPE = 2013;
	
	/**
	 * 设置是否打印log日志</br>
	 */
	public static final int TTS_KEY_IS_DEBUG = 2014;
	
	/**
	 * 设置合成文件音频保存路径</br>
	 */
	public static final int TTS_KEY_DEBUG_DIR = 2015;
	
	/**
	 * 设置合成模式</br>
	 */
	public static final int TTS_SERVICE_MODE = 2020;
	
	/**
	 * 本地合成</br>
	 */
	public static final int TTS_SERVICE_MODE_LOCAL = 1;
	
	/**
	 * 在线合成</br>
	 */
	public static final int TTS_SERVICE_MODE_NET = 2;
	
	/*
	 * 1.往服务器传数据多久传递一次params
	 * 2.网络交互超时
	 */
	
	 /* 设置识别领域 SpeechConstants.ASR_ENGINE </br>
	 * 设置在线识别带宽 SpeechConstants.ASR_BANDWIDTH	 
	 * 设置远近讲 SpeechConstants.ASR_VOICE_FIELD 可选项为VOICE_FIELD_NEAR、VOICE_FIELD_FAR 默认为VOICE_FIELD_NEAR</br>
	 * 设置识别语言 SpeechConstants.LANGUAGE </br>
	 * 设置语义理解场景 SpeechConstants.NLU_SCENARIO </br>
	 * 设置语义解析服务器 SpeechConstants.NLU_SERVER server=ip:port 例如："http://192.168.1.1:80"</br>
	 * 语义云平台返回的历史信息 SpeechConstants.NLU_HISTORY</br>
	 * 设置语义解析城市信息 SpeechConstants.NLU_CITY ,参看城市Cnstants->TODO</br>
	 * 设置语义日志ID SpeechConstants.NLU_VOICEID
	 */

	/**
	 * TTS onEvent 类型 21
	 */
	/**
	 * TTS onEvent type</br> 初始化成功事件
	 */
	public final static int TTS_EVENT_INIT = 2101;

	/**
	 * TTS onEvent type</br> 开始合成事件
	 */
	public final static int TTS_EVENT_SYNTHESIZER_START = 2102;
	/**
	 * TTS onEvent type</br> 结束合成事件
	 */
	public final static int TTS_EVENT_SYNTHESIZER_END = 2103;

	/**
	 * TTS onEvent type</br> 开始缓冲
	 */
	public static final int TTS_EVENT_BUFFER_BEGIN = 2104;
	/**
	 * TTS onEvent type</br> 缓冲就绪
	 */
	public static final int TTS_EVENT_BUFFER_READY = 2105;

	/**
	 * TTS onEvent type</br> 开始播放事件
	 */
	public final static int TTS_EVENT_PLAYING_START = 2106;
	/**
	 * TTS onEvent type</br> 结束播放事件
	 */
	public final static int TTS_EVENT_PLAYING_END = 2107;

	/**
	 * TTS onEvent type</br> 暂停事件
	 */
	public final static int TTS_EVENT_PAUSE = 2108;
	/**
	 * TTS onEvent type</br> 恢复事件
	 */
	public final static int TTS_EVENT_RESUME = 2109;

	/**
	 * TTS onEvent type</br> 取消事件
	 */
	public final static int TTS_EVENT_CANCEL = 2110;
	/**
	 * TTS onEvent type</br> 停止事件
	 */
	public final static int TTS_EVENT_STOP = 2111;

	/**
	 * TTS onEvent type</br> 释放事件（引擎、模型、用户字典）
	 */
	public final static int TTS_EVENT_RELEASE = 2112;

	/**
	 * TTS onEvent type</br> 模型加载
	 */
	public static final int TTS_EVENT_MODEL_LOAD = 2113;

	/**
	 * TTS result 22开始(TTS 暂无)
	 */

	/**
	 * TTS error 23开始
	 */
	public static final int TTS_ERROR = 2301;

	/**
	 * TTS release 24开始
	 */
	/**
	 * TTS release type</br> 释放引擎
	 */
	public static final int TTS_RELEASE_ENGINE = 2401;
	/**
	 * TTS release type</br> 释放模型
	 */
	public static final int TTS_RELEASE_MODEL_DATA = 2402;
	/**
	 * TTS release type</br> 释放用户
	 */
	public static final int TTS_RELEASE_USERDICT = 2403;

	/**
	 * ASR onEvent type</br>
	 * 开始录音
	 */
	public static final int ASR_EVENT_RECORDING_START = 1101;
	/**
	 * ASR onEvent type</br>
	 * 结束录音
	 */
	public static final int ASR_EVENT_RECORDING_STOP = 1102;
	/**
	 * ASR onEvent type</br>
	 * VAD 超时
	 */
	public static final int ASR_EVENT_VAD_TIMEOUT = 1103;
	/**
	 * ASR onEvent type</br>
	 * 检测到说话
	 */
	public static final int ASR_EVENT_SPEECH_DETECTED = 1104;
	/**
	 * ASR onEvent type</br>
	 * 说话停止
	 */
	public static final int ASR_EVENT_SPEECH_END = 1105;
//	/**
//	 * ASR onEvent type</br>
//	 * 声音改变
//	 */
//	public static final int ASR_EVENT_FX_VOLUME_CHANGE = 1106;
	/**
	 * ASR onEvent type</br>
	 * VAD 识别结束
	 */
	public static final int ASR_EVENT_RECOGNIZITION_END = 1107;
	
	/**
	 * ASR onEvent type</br>
	 * 用户数据上传结束
	 */
	public static final int ASR_EVENT_USERDATA_UPLOADED = 1108;
	
	/**
	 * ASR onEvent type</br>
	 * 用户grammar模型编译结束
	 */
	public static final int ASR_EVENT_GRAMMAR_COMPILED = 1109;
	
	/**
	 * ASR onEvent type</br>
	 * 用户grammar模型加载结束
	 */
	public static final int ASR_EVENT_GRAMMAR_LOADED = 1110;
	
	/**
	 * ASR onEvent type</br>
	 * 用户grammar模型插入host grammar模型结束,可以开始识别
	 */
	public static final int ASR_EVENT_GRAMMAR_INSERTED = 1111;
	
	/**
	 * ASR onEvent type</br>
	 * 用户词表插入host grammar模型结束,可以开始识别
	 */
	public static final int ASR_EVENT_VOCAB_INSERTED = 1112;
	
	/**
	 * ASR onEvent type</br>
	 * 检测音量过大
	 */
	public static final int ASR_EVENT_FX_ABNORMAL_TOO_LOUD = 1113;
	/**
	 * ASR onEvent type</br>
	 * 检测音量过小
	 */
	public static final int ASR_EVENT_FX_ABNORMAL_TOO_QUIET = 1114;
	/**
	 * ASR onEvent type</br>
	 */
	public static final int ASR_EVENT_FX_ABNORMAL_SNR_BAD = 1115;
	/**
	 * ASR onEvent type</br>
	 */
	public static final int ASR_EVENT_FX_ABNORMAL_NO_LEADINGSILENCE = 1116;
	/**
	 * ASR onEvent type</br>
	 * 取消
	 */
	public static final int ASR_EVENT_CANCEL = 1117;
	
	/**
	 * ASR LOCAL onEvent type</br>
	 * LOCAL识别结束
	 */
	public static final int ASR_EVENT_LOCAL_END = 1118;
	
	/**
	 * ASR NETonEvent type</br>
	 * NET识别结束
	 */
	public static final int ASR_EVENT_NET_END = 1119;
	
	/**
	 * ASR onEvent type</br>
	 * 识别结束
	 */
	public static final int ASR_EVENT_END = 1120;
	
	/**
	 * ASR_NLU onEvent type</br>
	 * 语义理解结束
	 */
	public static final int ASR_NLU_EVENT_END = 1121;
	
	/**
	 * ASR onEvent type</br>
	 * 音量改变
	 */
	public static final int ASR_EVENT_VOLUMECHANGE = 1122;
	
	/**
	 * ASR_NLU onError type</br>
	 * 语义错误
	 */
	public static final int ASR_NLU_ERROR = 1301;
	
	/**
	 * ASR onResult type</br>
	 * 识别在线理解返回
	 */
	public static final int ASR_RESULT_NET = 1201;
	
	/**
	 * ASR onResult type</br>
	 * 识别离线理解返回
	 */
	public static final int ASR_RESULT_LOCAL = 1202;
	
	/**
	 * ASR_NLU onResult type</br>
	 * 语义理解返回
	 */
	public static final int ASR_RESULT_NLU = 1210;
	
	/**
	 * VPR录音是否可用
	 */
	public static final int VPR_RECORDING_ENABLED = 4001;

	/**
	 * VPR是否获取wav头文件
	 */
	public static final int VPR_GET_WAVE_DATA_ENABLED = 4002;

	/**
	 * VPR服务器地址
	 */
	public static final int VPR_SERVER_ADDR = 4003;

	/**
	 * VPR采样率8k
	 */
	public static final int VPR_INPUT_8K = 4004;

	/**
	 * VPR采样率16k
	 */
	public static final int VPR_INPUT_16k = 4005;

	/**
	 * VPR 场景SCENE_ID
	 */
	public static final int VPR_SCENE_ID = 4006;

	/**
	 * VPR设置log监听
	 */
	public static final int VPR_LOG_LISTNER = 4007;

	/**
	 * VPR保存录音数据
	 */
	public static final int VPR_SAVE_RECORDING_DATA = 4008;

	/**
	 * VPR设置前端VAD是否可用
	 */
	public static final int VPR_FRONT_VAD_ENABLED = 4009;

	/**
	 * VPR设置采样率
	 */
	public static final int VPR_SAMPLE_RATE = 4010;

	/**
	 * VPR设置是否采用蓝牙录音
	 */
	public static final int VPR_BLUETOOTH_ENABLED = 4011;

	/**
	 * VPR设置VAD前后端超时
	 */
	public static final int VPR_VAD_TIMEOUT = 4012;

	/**
	 * VPR设置停止识别超时
	 */
	public static final int VPR_STOP_TIMEOUT = 4013;

	/**
	 * VPR设置远近讲
	 */
	public static final int VPR_FARFILED_ENABLED = 4014;

	/**
	 * VPR设置请求保存的注册录音的地址
	 */
	public static final int VPR_REQUEST_AUDIO_SERVER = 4015;

	/**
	 * VPR设置识别类型
	 */
	public static final int VPR_TYPE = 4016;

	/**
	 * VPR用户名称
	 */
	public static final int VPR_USERNAME = 4017;

	/**
	 * VPR获取wav头文件
	 */
	public static final int VPR_GET_WAVE_HEADER = 4018;

	/**
	 * VPR获取注册录音
	 */
	public static final int VPR_GET_REQUEST_AUDIO = 4019;

	/**
	 * VPR获取session ID
	 */
	public static final int VPR_SESSION_ID = 4020;

	/**
	 * VPR onEvent type</br> 声纹识别开始
	 */
	public static final int VPR_EVENT_RECOGNITION_START = 4104;

	/**
	 * VPR onEvent type</br> 声纹识别开始说话
	 */
	public static final int VPR_EVENT_SPEECH_START = 4106;

	/**
	 * VPR onEvent type</br> 声纹说话超时
	 */
	public static final int VPR_EVENT_VAD_TIMEOUT = 4107;

	/**
	 * VPR onResult Type</br> 声纹结果返回
	 */
	public static final int VPR_RESULT = 4201;

	/**
	 * VPR onError 声纹错误返回
	 */
	public static final int VPR_ERROR = 4301;
	/**
	 * VPR onEvent type</br>
	 * 录音开始
	 */
	public static final int VPR_EVENT_RECORDING_START = 4101;
	/**
	 * VPR onEvent type</br>
	 * 录音结束
	 */
	public static final int VPR_EVENT_RECORDING_STOP = 4102;
	
	/**
	 * VPR onEvent type</br>
	 * 声音改变
	 */
	public static final int VPR_EVENT_VOLUME_UPDATED = 4103;
	
	/**
	 * VPR onEvent type</br>
	 * 声纹识别结束
	 */
	public static final int VPR_EVENT_RECOGNITION_END = 4104;
	
	
	/**
	 * WAKEUP onEvent type</br>
	 * 录音开始,进行唤醒识别
	 */
	public static final int WAKEUP_EVENT_RECORDING_START = 3101;
	/**
	 * WAKEUP onEvent type</br>
	 * 录音结束,停止唤醒识别
	 */
	public static final int WAKEUP_EVENT_RECORDING_STOP = 3102;
	
	/**
	 * WAKEUP onEvent type</br>
	 * 识别结束
	 */
	public static final int WAKEUP_EVENT_RECOGNIZITION_END = 3103;
	
	/**
	 * WAKEUP onEvent type</br>
	 * 初始化完毕
	 */
	public static final int WAKEUP_EVENT_INIT_DEFAULTDATA_FINISH = 3104;
	/**
	 * WAKEUP onEvent type</br>
	 * 初始化完毕
	 */
	public static final int WAKEUP_EVENT_INIT_USERDATA_FINISH = 3105;
	
	/**
	 * WAKEUP onResult type</br>
	 * 唤醒结果
	 */
	public static final int WAKEUP_RESULT = 3201;
	
	/**
	 * WAKEUP onResult type</br>
	 * 唤醒错误
	 */
	public static final int WAKEUP_ERROR = 3301;
}
