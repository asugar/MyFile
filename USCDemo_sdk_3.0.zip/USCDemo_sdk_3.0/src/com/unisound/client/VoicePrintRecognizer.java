package com.unisound.client;

import com.unisound.sdk.VoicePrintRecognizerInterface;

import android.content.Context;

/**
 * 提供声纹识别相关接口
 * 通过setOption进行语义理解参数设置 </br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  通过start传入用户标示和启动类型(注册|登陆),开始进行声纹识别 </br>
 * (4)  获取回调,得到语义理解json结果 </br>
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class VoicePrintRecognizer extends VoicePrintRecognizerInterface{
	
	/**
	 * 声纹识别构造方法
	 * @param context
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	public VoicePrintRecognizer(Context context, String appKey ,String secret) {
		super(context, appKey, secret);
	}
	
	/**
	 * init 通过 jsonFile来配置系统启动参数
	 * @param JsonStr
	 * @return 如果为0 则表示成功，否则返回错误码
	 * @see 
	 */
	public int init(String JsonStr) {
		return 0;
	}

	/**
	 * 启动声纹识别
	 * @param userName 用户标识
	 * @param Type 1:声纹注册 2:声纹登陆
	 */
	public void start(String userName , int Type) {
		super.start(userName, Type);
	}

	/**
	 * 停止录音，完成当前任务
	 */
	public void stop() {
		super.stop();
	}

	/**
	 * 放弃当前任务
	 */
	public void cancel() {
		super.cancel();
	}
	
	/**
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	public void setListener(VoicePrintRecognizerListener listener){
		super.setListener(listener);
	}
	
	/**
	 * 用来设置 audiosource 
	 * @param audioSource
	 * @return 0 表示成功， 否则返回相应错误码
	 */
	public int setAudioSource(IAudioSource audioSource) {
		return 0;
	}
	
	/**
	 * 设置可选项</br>
	 * 设置采样率是否是8k 16000/8000{@link com.unisound.client.SpeechConstants#VPR_INPUT_8K} </br>
	 * 设置采样率是否是16k {@link com.unisound.client.SpeechConstants#VPR_INPUT_16k} </br>
	 * 设置识别SCENE    {@link com.unisound.client.SpeechConstants#VPR_SCENE_ID}</br>
	 * 添加Log监听对象    {@link com.unisound.client.SpeechConstants#VPR_LOG_LISTNER} </br>
	 * 保存录音数据    {@link com.unisound.client.SpeechConstants#VPR_SAVE_RECORDING_DATA} </br>
	 * 设置前端VAD是否可用 {@link com.unisound.client.SpeechConstants#VPR_FRONT_VAD_ENABLED} </br>
	 * 设置采样率  {@link com.unisound.client.SpeechConstants#VPR_SAMPLE_RATE}8k 或 16k</br>
	 * 设置是否开启蓝牙录音 {@link com.unisound.client.SpeechConstants#VPR_BLUETOOTH_ENABLED}</br>
	 * 设置前后端VAD超时{@link com.unisound.client.SpeechConstants#VPR_VAD_TIMEOUT} </br>
	 * 设置停止识别超时(ms)   {@link com.unisound.client.SpeechConstants#VPR_STOP_TIMEOUT} </br>
	 * 设置语义解析服务器 {@link com.unisound.client.SpeechConstants#VPR_SERVER_ADDR} server=ip:port </br>
	 * 设置获取注册语音数据的地址 {@link com.unisound.client.SpeechConstants#VPR_REQUEST_AUDIO_SERVER}</br>
	 * 设置远讲是否可用  {@link com.unisound.client.SpeechConstants#VPR_FARFILED_ENABLED}</br>
	 * 设置VPR的识别类型    {@link com.unisound.client.SpeechConstants#VPR_TYPE}VPRParams.VPR_TYPE_REGISTERED , VPRParams.VPR_TYPE_VPR_TYPE_VERIFY</br>
	 * 设置录音是否可用  {@link com.unisound.client.SpeechConstants#VPR_RECORDING_ENABLED}</br>
	 * 设置是否活取wav文件头   {@link com.unisound.client.SpeechConstants#VPR_GET_WAVE_DATA_ENABLED}</br>
	 * 设置用户名   {@link com.unisound.client.SpeechConstants#VPR_USERNAME}</br>
	 * @param key
	 * @param obj
	 * @see com.unisound.client.SpeechConstants
	 */
	public void setOption(int key , Object value){
		super.setOption(key, value);
	}
	
	/**
	 * 获取可选项
	 * @param key
	 * @return value 返回可选项
	 */
	public Object getOption(int key){
		return super.getOption(key);
	}
	
	
	
}
