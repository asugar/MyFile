package com.unisound.client;



/**
 * 语音唤醒回调
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public interface WakeUpRecognizerListener {
	/**
	 * RecognizerStart</br>
	 * RecognizerStop</br>
	 * 在timeMs 时刻 获得type类型的事件
	 * @param type 请参考上面的类型列表
	 * @param timeMs
	 * @see SpeechConstants
	 */
	public void onEvent(int type, int timeMs) ;
	/**
	 * 在处理timeMs 毫秒的语音时，发现有人声，该回调被触发
	 * @param timeMS
	 */
	
	/**
	 * 错误信息
	 * @param type 请参考上面的错误类型
	 * @param errorMSG 相应的错误描述
	 */
	public void onError(int type , String errorMSG);
	
	/**
	 * ASR_WAKEUP_RESULT
	 * @param type
	 * @param result 识别结果，非一次返回
	 */
	public void onResult(int type , String jsonResult);
}
