package com.unisound.client;
/**
 * 音频源设置
 * @author unisound Copyright (c) 2015, unisound.com All Rights Reserved
 *	该类用来定义相应的audiosource 操作
 */
public interface IAudioSource {
	/**
	 * 打开录音设备
	 * @return 0 表示成功，否则返回错误码
	 */
	public int openAudioIn();
	
	/**
	 * 打开放音设备
	 * @return 0 表示成功，否则返回错误码
	 */
	public int openAudioOut();
	
	/**
	 * 读取 size 大小的声音到buffer里。
	 * @param buffer
	 * @param size
	 * @return 实际读取的字节数。当返回值 小于
	 */
	public int readData(byte[] buffer, int size);
	
	/**
	 * 写入size大小的buffer到放音设备
	 * @param buffer
	 * @param size
	 * @return 实际写入的字节数 
	 */
	public int writeData(byte[] buffer, int size);
	
	/**
	 * 关闭录音设备
	 */
	public void closeAudioIn();
	
	/**
	 * 关闭放音设备
	 */
	public void closeAudioOut();
	
}
