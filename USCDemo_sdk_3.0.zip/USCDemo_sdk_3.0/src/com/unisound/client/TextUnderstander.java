package com.unisound.client;

import android.content.Context;

import com.unisound.sdk.TextUnderstanderInterface;

/**
 * 提供语义理解相关接口</br>
 * 通过setOption进行语义理解参数设置 </br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  通过setText传入文本,开始进行语义理解 </br>
 * (4)  获取回调,得到语义理解json结果 </br>
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class TextUnderstander extends TextUnderstanderInterface{
	
	/**
	 * TextUnderstander构造方法
	 * @param context 上下文
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	public TextUnderstander(Context context, String appKey ,String secret) {
		super(context, secret, secret);
	}
	
	/**
	 * 根据JsonStr初始化NLU
	 * @param JsonStr
	 * @return 0 表示成功，否则返回相应错误码
	 */
	public int init(String JsonStr) {
		return super.init(JsonStr);
	}

	/**
	 * 传入文本开始语义理解,非阻塞
	 * @param   text  需要解析的文本
	 */
	public void setText(String text) {
		super.setText(text);
	};
	
	/**
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	public void setListener(TextUnderstanderListener listener){
		super.setListener(listener);
	}

	/**
	 * 设置可选项</br>
	 * 设置语义理解场景   {@link com.unisound.client.SpeechConstants#NLU_SCENARIO} </br>
	 * 设置语义解析服务器 {@link com.unisound.client.SpeechConstants#NLU_SERVER_ADDR} server=ip:port </br>
	 * 设置云平台返回的历史信息 {@link com.unisound.client.SpeechConstants#GENERAL_HISTORY}</br>
	 * 设置解析城市信息 {@link com.unisound.client.SpeechConstants#GENERAL_CITY} </br>
	 * 设置语义日志ID     {@link com.unisound.client.SpeechConstants#GENERAL_VOICEID} </br>
	 * @param key
	 * @param value
	 * @see SpeechConstants
	 */
	public void setOption(int key , Object value){
		super.setOption(key, value);
	}
	
	/**
	 * 获取可选项
	 * @param key
	 * @return value 返回可选项
	 */
	public Object getOption(int key){
		return super.getOption(key);
	}
	
	/**
	 * 取消
	 */
	public void cancel(){
		super.cancel();
	}
}
