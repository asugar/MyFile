package com.unisound.client;

import java.util.List;

import com.unisound.sdk.WakeUpRecognizerInterface;

import android.content.Context;

/**
 * 提供语音唤醒相关接口
 * 通过setOption进行语义理解参数设置 </br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  通过loadModel加载模型 (optional)</br>
 * (4)  通过setWakeupWord 设置唤醒词(optional) </br>
 * (5)  通过star开始语音唤醒 </br>
 * (6)  获取回调 </br>
 * (7)  继续进入下一次语音唤醒
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class WakeUpRecognizer extends WakeUpRecognizerInterface{

	/***
	 * 构造方法
	 * @param context  上下文环境
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	public WakeUpRecognizer(Context context, String appKey ,String secret) {
		super(context , appKey , secret);
	}
	
	/**
	 * 根据JsonStr初始化WakeUp引擎 
	 * @param JsonStr
	 * @return 0 表示成功，否则返回相应错误码
	 */
	public int init(String JsonStr) {
		return super.init(JsonStr);
	}
	
	/**
	 * 加载模型
	 * @param modelFile
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	public int loadModel(String modelFile) {
		return super.loadModel(modelFile);
	}
	
	/**
	 * 开始语音唤醒
	 */
	public void start() {
		super.start();
	}
	
	
	/**
	 * 停止唤醒 </br>
	 */
	public void stop(){
		super.stop();
	}
	
	/***
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	public void setListener(WakeUpRecognizerListener listener){
		super.setListener(listener);
	}

	/**
	 * 设置可选项</br>
	 * 设置远近讲       {@link com.unisound.client.SpeechConstants#ASR_VOICE_FIELD} 默认为VOICE_FIELD_NEAR</br>
	 * 设置 VAD前端点超时 {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_FRONTSIL} 范围 int 500~3000 (ms)</br>
	 * 设置VAD后端点超时  {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_BACKSIL} 范围 int 500~3000 (ms)</br>
	 * @param key
	 * @param value
	 */
	public void setOption(int key , Object value){
		super.setOption(key, value);
	}
	
	/**
	 * 获取可选项
	 * @param key
	 * @return value 返回可选项
	 */
	public Object getOption(int key){
		return super.getOption(key);
	}
	
	/**
	 * 设置 唤醒词 
	 * @param wakeup
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	public int setWakeupWord(List<String> wakeup) {
		return super.setWakeupWord(wakeup);
	}
		
	/**
	 * 获取唤醒命令词
	 * @return
	 */
	public List<String> getWakeUpWord(){
		return super.getWakeUpWord();
	}
	
	/**
	 * 取消唤醒识别
	 */
	public void cancel() {
		super.cancel();
	}
	
	/**
	 * 释放唤醒模型
	 */
	public void release(){
		super.release();
	}
	
	/**
	 * 用来设置 audiosource 
	 * @param audioSource
	 * @return 0 表示成功, 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	public int setAudioSource(IAudioSource audioSource) {
		return super.setAudioSource(audioSource);
	}
}
