package com.unisound.client;

import java.util.List;
import java.util.Map;

import android.content.Context;

import com.unisound.sdk.SpeechUnderstanderInterface;

/**
 * 提供语音识别+语义理解相关接口</br>
 * 通过setOption进行识别参数设置,支持云端识别、本地识别、云+端的混合模式 </br>
 * 初始化过程:</br>
 * (1)  通过构造函数初始化引擎 </br>
 * (2)  通过init读取json配置,或setOption来配置各种参数 </br>
 * (3)  配置audiosource,如果不配置将使用内置音频处理 </br>
 * (4)  通过loadModel加载模型 (optional)</br>
 * (5)  通过loadGrammar & insertVocab 加载动态数据 (optional)</br>
 * (6)  通过star开始识别 </br>
 * (7)  获取回调 </br>
 * (8)  结束本次识别 </br>
 * 编译及加载模型相关接口为非阻塞
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public class SpeechUnderstander extends SpeechUnderstanderInterface{

	/***
	 * 构造方法
	 * @param context  上下文环境
	 * @param appKey 开发者平台注册获取
	 * @param secret 开发者平台注册获取
	 */
	public SpeechUnderstander(Context context, String appKey ,String secret) {
		super(context,appKey ,secret);
	}
	
	/**
	 * 根据JsonStr初始化ASR引擎 
	 * @param JsonStr 初始化参数配置(Key&Value)
	 * @return 0 表示成功，否则返回相应错误码
	 * @see com.unisound.client.SpeechConstants
	 */
	public int init(String JsonStr) {
		return super.init(JsonStr);
	}
	
	/**
	 * 开始语音识别,使用默认模型
	 */
	public void start() {
		super.start();
	}
	
	/**
	 * 开始语音识别,离线识别使用 grammar_tag 模型
	 * @param grammar_tag 模型识别标签
	 */
	public void start(String grammar_tag) {
		super.start(grammar_tag);
	}
	
	/**
	 * 结束录音，停止本次语音识别，并回调相关结果,非阻塞</br>
	 * 先录音停止回调onEvent type=ASR_EVENT_RECORDING_STOP</br>
	 * 再完成识别回调onEvent type=ASR_EVENT_RECOGNIZITION_END，</br>
	 */
	public void  stop(){
		super.stop();
	}
	
	/**
	 * 取消本次语音识别,停止所有相关回调
	 */
	public void cancel(){
		super.cancel();
	}
	
	/**
	 * 设置状态回调监听
	 * @param listener  回调接口
	 */
	public void setListener(SpeechUnderstanderListener listener){
		super.setListener(listener);
	}

//	/**
//	 * 设置是否同步请求语义结果
//	 * @param enable 默认为true 开启语义设置为true，关闭语义设置为false
//	 */
//	public void setNluEnable(boolean enable){
//		super.setNluEnable(enable);
//	}
	
	/**
	 * 设置可选项</br>
	 * 设置识别模式     {@link com.unisound.client.SpeechConstants#ASR_SERVICE_MODE} </br>
	 * 设置采样率 16000/8000{@link com.unisound.client.SpeechConstants#ASR_SAMPLING_RATE} </br>
	 * 设置在线识别带宽 {@link com.unisound.client.SpeechConstants#ASR_BANDWIDTH} </br>
	 * 设置识别领域     {@link com.unisound.client.SpeechConstants#ASR_DOMAIN} </br>
	 * 设置远近讲       {@link com.unisound.client.SpeechConstants#ASR_VOICE_FIELD} 默认为VOICE_FIELD_NEAR</br>
	 * 设置识别语言     {@link com.unisound.client.SpeechConstants#ASR_LANGUAGE} 默认LANGUAGE_MANDARIN </br>
	 * 设置 VAD前端点超时 {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_FRONTSIL} 范围 int 500~3000 (ms)</br>
	 * 设置VAD后端点超时  {@link com.unisound.client.SpeechConstants#ASR_VAD_TIMEOUT_BACKSIL} 范围 int 500~3000 (ms)</br>
	 * 设置语音解析服务器 {@link com.unisound.client.SpeechConstants#ASR_SERVER_ADDR} server=ip:port</br>
	 * 设置同步请求语义结果 {@link com.unisound.client.SpeechConstants#NLU_ENABLE} 默认同步请求语义</br>
	 * 设置语义理解场景   {@link com.unisound.client.SpeechConstants#NLU_SCENARIO} </br>
	 * 设置语义解析服务器 {@link com.unisound.client.SpeechConstants#NLU_SERVER_ADDR} server=ip:port </br>
	 * 设置云平台返回的历史信息 {@link com.unisound.client.SpeechConstants#GENERAL_HISTORY}</br>
	 * 设置解析城市信息 {@link com.unisound.client.SpeechConstants#GENERAL_CITY} </br>
	 * 设置语义日志ID     {@link com.unisound.client.SpeechConstants#GENERAL_VOICEID} </br>
	 * 设置网络交互超时   {@link com.unisound.client.SpeechConstants#ASR_NET_TIMEOUT} 范围 int 3000~10000 (ms)
	 * @param key
	 * @param value
	 * @see com.unisound.client.SpeechConstants
	 */
	public void setOption(int key , Object value){
		super.setOption(key, value);
	}
	
	/**
	 * 获取可选项
	 * 对应 {@link com.unisound.client.SpeechUnderstander#setOption}
	 * @param key
	 * @return value 返回可选项
	 * @see com.unisound.client.SpeechConstants
	 */
	public Object getOption(int key){
		return super.getOption(key);
	}
	
	/**
	 * 上传用户词表，非阻塞 </br>
	 * 上传完成后回调onEvent type=　ASR_EVENT_USERDATA_UPLOADED</br>
	 * 用户设置命令词并上传，提高识别率</br>
	 * 如果当前为在线识别，则上传词表 </br>
	 * @param userData 用户词表
	 */
	public void uploadUserData(Map<Integer, List<String>> userData) {
		super.uploadUserData(userData);
	}
	
	/**
	 * 编译用户词表，非阻塞 </br>
	 * 编译完成后回调onEvent type=　ASR_EVENT_GRAMMAR_COMPILED</br>
	 * 用户自定义jsgf格式标准语法文件，语音识别系统可以根据此生成标准格式的识别语法 </br>
	 * 如果当前为离线识别，则编译编译模型</br>
	 * @param jsgfPath JSGF文件路径
	 * @param desFile 目标二进制文件
	 * @return 0 表示成功， 否则返回相应错误码
	 */
	public int compileGrammar(String jsgfPath , String desFile) {
		return super.compileGrammar(jsgfPath, desFile);
	}
	
//	/**
//	 * 接收外部录音数据进行识别
//	 * @param data
//	 * @param offset
//	 * @param length
//	 */
//	public void writeAudioData(byte[] data,int offset, int length){
//	}
	
	
	
	/**
	 * 获取版本信息
	 * @return 返回当前版本信息
	 */
	public String getVersion(){
		return super.getVersion();
	}
	
	/**
	 * 返回当前状态 READY, RECOGNIZING, etc
	 * @return 当前状态 范围 int 0-2.
	 * @return 返回当前状态
	 */
	public int getStatus() {
		return getStatus();
	}
	
	/**
	 * 加载模型，非阻塞</br>
	 * 加载完成后回调onEvent type=　ASR_EVENT_MODEL_LOADED
	 * @param modelFile 模型文件路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	public int loadModel(String modelFile) {
		return super.loadModel(modelFile);
	}

	/**
	 * 预留，暂不支持</br>
	 * 加载用户字典， 用户字典用来对于一些用户自定义的特殊发音做标记
	 * @param userDictName 用户字典名称
	 * @param userDictPath 用户字典路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	public int loadUserDict(String userDictName, String userDictPath) {
		return super.loadUserDict(userDictName, userDictPath);
	}
	
	/**
	 * 用来设置 audiosource </br>
	 * 音频源需要实现打开录音,打开放音,关闭,读数据,取数据操作
	 * @param audioSource 相应音频源实现
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode	 
	 */
	public int setAudioSource(IAudioSource audioSource) {
		return super.setAudioSource(audioSource);
	}

//	/**
//	 * 设置 唤醒词 
//	 * @param wakeup
//	 * @return 0 表示成功， 否则返回相应错误码
//	 * @see com.unisound.client.ErrorCode
//	 */
//	public int setWakeupWord(String wakeup) {return 0;}
	
	/**
	 * 将识别参数以json格式批量输入到引擎,加入到目前识别中</br>
	 * 当postInfo和setOption设置同一参数时,以最新调用为准</br>
	 * 可设置参数请参考setoption</br>
	 * @param jsoninfo json格式的字符串，可以包含各种引擎参数，设备参数等.
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 * @see com.unisound.client.SpeechConstants
	 * @see com.unisound.client.SpeechUnderstander#setOption(int, Object)
	 */
	public int postInfo(String jsoninfo) {
		return super.postInfo(jsoninfo);
	}
	
	/**
	 * 加载二进制的grammar文件</br>
	 * 加载完成后回调onEvent type=　ASR_EVENT_GRAMMAR_LOADED
	 * @param grammarName
	 * @param grammarPath
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 * @see com.unisound.client.SpeechConstants
	 * @see com.unisound.client.SpeechUnderstanderListener#onEvent
	 */
	public int loadGrammar(String grammarName, String grammarPath) {
		return super.loadGrammar(grammarName, grammarPath);
	}
	
	/**
	 * 预留, 暂不支持</br>
	 * 把二进制的grammar文件插入相应的host grammar的槽内, 非阻塞</br>
	 * 插入完成后回调onEvent type=　ASR_GRAMMAR_INSERTED
	 * @param grammarName grammar名字
	 * @param grammarPath grammar路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	public int insertGrammar(String grammarName,String grammarPath,String slotName) {
		return super.insertGrammar(grammarName, grammarPath, slotName);
	}
	
	/**
	 * 预留, 暂不支持 </br>
	 * 把动态获得的用户信息插入相应的grammar内, 非阻塞 </br>
	 * 插入完成后回调onEvent type=　ASR_EVENT_VOCAB_INSERTED </br>
	 * 执行后即可start进行识别
	 * @param strList 用户信息列表 比如 联系人列表
	 * @param vocabName 词表名称比如contact,需要和grammar对应
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	public int insertVocab (List<String> strList, String vocabName){
		return super.insertVocab(strList, vocabName);
	}
	
	/**
	 * 预留, 暂不支持</br>
	 * 保存当前Grammar到文件</br>
	 * @param grammarPath grammar保存路径
	 * @return 0 表示成功， 否则返回相应错误码
	 * @see com.unisound.client.ErrorCode
	 */
	public int saveCurGrammar (String grammarPath ){
		return super.saveCurGrammar(grammarPath);
	}
	
	/**
	 * 根据type值进行卸载</br>
	 * type</br>
	 * ASR_ENGINE</br>
	 * ASR_USERDICT</br>
	 * ASR_GRAMMAR</br>
	 * ASR_VOCAB</br>
	 * 
	 * dataName:</br>
	 * null</br>
	 * userDictName</br>
	 * grammarName</br>
	 * vocabName</br>
	 * @param type 
	 * @param dataName 
	 * @return 0 表示成功， 否则返回相应错误码
	 */
	public int release(int type , String dataName) {
		return super.release(type, dataName);
	}
	
	
}
