package com.unisound.client;

/**
 * 语义理解回调
 * @author unisound
 * Copyright (c) 2015, unisound.com All Rights Reserved.
 */
public interface TextUnderstanderListener {
	/**
	 * 预留 
	 * 扩展接口
	 * @param type
	 */
	public void onEvent(int type);
	
	/**
	 * 错误信息
	 * @param type 请参考上面的错误类型
	 * @param errorMSG 相应的错误描述
	 */
	public void onError(int type , String errorMSG);
	
	/**
	 * 在线语义结果
	 * @param type
	 * @param jsonResult
	 */
	public void onResult(int type , String jsonResult);
}
